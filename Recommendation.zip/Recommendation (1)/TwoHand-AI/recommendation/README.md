# 2HandToYou Recommendation

บริการแนะนำสินค้าด้วย Semantic model สำหรับ Backend ของ 2HandToYou รองรับ API 3 เส้น
ใช้โมเดล multilingual MiniLM ที่เตรียมไว้ในเครื่อง ไม่ส่งข้อความไปประมวลผลกับบริการ AI ภายนอกขณะ inference

README นี้อธิบายการรัน **Recommendation แยกบริการ** จาก Recommendation.zip
คำสั่งทั้งหมดให้รันในโฟลเดอร์ `TwoHand-AI/recommendation` ที่มี Dockerfile และ requirements.txt

## 1. เริ่มใช้งานด้วย Docker

ต้องมี Docker Engine / Docker Desktop แบบ Linux containers, Compose v2.20+ และ Python 3 สำหรับสร้าง config

Linux:

```bash
python3 scripts/setup_env.py
docker compose config --quiet
docker compose up -d --build --wait
docker compose ps
```

Windows PowerShell:

```powershell
py -3 scripts/setup_env.py
docker compose config --quiet
docker compose up -d --build --wait
docker compose ps
```

ตัวสร้าง config จะสร้าง `.env` พร้อม API key สุ่ม โดยไม่ทับไฟล์ที่มีอยู่แล้ว
Docker ติดตั้ง dependencies และดาวน์โหลด weights ประมาณ 485 MB ให้ในขั้นตอน build
ครั้งแรกต้องเข้าถึง Docker Hub, PyPI, PyTorch และ Hugging Face ได้
ไม่ต้องติดตั้ง ML libraries บนเครื่อง host เมื่อใช้ Docker

เมื่อบริการพร้อม ให้เปิด `http://127.0.0.1:8000/ready` ต้องได้:

```json
{"status":"ok","engine":"semantic"}
```

ตรวจ log หรือหยุดบริการ:

```bash
docker compose logs --tail=100 recommendation
docker compose down
```

## 2. API ทั้ง 3 เส้น

ทุกเส้นใช้ **POST** และ JSON body

| Endpoint | หน้าที่ | ตัวอย่าง request body ในโปรเจกต์ |
| --- | --- | --- |
| `/gateway/recommendProduct` | แนะนำสินค้าตามความสนใจ/ประวัติ | [examples/recommend.json](examples/recommend.json) |
| `/gateway/similarProduct` | หาสินค้าที่คล้ายกับสินค้าที่เลือก | [examples/similar.json](examples/similar.json) |
| `/gateway/compareProduct` | เลือกสินค้า 3 ชิ้นสำหรับเปรียบเทียบ | [examples/compare.json](examples/compare.json) |

Cold start ใช้ `recommendProduct` เส้นเดิม ดูตัวอย่าง [examples/cold_start.json](examples/cold_start.json)
recommend/similar คืนสินค้าได้สูงสุด 10 ชิ้นตาม candidates ที่มี
compare ต้องได้คู่เทียบครบ 3 ชิ้น มิฉะนั้นค่าเริ่มต้นจะตอบ HTTP 409

Headers:

```text
Content-Type: application/json
api-key: ค่าจาก AI_API_KEY ใน .env
```

ตัวอย่าง curl บน Linux ให้แทน YOUR_API_KEY ด้วยคีย์ของบริการนี้:

```bash
curl -X POST http://127.0.0.1:8000/gateway/recommendProduct \
  -H "Content-Type: application/json" \
  -H "api-key: YOUR_API_KEY" \
  --data-binary @examples/recommend.json
```

## 3. ทดสอบด้วย Postman

ใช้ Postman แบบสร้าง request เองได้ทันที:

1. เลือก POST และใส่ `http://127.0.0.1:8000/gateway/recommendProduct`
2. เพิ่ม header `api-key` ให้ตรง `.env`
3. เลือก Body → raw → JSON
4. เปิด examples/recommend.json แล้วคัดลอกเนื้อหาทั้งไฟล์ใส่ Body
5. กด Send; similar/compare ใช้ endpoint และไฟล์ตัวอย่างของเส้นนั้น

ถ้ามี Postman.zip ให้แตกลงตำแหน่งเดียวกัน แล้ว Import
`postman/Recommendation-Production.postman_collection.json` ภายในโฟลเดอร์ recommendation
ตั้ง `base_url` และ `ai_api_key` ก่อนรัน Collection
Collection รวมของทั้งสองบริการอยู่ที่ `TwoHand-AI/postman/TwoHand-AI.postman_collection.json`
ชุดรวมใช้ตัวแปร `recommendation_url` / `recommendation_key` สำหรับบริการนี้

## 4. การตั้งค่าและข้อมูลที่ Backend ต้องส่ง

| ตัวแปร | ค่าเริ่มต้น/หน้าที่ |
| --- | --- |
| `AI_API_KEY` | สร้างด้วย setup_env.py; Backend ต้องส่งใน api-key |
| `BIND_ADDRESS` | 127.0.0.1 รับเฉพาะเครื่องเดียวกัน |
| `API_PORT` | 8000 |
| `CPU_THREADS` | 2 |
| `MAX_CONCURRENT_REQUESTS` | 2; งานเต็มจะตอบ 503 |
| `COMPARE_SHORTFALL` | error; คู่เทียบไม่ครบตอบ 409 |
| `REQUIRE_PRODUCT_STATUS` | production ต้องมีสถานะสินค้า |
| `CATALOG_PATH` | ตัวเลือกสำหรับ resolve ประวัติด้วย catalog จริง ไม่ได้เติม candidates ให้เอง |

Backend ต้องส่ง candidates, สถานะสินค้า, รายละเอียดสินค้า และประวัติ/ความนิยมที่มีจริงตาม contract
ระบบไม่โหลดข้อมูล QA ใน data/ เป็น catalog production โดยอัตโนมัติ
การใช้ปัจจัยภาพต้องส่ง image embeddings ที่มาจาก encoder เดียวกัน การส่ง URL ภาพอย่างเดียวไม่เปิดการจัดอันดับด้วยภาพ
หากใช้ CATALOG_PATH กับ Docker ให้วางไฟล์จริงใน runtime-data/ และระบุ path ใน container เช่น `/app/runtime-data/catalog.json`

หาก Backend อยู่คนละเครื่อง ให้ตั้ง BIND_ADDRESS เป็น private IP ที่เหมาะสม พร้อม firewall/TLS ตามโครงสร้างของทีม
อย่าฝัง API key ในหน้าเว็บฝั่ง browser ให้ Backend เป็นผู้เรียกบริการ
`/docs` และ `/openapi.json` ไม่เปิดใน production; OpenAPI และ contract ฉบับเต็มอยู่ใน Docs-Deployment.zip

## 5. ติดตั้งแบบไม่ใช้ Docker

เส้นทางที่ตรวจแล้วคือ Python 3.12 / Linux x86_64 / CPU

Linux:

```bash
python3.12 scripts/install.py
.venv/bin/python scripts/serve.py
```

Windows PowerShell:

```powershell
py -3.12 scripts/install.py
.\.venv\Scripts\python.exe scripts\serve.py
```

ตัวติดตั้งสร้าง .venv, ติดตั้ง dependencies, สร้าง .env และดาวน์โหลดโมเดล
หลังติดตั้งครั้งแรก เปิดครั้งต่อไปด้วย scripts/serve.py ผ่าน Python ใน .venv ได้เลย
ตัวรัน Windows มีให้ แต่ยังไม่ได้ยืนยันบน Windows native จริง

หากต้องการแยกขั้นตอนดาวน์โหลด:

```bash
python3.12 scripts/install.py --skip-model
.venv/bin/python scripts/download_model.py
.venv/bin/python scripts/download_model.py --offline
```

`--offline` ตรวจไฟล์ที่มีอยู่; `--force` ใช้ดาวน์โหลด/ซ่อมใหม่เมื่อ checksum ไม่ตรง
ไฟล์ model-source.json และ model-checksums.json ล็อก revision และ SHA-256 ของโมเดลไว้

## 6. Tests และการแก้ปัญหา

ติดตั้งเครื่องมือทดสอบแล้วรันด้วย Python ของ .venv:

```bash
python3.12 scripts/install.py --with-tests
.venv/bin/python scripts/verify.py
.venv/bin/python scripts/verify_live.py
```

verify.py รันทดสอบรวม real Semantic tests ส่วน verify_live.py เปิด API ชั่วคราวและตรวจ HTTP จริง
ผลชุดส่งมอบวันที่ 15 กันยายน 2026: 58 tests และ 22 HTTP checks ผ่าน
Reports.zip เก็บหลักฐานเดิม; การเพิ่ม README รอบนี้ไม่ได้รันทดสอบโมเดลใหม่

| อาการ | ตรวจอะไร |
| --- | --- |
| 401 | api-key หาย/ผิด หรือใช้คีย์ของอีกบริการ |
| 422 | JSON ไม่ตรง schema หรือขาด product_status ใน production |
| 409 จาก compare | คู่เทียบไม่ครบตามกฎ; ดู examples/compare_shortfall.json |
| 503 | งานเต็มหรือโมเดลยังไม่พร้อม; ตรวจ /ready และ log |
| Missing model / checksum mismatch | รัน downloader ผ่าน .venv หรือดู log ขั้นตอน build |
| เชื่อมจากเครื่องอื่นไม่ได้ | BIND_ADDRESS, IP, พอร์ต, firewall และ reverse proxy |

การทดสอบที่ผ่านมาไม่ได้ยืนยัน Docker containers/Gateway บนเซิร์ฟเวอร์ SE หรือคุณภาพการแนะนำบนผู้ใช้จริง
ต้องตรวจบนเครื่องปลายทางและใช้ข้อมูลจริงก่อนรับมอบระบบรวม

## 7. ใช้คู่กับ Duplicate และชุดไฟล์เสริม

Recommendation.zip รันเดี่ยวได้โดยไม่ต้องมี Reports/Docs/Postman
เมื่อต้องการ Compose รวม ให้แตก Recommendation.zip, Duplicate.zip และ Docs-Deployment.zip
ลงโฟลเดอร์แม่เดียวกัน ให้รวมเป็น TwoHand-AI เดียว แล้วใช้คำสั่งจาก README ของโฟลเดอร์บนสุด

Standalone ใช้ AI_API_KEY จาก `recommendation/.env`
Compose รวมใช้ RECOMMENDATION_API_KEY จาก `TwoHand-AI/.env` ซึ่งเป็นคนละไฟล์กัน
เอกสารเพิ่มเติม: Docs-Deployment.zip; ผลทดสอบ: Reports.zip; Collection: Postman.zip
