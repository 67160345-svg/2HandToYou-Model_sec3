@echo off
call "%~dp0run_production.bat"
