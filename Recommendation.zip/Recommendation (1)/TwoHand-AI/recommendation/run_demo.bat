@echo off
echo This release uses the real semantic service. Starting run_production.bat.
call "%~dp0run_production.bat"
