@echo off
setlocal

rem Install the pinned TwoHand-AI Recommendation runtime.
cd /d "%~dp0"

where py >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python launcher was not found.
    echo Install Python 3.12 and enable the Python Launcher, then run this file again.
    exit /b 1
)

set "PYTHON_VERSION="
for /f "delims=" %%V in ('py -3.12 -c "import sys; print(sys.version_info.major, sys.version_info.minor)" 2^>nul') do set "PYTHON_VERSION=%%V"
if not "%PYTHON_VERSION%"=="3 12" (
    echo [ERROR] Python 3.12 was not found.
    echo Install Python 3.12, then run this file again.
    exit /b 1
)

echo [INFO] Using Python 3.12.
echo [INFO] Installing TwoHand-AI Recommendation dependencies...
py -3.12 scripts\install.py %*
if errorlevel 1 (
    echo [ERROR] Installation failed.
    exit /b 1
)

echo.
echo [OK] Installation completed.
echo [INFO] Start the service with: run_production.bat
exit /b 0
