# Model provenance and license

This source distribution downloads, but does not bundle, the pretrained model
[sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2](https://huggingface.co/sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2)
from the Sentence Transformers project. The upstream model metadata identifies its license as Apache-2.0.
After downloading, the upstream README is in `models/semantic/README.md`; the license text is in `docs/APACHE-2.0.txt`.

The exact source revision is recorded in `model-source.json` and per-file SHA-256 hashes in
`model-checksums.json` (copied to `models/semantic/model-manifest.json` after installation). The model has not been fine-tuned on 2HandToYou customer data.
This notice applies to the downloaded model; it does not invent a license for the original project source or uploaded dataset.

Implementation references:

- [SentenceTransformer loading and local_files_only](https://www.sbert.net/docs/package_reference/sentence_transformer/model.html)
- [Docker Compose service configuration](https://docs.docker.com/reference/compose-file/services/)
- [Compose specification schema](https://github.com/compose-spec/compose-spec/blob/main/schema/compose-spec.json)
