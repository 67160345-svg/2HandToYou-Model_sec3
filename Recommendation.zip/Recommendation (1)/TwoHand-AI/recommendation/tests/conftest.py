import os
import pytest
from scripts.train_tfidf import train

@pytest.fixture(scope='session', autouse=True)
def baseline_artifact(tmp_path_factory):
    path = tmp_path_factory.mktemp('test-baseline')/'tfidf.json'
    train(path)
    old = os.environ.get('TFIDF_PATH')
    os.environ['TFIDF_PATH'] = str(path)
    yield path
    if old is None:
        os.environ.pop('TFIDF_PATH', None)
    else:
        os.environ['TFIDF_PATH'] = old
