"""Integration tests requiring real, complete pinned model weights."""
import json
import os
from dataclasses import replace
from pathlib import Path
import numpy as np
import pytest
from fastapi.testclient import TestClient
from app.config import Settings
from app.embedding import Encoder
from app.main import create_app
ROOT=Path(__file__).resolve().parents[1]
pytestmark=pytest.mark.skipif(os.getenv('RUN_SEMANTIC_TESTS')!='1',reason='Set RUN_SEMANTIC_TESTS=1 to require real semantic tests')

@pytest.fixture(scope='module')
def encoder():
    return Encoder(Settings(model_name=str(ROOT/'models/semantic'),embedding_cache_size=2,encode_batch_size=2))

def test_real_thai_similarity_and_cache_eviction(encoder):
    scores=encoder.similarities(['โทรศัพท์มือถือ'],['สมาร์ตโฟน','เก้าอี้ไม้','รองเท้าวิ่ง'])
    assert scores.shape==(1,3) and np.isfinite(scores).all()
    assert scores[0,0]>scores[0,1]
    assert len(encoder.cache)<=2
    again=encoder.similarities(['โทรศัพท์มือถือ'],['สมาร์ตโฟน','เก้าอี้ไม้','รองเท้าวิ่ง'])
    np.testing.assert_allclose(scores,again,atol=1e-6)

def test_long_description_uses_tail_and_matches_direct_short_encoding(encoder):
    text='โทรศัพท์มือถือ Apple'
    direct=encoder.model.encode([text],normalize_embeddings=True,show_progress_bar=False)
    np.testing.assert_allclose(encoder._semantic_encode([text]),direct,atol=1e-5)
    prefix='โทรศัพท์มือถือ '*50
    vectors=encoder._semantic_encode([prefix+'เก้าอี้ไม้ '*50,prefix+'รองเท้าวิ่ง '*50])
    assert np.isfinite(vectors).all()
    assert not np.allclose(vectors[0],vectors[1],atol=1e-4)

def test_production_routes_with_real_model(encoder):
    key='real-model-test-only-key-123456'
    settings=Settings(environment='production',api_key=key,model_name=str(ROOT/'models/semantic'))
    with TestClient(create_app(settings,encoder=encoder)) as client:
        assert client.get('/ready').json()=={'status':'ok','engine':'semantic'}
        for name,endpoint,field,count in [('recommend','recommendProduct','product_recommend',10),('cold_start','recommendProduct','product_recommend',10),('similar','similarProduct','product_recommend',10),('compare','compareProduct','product_compare',3)]:
            r=client.post('/gateway/'+endpoint,json=json.loads((ROOT/f'examples/{name}.json').read_text()),headers={'api-key':key})
            assert r.status_code==200,r.text
            assert r.headers['X-AI-Engine']=='semantic'
            items=r.json()[field]
            assert len(items)==count
            assert all(p['product_status']=='Active' for p in items)
            assert len({p['product_id'] for p in items})==count

def test_missing_model_fails_instead_of_falling_back(tmp_path):
    with pytest.raises(RuntimeError,match='Incomplete local semantic model'):
        Encoder(Settings(model_name=str(tmp_path)))
