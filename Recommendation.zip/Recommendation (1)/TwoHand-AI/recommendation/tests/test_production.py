import asyncio
import json
import os
import threading
from dataclasses import replace
from pathlib import Path
import numpy as np
import pytest
from fastapi.testclient import TestClient
from app.config import Settings
from app.engine import RecommendationService
from app.main import create_app
from app.middleware import RequestGuard
from app.schemas import Product, RecommendRequest

ROOT = Path(__file__).resolve().parents[1]
KEY = 'test-only-key-not-for-deployment-1234'

class ControlledEncoder:
    kind = 'controlled_test'
    def similarities(self, queries, products):
        return np.asarray([[float(q == p) for p in products] for q in queries])

@pytest.fixture
def settings():
    return Settings(environment='production', api_key=KEY, require_status=True, max_concurrent_requests=1)

@pytest.fixture
def client(settings):
    with TestClient(create_app(settings, encoder=ControlledEncoder()), raise_server_exceptions=False) as client:
        yield client

def test_auth_precedes_body_parse(client):
    r = client.post('/gateway/recommendProduct', content=b'{not-json', headers={'Content-Type':'application/json'})
    assert r.status_code == 401
    assert r.headers['X-Request-ID']
    assert r.headers['Cache-Control'] == 'no-store'

def test_validation_does_not_echo_payload(client):
    r = client.post('/gateway/recommendProduct', json={'product':'PRIVATE-DATA'}, headers={'api-key':KEY})
    assert r.status_code == 422
    assert 'PRIVATE-DATA' not in r.text

@pytest.mark.parametrize('headers,body,status', [
    ({'Content-Type':'text/plain'}, '{}', 415),
    ({'Content-Type':'application/json','Content-Encoding':'gzip'}, '{}', 415),
    ({'Content-Type':'application/json'}, '{bad', 422),
    ({'Content-Type':'application/json','Content-Length':'8000001'}, '{}', 413),
])
def test_bad_requests(client, headers, body, status):
    response=client.post('/gateway/recommendProduct', content=body, headers={'api-key':KEY,**headers})
    assert response.status_code==status

def test_production_docs_disabled_and_liveness(client):
    assert client.get('/docs').status_code==404
    assert client.get('/openapi.json').status_code==404
    assert client.get('/live').json()=={'status':'alive'}
    assert client.get('/ready').status_code==200

def test_busy_keeps_health_responsive_and_releases_slot(settings):
    entered, release = threading.Event(), threading.Event()
    class BlockingEncoder(ControlledEncoder):
        def similarities(self, q, p):
            entered.set()
            if not release.wait(5): raise RuntimeError('test timed out')
            return super().similarities(q,p)
    with TestClient(create_app(settings, encoder=BlockingEncoder())) as c:
        payload=json.loads((ROOT/'examples/similar.json').read_text())
        responses=[]
        worker=threading.Thread(target=lambda:responses.append(c.post('/gateway/similarProduct',json=payload,headers={'api-key':KEY})))
        worker.start()
        try:
            assert entered.wait(3)
            busy=c.post('/gateway/similarProduct',json=payload,headers={'api-key':KEY})
            assert busy.status_code==503 and busy.headers['Retry-After']=='1'
            assert c.get('/ready').status_code==200
        finally:
            release.set();worker.join(timeout=5)
        assert responses[0].status_code==200
        assert c.post('/gateway/similarProduct',json=payload,headers={'api-key':KEY}).status_code==200

def test_inference_failure_does_not_leak_and_releases_slot(settings):
    class FailingEncoder(ControlledEncoder):
        def similarities(self,q,p):raise RuntimeError('SECRET-MODEL-PATH')
    with TestClient(create_app(settings,encoder=FailingEncoder()),raise_server_exceptions=False) as c:
        payload=json.loads((ROOT/'examples/similar.json').read_text())
        for _ in range(2):
            r=c.post('/gateway/similarProduct',json=payload,headers={'api-key':KEY})
            assert r.status_code==500 and 'SECRET' not in r.text and r.headers['X-Request-ID']

def test_body_limits_timeout_disconnect_and_duplicate_keys(settings):
    async def scenario(events, headers, expected, delay=0):
        async def target(scope,receive,send):
            await receive()
            await send({'type':'http.response.start','status':200,'headers':[]})
            await send({'type':'http.response.body','body':b'{}'})
        guard=RequestGuard(target,replace(settings,max_body_bytes=1024,body_timeout_seconds=.02))
        out=[]
        queue=list(events)
        async def receive():
            if delay:await asyncio.sleep(delay)
            return queue.pop(0)
        async def send(message):out.append(message)
        scope={'type':'http','method':'POST','path':'/gateway/recommendProduct','headers':headers}
        await guard(scope,receive,send)
        statuses=[m['status'] for m in out if m['type']=='http.response.start']
        assert statuses==expected
        assert not guard.slots.locked()
    standard=[(b'content-type',b'application/json'),(b'api-key',KEY.encode())]
    asyncio.run(scenario([{'type':'http.request','body':b'x'*700,'more_body':True},{'type':'http.request','body':b'x'*700}],standard,[413]))
    asyncio.run(scenario([{'type':'http.request','body':b'{}'}],standard,[408],.05))
    asyncio.run(scenario([{'type':'http.disconnect'}],standard,[]))
    asyncio.run(scenario([],standard+[(b'api-key',KEY.encode())],[401]))
    asyncio.run(scenario([{'type':'http.request','body':b'{}'}],standard+[(b'content-length',b'3')],[400]))

@pytest.mark.parametrize('changes', [
    {'environment':'prodution'}, {'environment':'production','api_key':''},
    {'environment':'production','engine':'tfidf','api_key':KEY},
    {'environment':'production','api_key':KEY,'model_local_only':False},
    {'max_concurrent_requests':0}, {'body_timeout_seconds':float('nan')},
])
def test_configuration_fails_closed(changes):
    with pytest.raises(ValueError):replace(Settings(),**changes).validate()

def test_boolean_and_numeric_fields_are_strict():
    base={'product_id':'A','product_name':'A'}
    for key,value in [('price',True),('product_deteriorate',False),('popularity_score','0.5'),('historical_clicks',True)]:
        with pytest.raises(ValueError):Product.model_validate({**base,key:value})

def test_image_and_structured_signals_are_used_without_echoing_vectors():
    vector={'model_id':'image-model-v1','values':[1.,0.,0.,0.,0.,0.,0.,0.]}
    base={'product_name':'same text','product_status':'Active','category':'Phone','brand':'A','price':100.,'condition':'Good','region_code':'TH-10','image_embedding':vector,'historical_clicks':10,'historical_purchases':1}
    h=Product.model_validate({**base,'product_id':'H'})
    a=Product.model_validate({**base,'product_id':'A'})
    b=Product.model_validate({**base,'product_id':'B','image_embedding':{'model_id':'image-model-v1','values':[0.,1.,0.,0.,0.,0.,0.,0.]}})
    warnings=set()
    scores=RecommendationService.enrich_recommendation([a,b],[.5,.5],[(h,1.)],warnings)
    assert scores[0]>scores[1]
    assert not warnings
    dumped=a.model_dump()
    assert 'image_embedding' not in dumped and 'historical_clicks' not in dumped
    mismatched=b.model_copy(update={'image_embedding':b.image_embedding.model_copy(update={'model_id':'different-version'})})
    RecommendationService.enrich_recommendation([mismatched],[.5],[(h,1.)],warnings)
    assert 'incompatible_image_embeddings' in warnings

def test_price_condition_region_each_changes_score():
    base={'product_id':'A','product_name':'Phone','price':100.,'condition':'Good','region_code':'TH-10'}
    h=Product.model_validate(base)
    for change in [{'price':1000.},{'condition':'Poor'},{'region_code':'TH-20'}]:
        other=Product.model_validate({**base,**change,'product_id':'B'})
        scores=RecommendationService.enrich_recommendation([h,other],[.5,.5],[(h,1.)],set())
        assert scores[0]>scores[1]
