"""Offline semantic encoding with bounded chunk batches and a bounded text cache."""
import json
from collections import OrderedDict
from pathlib import Path
from threading import RLock
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer


class Encoder:
    def __init__(self, settings):
        self.kind = settings.engine
        self.lock = RLock()
        self.cache = OrderedDict()
        self.batch_size = settings.encode_batch_size
        self.cache_size = settings.embedding_cache_size
        if self.kind == "semantic":
            import torch
            from sentence_transformers import SentenceTransformer
            path = Path(settings.model_name)
            if settings.model_local_only and not (path / "modules.json").is_file():
                raise RuntimeError("Incomplete local semantic model. Run python scripts/download_model.py first.")
            torch.set_num_threads(settings.cpu_threads)
            self.model = SentenceTransformer(
                settings.model_name, revision=settings.model_revision,
                local_files_only=settings.model_local_only, trust_remote_code=False,
                device="cpu", model_kwargs={"use_safetensors": True},
            )
            self.model.eval()
            special = self.model.tokenizer.num_special_tokens_to_add(pair=False)
            self.chunk_tokens = self.model.max_seq_length - special
            if self.chunk_tokens < 8:
                raise RuntimeError("Model sequence length is too small")
            self.dimension = self.model.get_sentence_embedding_dimension()
            # Warm-up must succeed before readiness is reported.
            self._semantic_encode(["ตรวจสอบการทำงานของโมเดล"])
        else:
            path = Path(settings.tfidf_path)
            if not path.exists():
                raise RuntimeError("Missing test TF-IDF artifact. Run python scripts/train_tfidf.py")
            state = json.loads(path.read_text(encoding="utf-8"))
            self.model = TfidfVectorizer(analyzer="char", ngram_range=(2, 5),
                                         vocabulary=state["vocabulary"], dtype=np.float32)
            self.model.idf_ = np.asarray(state["idf"], dtype=np.float32)

    def _encode_missing(self, texts):
        import torch
        pooled = np.zeros((len(texts), self.dimension), dtype=np.float32)
        batch, owners = [], []

        def flush():
            if not batch:
                return
            # Encode token chunks directly: decode/re-tokenize can change Thai
            # tokens and silently truncate pieces of a long description.
            features = self.model.tokenizer.pad(batch, padding=True, return_tensors="pt")
            with torch.inference_mode():
                vectors = self.model(features)["sentence_embedding"]
                vectors = torch.nn.functional.normalize(vectors, p=2, dim=1)
            np.add.at(pooled, owners, vectors.cpu().float().numpy())
            batch.clear()
            owners.clear()

        tokenizer = self.model.tokenizer.backend_tokenizer
        tokenizer.no_truncation()
        tokenizer.no_padding()
        for index, text in enumerate(texts):
            encoded = tokenizer.encode(text, add_special_tokens=False)
            encoded.truncate(self.chunk_tokens, stride=0)
            chunks = [encoded, *encoded.overflowing]
            for chunk in chunks:
                processed = tokenizer.post_process(chunk, add_special_tokens=True)
                batch.append({"input_ids": processed.ids, "attention_mask": processed.attention_mask,
                              "token_type_ids": processed.type_ids})
                owners.append(index)
                if len(batch) >= self.batch_size:
                    flush()
        flush()
        pooled /= np.maximum(np.linalg.norm(pooled, axis=1, keepdims=True), 1e-12)
        if not np.isfinite(pooled).all():
            raise RuntimeError("Model returned non-finite embeddings")
        return pooled

    def _semantic_encode(self, texts):
        with self.lock:
            # Request-local references keep results available even when a request
            # is larger than the cross-request cache capacity.
            available = {t: self.cache[t] for t in texts if t in self.cache}
            missing = list(dict.fromkeys(t for t in texts if t not in available))
            if missing:
                for text, vector in zip(missing, self._encode_missing(missing)):
                    available[text] = vector
            result = np.stack([available[t] for t in texts])
            for text in texts:
                if self.cache_size:
                    self.cache[text] = available[text]
                    self.cache.move_to_end(text)
                    while len(self.cache) > self.cache_size:
                        self.cache.popitem(last=False)
            return result

    def similarities(self, query_texts, product_texts):
        if not query_texts or not product_texts:
            return np.zeros((len(query_texts), len(product_texts)), dtype=np.float32)
        if self.kind == "semantic":
            vectors = self._semantic_encode(query_texts + product_texts)
            result = vectors[:len(query_texts)] @ vectors[len(query_texts):].T
        else:
            result = (self.model.transform(query_texts) @ self.model.transform(product_texts).T).toarray()
        return np.clip(result, 0, 1)
