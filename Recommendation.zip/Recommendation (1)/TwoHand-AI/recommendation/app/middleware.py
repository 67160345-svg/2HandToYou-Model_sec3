"""Bound request admission and body reads before FastAPI JSON parsing."""
import asyncio
import json
import logging
import secrets
import time
import uuid
from starlette.responses import JSONResponse

LOG = logging.getLogger("recommendation.requests")
ROUTES = {"/gateway/recommendProduct", "/gateway/similarProduct", "/gateway/compareProduct"}


class RequestGuard:
    def __init__(self, app, settings):
        self.app, self.settings = app, settings
        self.slots = asyncio.Semaphore(settings.max_concurrent_requests)

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        request_id = uuid.uuid4().hex
        scope.setdefault("state", {})["request_id"] = request_id
        start, status = time.perf_counter(), 500
        admitted = False
        started = False

        async def tracked_send(message):
            nonlocal status, started
            if message["type"] == "http.response.start":
                started = True
                status = message["status"]
                message = dict(message)
                message["headers"] = list(message.get("headers", [])) + [
                    (b"x-request-id", request_id.encode()), (b"cache-control", b"no-store")]
            await send(message)

        async def error(code, http_status, headers=None):
            await JSONResponse({"detail": {"code": code}}, status_code=http_status,
                               headers=headers)(scope, receive, tracked_send)

        try:
            path = scope.get("path", "")
            if path not in ROUTES or scope["method"] != "POST":
                return await self.app(scope, receive, tracked_send)
            raw_headers = scope.get("headers", [])
            headers = dict(raw_headers)
            keys = [v for k, v in raw_headers if k == b"api-key"]
            expected = self.settings.api_key.encode()
            if expected and (len(keys) != 1 or not secrets.compare_digest(keys[0], expected)):
                return await error("invalid_api_key", 401)
            if headers.get(b"content-encoding", b"identity").lower() != b"identity":
                return await error("unsupported_content_encoding", 415)
            content_type = headers.get(b"content-type", b"").split(b";", 1)[0].strip().lower()
            if content_type != b"application/json":
                return await error("unsupported_media_type", 415)
            lengths = [v for k, v in raw_headers if k == b"content-length"]
            expected_length = None
            if lengths:
                if len(lengths) != 1 or not lengths[0].isdigit():
                    return await error("invalid_content_length", 400)
                expected_length = int(lengths[0])
                if expected_length > self.settings.max_body_bytes:
                    return await error("body_too_large", 413)
            if self.slots.locked():
                return await error("service_busy", 503, {"Retry-After": "1"})
            await self.slots.acquire()
            admitted = True
            body = bytearray()

            async def read_body():
                while True:
                    message = await receive()
                    if message["type"] == "http.disconnect":
                        return "disconnected"
                    chunk = message.get("body", b"")
                    if len(body) + len(chunk) > self.settings.max_body_bytes:
                        return "oversize"
                    body.extend(chunk)
                    if not message.get("more_body", False):
                        return "complete"

            try:
                result = await asyncio.wait_for(read_body(), timeout=self.settings.body_timeout_seconds)
            except asyncio.TimeoutError:
                return await error("request_body_timeout", 408)
            if result == "disconnected":
                status = 499
                return
            if result == "oversize":
                return await error("body_too_large", 413)
            if expected_length is not None and expected_length != len(body):
                return await error("content_length_mismatch", 400)
            delivered = False

            async def replay():
                nonlocal delivered
                if not delivered:
                    delivered = True
                    return {"type": "http.request", "body": bytes(body), "more_body": False}
                return await receive()

            await self.app(scope, replay, tracked_send)
        except Exception as exc:
            # No raw request, key, model path, querystring or exception message in logs.
            LOG.error(json.dumps({"event": "request_error", "request_id": request_id,
                                  "exception_type": type(exc).__name__}))
            if started:
                raise
            await error("internal_error", 500)
        finally:
            if admitted:
                self.slots.release()
            LOG.info(json.dumps({"event": "request", "request_id": request_id,
                                 "route": scope.get("path") if scope.get("path") in ROUTES else "other",
                                 "status": status, "duration_ms": round((time.perf_counter()-start)*1000, 2)}))
