import json
import logging
import secrets
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import Depends, FastAPI, Security, HTTPException, Request, Response
from fastapi.security import APIKeyHeader
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from app.config import Settings
from app.middleware import RequestGuard
from app.embedding import Encoder
from app.engine import ContractError, RecommendationService
from app.schemas import Product, RecommendRequest, SimilarRequest, RecommendResponse, CompareResponse



def create_app(settings=None, encoder=None):
    settings = settings or Settings.from_env()
    settings.validate()

    @asynccontextmanager
    async def lifespan(app):
        app.state.ready = False
        shared_encoder = encoder or Encoder(settings)
        catalog = []
        if settings.catalog_path:
            raw = json.loads(Path(settings.catalog_path).read_text(encoding="utf-8"))
            catalog = [Product.model_validate(p) for p in raw]
            if len({p.product_id for p in catalog}) != len(catalog):
                raise ValueError("Catalog must have unique product_id")
        app.state.service = RecommendationService(shared_encoder,settings,catalog)
        app.state.ready = True
        try:
            yield
        finally:
            app.state.ready = False
            del app.state.service

    app = FastAPI(title="2HandToYou Recommendation API",version="2.0.0",lifespan=lifespan,
                  docs_url="/docs" if settings.environment != "production" else None,
                  redoc_url=None,openapi_url="/openapi.json" if settings.environment != "production" else None)
    app.add_middleware(RequestGuard, settings=settings)

    @app.exception_handler(ContractError)
    async def contract_error(request, exc):
        return JSONResponse(status_code=exc.status,content={"detail":exc.detail})

    @app.exception_handler(RequestValidationError)
    async def validation_error(request, exc):
        # Do not echo raw user payload or internal exception contexts.
        return JSONResponse(status_code=422,content={"detail":{"code":"invalid_payload","errors":[
            {"loc":list(e["loc"]),"msg":e["msg"],"type":e["type"]} for e in exc.errors()]}})

    @app.exception_handler(Exception)
    async def internal_error(request, exc):
        logging.getLogger("ai").error("Processing failure: %s",type(exc).__name__)
        return JSONResponse(status_code=500,content={"detail":{"code":"internal_error"}})

    key_header = APIKeyHeader(name="api-key", scheme_name="InternalAPIKey", auto_error=False)

    def authorize(api_key: str | None = Security(key_header)):
        if settings.api_key and not secrets.compare_digest((api_key or "").encode(),settings.api_key.encode()):
            raise HTTPException(status_code=401,detail={"code":"invalid_api_key"})

    def annotate(response, service, warnings, mode):
        response.headers["X-AI-Engine"] = service.encoder.kind
        response.headers["X-AI-Mode"] = mode
        if warnings:
            response.headers["X-AI-Warnings"] = ",".join(sorted(warnings))

    @app.get("/live")
    async def live():
        return {"status": "alive"}

    @app.get("/ready")
    @app.get("/health")
    async def health(request: Request):
        if not getattr(request.app.state, "ready", False):
            return JSONResponse(status_code=503, content={"status": "not_ready"})
        return {"status":"ok", "engine":request.app.state.service.encoder.kind}

    @app.post("/gateway/recommendProduct",response_model=RecommendResponse,response_model_exclude_none=True,
              dependencies=[Depends(authorize)])
    def recommend(payload: RecommendRequest, request: Request, response: Response):
        service = request.app.state.service
        result,warnings,mode = service.recommend(payload)
        annotate(response,service,warnings,mode)
        return {"product_recommend":result}

    @app.post("/gateway/similarProduct",response_model=RecommendResponse,response_model_exclude_none=True,
              dependencies=[Depends(authorize)])
    def similar(payload: SimilarRequest, request: Request, response: Response):
        service = request.app.state.service
        result,warnings,mode = service.similar(payload)
        annotate(response,service,warnings,mode)
        return {"product_recommend":result}

    @app.post("/gateway/compareProduct",response_model=CompareResponse,response_model_exclude_none=True,
              dependencies=[Depends(authorize)])
    def compare(payload: SimilarRequest, request: Request, response: Response):
        service = request.app.state.service
        result,warnings,mode = service.compare(payload)
        annotate(response,service,warnings,mode)
        return {"product_compare":result}

    return app


app = create_app()
