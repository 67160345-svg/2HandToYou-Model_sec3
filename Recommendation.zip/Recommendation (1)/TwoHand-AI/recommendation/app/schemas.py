from datetime import datetime
from typing import Annotated, Literal
from pydantic import BaseModel, ConfigDict, Field, StrictBool, field_validator, model_validator

Text = Annotated[str, Field(min_length=1, max_length=200, strict=True)]
UnitScore = Annotated[float, Field(ge=0, le=1, allow_inf_nan=False, strict=True)]


class ImageEmbedding(BaseModel):
    model_config = ConfigDict(extra="forbid")
    model_id: Text
    values: list[Annotated[float, Field(allow_inf_nan=False, strict=True)]] = Field(min_length=8, max_length=2048)

    @field_validator("values")
    @classmethod
    def nonzero(cls, value):
        # Bound norms to make normalization numerically stable and reject empty signals.
        if max(abs(x) for x in value) > 1_000_000 or not any(abs(x) > 1e-12 for x in value):
            raise ValueError("Image embedding must be a nonzero bounded vector")
        return value


class Product(BaseModel):
    # Unknown fields are discarded, never echoed back (e.g. seller PII).
    model_config = ConfigDict(extra="ignore", str_strip_whitespace=True)
    product_id: Text
    product_name: Annotated[str, Field(min_length=1, max_length=500)]
    product_description: Annotated[str, Field(max_length=4000)] = ""
    product_deteriorate: Annotated[float, Field(ge=0, le=100, allow_inf_nan=False, strict=True)] | None = None
    product_have_boxset: StrictBool | None = None
    product_image: Annotated[str, Field(max_length=2000)] | None = None
    category: Text | None = None
    subcategory: Text | None = None
    product_type: Text | None = None
    brand: Text | None = None
    region_code: Annotated[str, Field(pattern=r"^TH-[0-9]{2}$")] | None = None
    # Upstream must use the same image encoder/version for matching vectors.
    # These internal ranking features are never returned in Product output.
    image_embedding: ImageEmbedding | None = Field(default=None, exclude=True)
    historical_clicks: Annotated[int, Field(ge=0, le=1_000_000_000, strict=True)] | None = Field(default=None, exclude=True)
    historical_purchases: Annotated[int, Field(ge=0, le=1_000_000_000, strict=True)] | None = Field(default=None, exclude=True)
    condition: Text | None = None
    price: Annotated[float, Field(gt=0, allow_inf_nan=False, strict=True)] | None = None
    popularity_score: UnitScore | None = None
    product_status: Literal["Active", "Sold", "Inactive", "Deleted"] | None = None

    @field_validator("product_status", mode="before")
    @classmethod
    def status_case(cls, value):
        return value.strip().title() if isinstance(value, str) else value


class History(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    product_id: Text
    viewed_at: datetime | None = None

    @field_validator("viewed_at")
    @classmethod
    def timezone_required(cls, value):
        if value is not None and value.tzinfo is None:
            raise ValueError("Timestamp must include timezone, e.g. Z or +07:00")
        return value


class Activity(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    type: Literal["view", "click", "add_to_cart", "search", "wishlist", "favorite", "purchase"]
    product_id: Text | None = None
    keyword: Annotated[str, Field(min_length=1, max_length=500)] | None = None
    timestamp: datetime | None = None

    @field_validator("timestamp")
    @classmethod
    def timezone_required(cls, value):
        return History.timezone_required(value)

    @model_validator(mode="after")
    def required_signal(self):
        if self.type == "search" and not self.keyword:
            raise ValueError("search requires keyword")
        if self.type != "search" and not self.product_id:
            raise ValueError("non-search activity requires product_id")
        return self


class CatalogRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    product: list[Product] = Field(max_length=5000)

    @model_validator(mode="after")
    def unique_products(self):
        seen = {}
        unique = []
        for product in self.product:
            if product.product_id in seen:
                if product != seen[product.product_id]:
                    raise ValueError("Conflicting duplicate product_id in product")
                continue
            seen[product.product_id] = product
            unique.append(product)
        self.product = unique
        return self


class RecommendRequest(CatalogRequest):
    history: list[History] = Field(default_factory=list, max_length=1000)
    activity: list[Activity] = Field(default_factory=list, max_length=1000)
    # Optional enrichment for history IDs absent from candidate product list.
    history_product: list[Product] = Field(default_factory=list, max_length=1000)

    @model_validator(mode="after")
    def unique_history_products(self):
        seen = {}
        for p in self.history_product:
            if p.product_id in seen and p != seen[p.product_id]:
                raise ValueError("Conflicting duplicate history_product ID")
            seen[p.product_id] = p
        return self


class SimilarRequest(CatalogRequest):
    this_product: Product


class RankedProduct(Product):
    score: UnitScore
    reason: str


class ComparedProduct(RankedProduct):
    price_difference: float | None = None
    deteriorate_difference: float | None = None
    boxset_match: bool | None = None


class RecommendResponse(BaseModel):
    product_recommend: list[RankedProduct]


class CompareResponse(BaseModel):
    product_compare: list[ComparedProduct]
