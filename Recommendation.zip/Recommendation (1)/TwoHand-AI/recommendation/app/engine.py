from datetime import datetime, timezone
import numpy as np


class ContractError(Exception):
    def __init__(self, code, message, status=422, **details):
        self.status = status
        self.detail = {"code": code, "message": message, **details}
        super().__init__(message)


def norm(value):
    return (value or "").strip().casefold()


def product_text(p):
    return " | ".join(str(x) for x in [p.product_name, p.product_description,
                       p.category, p.subcategory, p.product_type, p.brand, p.condition] if x)


def type_key(p):
    # Use the SAME attribute on both products; never equate unrelated taxonomic levels.
    for name in ("product_type", "subcategory", "category"):
        if getattr(p, name):
            return name, norm(getattr(p, name))
    return None, None


class RecommendationService:
    def __init__(self, encoder, settings, catalog=None):
        self.encoder = encoder
        self.settings = settings
        self.catalog = {p.product_id: p for p in (catalog or [])}

    def candidates(self, products, exclude=None):
        warnings, valid = set(), []
        for p in products:
            if p.product_id in (exclude or set()):
                continue
            if p.product_status is None:
                if self.settings.require_status:
                    raise ContractError("missing_product_status", "Every candidate needs product_status")
                warnings.add("status_not_supplied_upstream_must_filter")
            elif p.product_status != "Active":
                continue
            valid.append(p)
        return valid, warnings

    @staticmethod
    def ranked(products, scores, limit, reason):
        order = sorted(range(len(products)), key=lambda i: (-float(scores[i]), products[i].product_id))
        return [{**products[i].model_dump(exclude_none=True),
                 "score": round(float(np.clip(scores[i], 0, 1)), 6), "reason": reason}
                for i in order[:limit]]

    def cold_start(self, products, warnings):
        if any(p.popularity_score is None for p in products):
            raise ContractError("missing_popularity", "Cold Start requires popularity_score for every eligible product")
        return self.ranked(products, [p.popularity_score for p in products], 10,
                           "จัดอันดับตามความนิยมที่ backend ส่งมา"), warnings, "cold_start"

    def recommend(self, req):
        purchased = {a.product_id for a in req.activity if a.type == "purchase"}
        candidates, warnings = self.candidates(req.product, purchased)
        if not candidates:
            return [], warnings, "empty_catalog"
        lookup = {**self.catalog, **{p.product_id:p for p in req.history_product},
                  **{p.product_id:p for p in req.product}}
        signals = {}
        profile_signals = {}
        now = datetime.now(timezone.utc)
        weights = {"view":1., "click":2., "search":3., "add_to_cart":4., "wishlist":4., "favorite":4., "purchase":5.}

        def add(text, weight, when, product=None):
            if when:
                age_days = max(0, (now - when).total_seconds() / 86400)
                weight *= 0.5 ** (min(age_days, 365) / 30)
            # Repeated events must not amplify the same signal without bound.
            signals[text] = max(signals.get(text, 0), weight)
            if product is not None:
                old = profile_signals.get(product.product_id)
                if old is None or weight > old[1]:
                    profile_signals[product.product_id] = (product, weight)

        for h in req.history:
            if h.product_id in lookup:
                add(product_text(lookup[h.product_id]), 1., h.viewed_at, lookup[h.product_id])
            else:
                warnings.add("unresolved_history_ids")
        for a in req.activity:
            if a.type == "search":
                add(a.keyword, weights[a.type], a.timestamp)
            elif a.product_id in lookup:
                add(product_text(lookup[a.product_id]), weights[a.type], a.timestamp, lookup[a.product_id])
            else:
                warnings.add("unresolved_history_ids")
        if not signals:
            if req.history or req.activity:
                warnings.add("no_resolvable_interest_using_popularity")
            return self.cold_start(candidates, warnings)
        selected = sorted(signals.items(), key=lambda pair: (-pair[1], pair[0]))[:100]
        sims = self.encoder.similarities([t for t,_ in selected], [product_text(p) for p in candidates])
        scores = np.average(sims, axis=0, weights=[w for _,w in selected])
        profiles = sorted(profile_signals.values(), key=lambda row: (-row[1], row[0].product_id))[:100]
        scores = self.enrich_recommendation(candidates, scores, profiles, warnings)
        return self.ranked(candidates, scores, 10, "จัดอันดับจากความสนใจ พฤติกรรม และข้อมูลสินค้าที่มีร่วมกัน"), warnings, "personalized"

    @staticmethod
    def enrich_recommendation(candidates, text_scores, profiles, warnings):
        """Use only observed features; absent features are omitted and reported.

        Weights are explicit baseline policy, not learned accuracy claims.
        Image vectors are supplied by the trusted Backend, not fetched by URL.
        """
        result = []
        count_max = {field: max((getattr(p, field) or 0 for p in candidates), default=0)
                     for field in ("historical_clicks", "historical_purchases")}
        for candidate, text_score in zip(candidates, text_scores):
            terms = [(0.65, float(text_score))]
            for field, weight in (("category", .08), ("brand", .05), ("price", .07),
                                  ("condition", .03), ("region_code", .02), ("image_embedding", .05)):
                matches, factors = [], []
                right = getattr(candidate, field)
                if right is not None:
                    for history, factor in profiles:
                        left = getattr(history, field)
                        if left is None:
                            continue
                        if field == "price":
                            similarity = 1 - abs(left - right) / max(left, right)
                        elif field == "image_embedding":
                            if left.model_id != right.model_id or len(left.values) != len(right.values):
                                warnings.add("incompatible_image_embeddings")
                                continue
                            a, b = np.asarray(left.values, dtype=np.float64), np.asarray(right.values, dtype=np.float64)
                            similarity = float(np.clip((a @ b) / (np.linalg.norm(a) * np.linalg.norm(b)), 0, 1))
                        else:
                            similarity = float(norm(left) == norm(right))
                        matches.append(similarity)
                        factors.append(factor)
                if matches:
                    terms.append((weight, float(np.average(matches, weights=factors))))
                else:
                    warnings.add("missing_ranking_" + field)
            for field in count_max:
                value = getattr(candidate, field)
                if value is None:
                    warnings.add("missing_ranking_" + field)
                else:
                    score = np.log1p(value) / np.log1p(count_max[field]) if count_max[field] else 0.
                    terms.append((.025, float(score)))
            result.append(sum(w * value for w, value in terms) / sum(w for w, _ in terms))
        return result

    def similar(self, req):
        candidates, warnings = self.candidates(req.product, {req.this_product.product_id})
        if not candidates:
            return [], warnings, "similar"
        query = req.this_product
        scores = self.encoder.similarities([product_text(query)], [product_text(p) for p in candidates])[0]
        combined = []
        for p, semantic in zip(candidates, scores):
            terms = [(0.75, float(semantic))]
            for field, weight in (("category",0.15),("subcategory",0.10)):
                left, right = norm(getattr(query,field)), norm(getattr(p,field))
                if left and right:
                    terms.append((weight,float(left == right)))
                else:
                    warnings.add("missing_category_text_only_component")
            combined.append(sum(w*v for w,v in terms)/sum(w for w,_ in terms))
        return self.ranked(candidates, combined, 10, "ชื่อ รายละเอียด และหมวดหมู่ใกล้เคียงสินค้าปัจจุบัน"), warnings, "similar"

    def compare(self, req):
        query = req.this_product
        field, target = type_key(query)
        if field is None:
            raise ContractError("missing_product_type", "compareProduct needs product_type, subcategory, or category")
        if query.product_deteriorate is None and query.product_have_boxset is None:
            raise ContractError("missing_comparison_attribute", "this_product needs product_deteriorate or product_have_boxset")
        candidates, warnings = self.candidates(req.product, {query.product_id})
        candidates = [p for p in candidates if norm(getattr(p,field)) == target and
                      ((query.product_deteriorate is not None and p.product_deteriorate is not None) or
                       (query.product_have_boxset is not None and p.product_have_boxset is not None))]
        if len(candidates) < 3:
            if self.settings.compare_shortfall == "error":
                raise ContractError("insufficient_comparable_products", "Need 3 distinct eligible same-type products", 409,
                                    available_count=len(candidates), required_count=3)
            warnings.add("fewer_than_three_comparable_products")
        if not candidates:
            return [], warnings, "compare"
        text_scores = self.encoder.similarities([product_text(query)], [product_text(p) for p in candidates])[0]
        scores = []
        for p, semantic in zip(candidates, text_scores):
            terms = [(0.4, float(semantic))]
            if query.product_deteriorate is not None and p.product_deteriorate is not None:
                terms.append((0.5,1-abs(query.product_deteriorate-p.product_deteriorate)/100))
            if query.product_have_boxset is not None and p.product_have_boxset is not None:
                terms.append((0.1,float(query.product_have_boxset == p.product_have_boxset)))
            scores.append(sum(w*v for w,v in terms)/sum(w for w,_ in terms))
        result = self.ranked(candidates,scores,3,"ประเภทเดียวกัน จัดอันดับจากข้อความ สภาพ และกล่องที่มีข้อมูลร่วมกัน")
        by_id = {p.product_id:p for p in candidates}
        for item in result:
            p = by_id[item["product_id"]]
            item["price_difference"] = round(p.price-query.price,2) if p.price is not None and query.price is not None else None
            item["deteriorate_difference"] = p.product_deteriorate-query.product_deteriorate if p.product_deteriorate is not None and query.product_deteriorate is not None else None
            item["boxset_match"] = p.product_have_boxset == query.product_have_boxset if p.product_have_boxset is not None and query.product_have_boxset is not None else None
        return result, warnings, "compare"
