"""Validated environment configuration for one model per API process."""
from dataclasses import dataclass
from pathlib import Path
import os


def env_bool(name, default):
    value = os.getenv(name, str(default)).strip().lower()
    if value not in {"true", "false"}:
        raise ValueError(f"{name} must be true or false")
    return value == "true"


@dataclass(frozen=True)
class Settings:
    engine: str = "semantic"
    model_name: str = "models/semantic"
    model_revision: str | None = None
    model_local_only: bool = True
    tfidf_path: str = "models/tfidf.json"
    catalog_path: str = ""
    api_key: str = ""
    environment: str = "development"
    require_status: bool = True
    compare_shortfall: str = "error"
    max_body_bytes: int = 8_000_000
    body_timeout_seconds: float = 15.0
    max_concurrent_requests: int = 2
    encode_batch_size: int = 16
    embedding_cache_size: int = 4096
    cpu_threads: int = 2

    @classmethod
    def from_env(cls):
        key = os.getenv("AI_API_KEY", "")
        key_file = os.getenv("AI_API_KEY_FILE", "")
        if key_file:
            if key:
                raise ValueError("Set only one of AI_API_KEY and AI_API_KEY_FILE")
            key = Path(key_file).read_text(encoding="utf-8").strip()
        return cls(
            engine=os.getenv("AI_ENGINE", "semantic"),
            model_name=os.getenv("MODEL_NAME", cls.model_name),
            model_revision=os.getenv("MODEL_REVISION") or None,
            model_local_only=env_bool("MODEL_LOCAL_ONLY", True),
            tfidf_path=os.getenv("TFIDF_PATH", cls.tfidf_path),
            catalog_path=os.getenv("CATALOG_PATH", ""), api_key=key,
            environment=os.getenv("APP_ENV", "development"),
            require_status=env_bool("REQUIRE_PRODUCT_STATUS", True),
            compare_shortfall=os.getenv("COMPARE_SHORTFALL", "error"),
            max_body_bytes=int(os.getenv("MAX_BODY_BYTES", cls.max_body_bytes)),
            body_timeout_seconds=float(os.getenv("BODY_TIMEOUT_SECONDS", cls.body_timeout_seconds)),
            max_concurrent_requests=int(os.getenv("MAX_CONCURRENT_REQUESTS", cls.max_concurrent_requests)),
            encode_batch_size=int(os.getenv("ENCODE_BATCH_SIZE", cls.encode_batch_size)),
            embedding_cache_size=int(os.getenv("EMBEDDING_CACHE_SIZE", cls.embedding_cache_size)),
            cpu_threads=int(os.getenv("CPU_THREADS", cls.cpu_threads)),
        )

    def validate(self):
        if self.environment not in {"development", "test", "production"}:
            raise ValueError("APP_ENV must be development, test or production")
        if self.engine not in {"semantic", "tfidf"}:
            raise ValueError("AI_ENGINE must be semantic or tfidf")
        if self.compare_shortfall not in {"error", "return_available"}:
            raise ValueError("COMPARE_SHORTFALL must be error or return_available")
        for name, low, high in [
            ("max_body_bytes", 1024, 64_000_000), ("body_timeout_seconds", 0.01, 120),
            ("max_concurrent_requests", 1, 16), ("encode_batch_size", 1, 128),
            ("embedding_cache_size", 0, 100_000), ("cpu_threads", 1, 64),
        ]:
            if not low <= getattr(self, name) <= high:
                raise ValueError(f"{name} must be between {low} and {high}")
        if self.api_key and (not self.api_key.isascii() or any(c.isspace() for c in self.api_key)):
            raise ValueError("AI_API_KEY must be ASCII without whitespace")
        if self.environment == "production":
            if len(self.api_key) < 24 or not self.require_status:
                raise ValueError("Production needs AI_API_KEY (24+ characters) and REQUIRE_PRODUCT_STATUS=true")
            if self.engine != "semantic" or not self.model_local_only:
                raise ValueError("Production requires semantic engine and MODEL_LOCAL_ONLY=true")
