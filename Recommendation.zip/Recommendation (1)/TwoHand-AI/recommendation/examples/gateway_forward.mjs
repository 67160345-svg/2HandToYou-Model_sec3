// Node.js 18+ integration helper. Call after the existing Gateway authorizes the user.
// This file does not replace the partner's caller/referer/permission checks.
const allowed = new Set(['recommendProduct', 'similarProduct', 'compareProduct']);

export async function callRecommendationAI(endpoint, payload) {
  if (!allowed.has(endpoint)) throw new Error('Unsupported AI endpoint');
  const base = process.env.RECOMMENDATION_AI_URL;
  const key = process.env.RECOMMENDATION_AI_KEY;
  const timeout = Number(process.env.RECOMMENDATION_AI_TIMEOUT_MS || 120000);
  if (!base || !key || key.length < 24 || !Number.isFinite(timeout) || timeout < 1000 || timeout > 300000) {
    throw new Error('AI service configuration missing or invalid');
  }
  const url = new URL(base);
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) throw new Error('Invalid AI service URL');
  url.pathname = url.pathname.replace(/\/$/, '') + `/gateway/${endpoint}`;
  url.search = ''; url.hash = '';
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {'Content-Type': 'application/json', 'api-key': key},
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(timeout), redirect: 'error'
    });
    const body = await response.json();
    return {
      status: response.status, body,
      warnings: response.headers.get('X-AI-Warnings'),
      requestId: response.headers.get('X-Request-ID'),
      retryAfter: response.headers.get('Retry-After')
    };
  } catch (error) {
    const timedOut = error.name === 'TimeoutError' || error.name === 'AbortError';
    return {status: timedOut ? 504 : 502,
      body: {detail: {code: timedOut ? 'ai_timeout' : 'ai_unavailable'}}};
  }
}
