"""Download pinned semantic weights separately, verify known checksums, then install atomically."""
import argparse
import hashlib
import json
import re
import shutil
import tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()


def verify(output, expected):
    for name, sha in expected['sha256'].items():
        path = (output / name).resolve()
        if not path.is_relative_to(output.resolve()) or not path.is_file() or digest(path) != sha:
            raise RuntimeError(f'Model file missing or checksum mismatch: {name}. Re-run with --force to repair.')
    import numpy as np
    import torch
    from sentence_transformers import SentenceTransformer
    torch.set_num_threads(2)
    model = SentenceTransformer(str(output), local_files_only=True, device='cpu',
                                trust_remote_code=False, model_kwargs={'use_safetensors': True})
    vectors = model.encode(['โทรศัพท์มือถือ', 'สมาร์ตโฟน', 'เก้าอี้ไม้'],
                           normalize_embeddings=True, show_progress_bar=False)
    if vectors.shape != (3, 384) or not np.isfinite(vectors).all():
        raise RuntimeError('Model encoding check failed')
    if float(vectors[0] @ vectors[1]) <= float(vectors[0] @ vectors[2]):
        raise RuntimeError('Thai semantic smoke check failed')
    return {'dimension': 384, 'files_verified': len(expected['sha256']),
            'phone_smartphone_similarity': float(vectors[0] @ vectors[1]),
            'phone_chair_similarity': float(vectors[0] @ vectors[2])}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT / 'models/semantic')
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--offline', '--verify-only', action='store_true', help='Verify existing files without downloading')
    mode.add_argument('--force', action='store_true', help='Repair/replace only after new files pass verification')
    args = parser.parse_args()
    source = json.loads((ROOT / 'model-source.json').read_text())
    expected = json.loads((ROOT / 'model-checksums.json').read_text())
    if (expected['model_id'], expected['revision']) != (source['model_id'], source['revision']):
        raise RuntimeError('model-source.json and model-checksums.json must identify the same model revision')
    if not re.fullmatch('[0-9a-f]{40}', source['revision']):
        raise RuntimeError('Model revision must be a pinned 40-character commit hash')
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    from filelock import FileLock
    with FileLock(str(output) + '.lock', timeout=0):
        if args.offline or (not args.force and (output / 'model-manifest.json').exists()):
            print(json.dumps({'status': 'verified_existing', **verify(output, expected)}, indent=2))
            return
        from huggingface_hub import snapshot_download
        # Keep partial transfers when interrupted so re-running can resume.
        download_cache = output.parent / '.download-cache' / source['revision']
        print('Downloading pinned model (about 485 MB) and verifying SHA-256...', flush=True)
        snapshot_download(repo_id=source['model_id'], revision=source['revision'],
                          allow_patterns=list(expected['sha256']), local_dir=download_cache, max_workers=2)
        with tempfile.TemporaryDirectory(prefix='.model-stage-', dir=output.parent) as tmp:
            stage = Path(tmp) / 'semantic'
            stage.mkdir()
            # Copy only the expected files, not transient downloader metadata.
            for name in expected['sha256']:
                target = (stage / name).resolve()
                if not target.is_relative_to(stage.resolve()):
                    raise RuntimeError('Unsafe path in model checksum manifest')
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(download_cache / name, target)
            check = verify(stage, expected)
            (stage / 'model-manifest.json').write_text(json.dumps(expected, indent=2) + '\n')
            (stage / '.gitkeep').touch()
            backup = Path(tmp) / 'previous'
            if output.exists():
                output.rename(backup)
            try:
                stage.rename(output)
            except Exception:
                if backup.exists():
                    backup.rename(output)
                raise
        shutil.rmtree(download_cache, ignore_errors=True)
        print(json.dumps({'status': 'installed', **check}, indent=2))


if __name__ == '__main__':
    try:
        main()
    except ImportError as error:
        raise SystemExit(f'Missing dependency: {error.name}. Run python scripts/install.py first.') from None
