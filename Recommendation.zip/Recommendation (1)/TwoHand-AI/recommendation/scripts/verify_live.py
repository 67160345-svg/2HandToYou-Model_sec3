"""Start a temporary real production API and run HTTP/Postman checks, then stop it."""
import json
import os
import secrets
import socket
import subprocess
import sys
import time
from pathlib import Path
from urllib.request import urlopen
ROOT=Path(__file__).resolve().parents[1]


def main():
    with socket.socket() as s:
        s.bind(('127.0.0.1',0))
        port=s.getsockname()[1]
    env={**os.environ,'AI_API_KEY':secrets.token_hex(32),'AI_API_KEY_FILE':'',
         'APP_ENV':'production','AI_ENGINE':'semantic','MODEL_LOCAL_ONLY':'true',
         'MODEL_NAME':str(ROOT/'models/semantic'),'REQUIRE_PRODUCT_STATUS':'true',
         'CATALOG_PATH':'','BIND_ADDRESS':'127.0.0.1','API_PORT':str(port),
         'HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1'}
    url=f'http://127.0.0.1:{port}'
    (ROOT/'reports').mkdir(exist_ok=True)
    with (ROOT/'reports/server_test.log').open('w') as log:
        server=subprocess.Popen([sys.executable,'scripts/serve.py'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
        try:
            deadline=time.monotonic()+120
            while True:
                if server.poll() is not None:raise RuntimeError('API failed startup; see reports/server_test.log')
                try:
                    with urlopen(url+'/ready',timeout=1) as r:
                        if json.load(r).get('engine')=='semantic':break
                except Exception:
                    if time.monotonic()>deadline:raise RuntimeError('API startup timed out')
                    time.sleep(.2)
            subprocess.run([sys.executable,'scripts/smoke_test.py','--url',url],cwd=ROOT,env=env,check=True)
            if (ROOT/'node_modules/newman').exists():
                subprocess.run(['node','scripts/run_postman.cjs'],cwd=ROOT,env={**env,'AI_BASE_URL':url},check=True)
            else:
                print('Postman CLI not run: optional npm ci is required; HTTP checks completed.')
        finally:
            server.terminate()
            try:server.wait(timeout=20)
            except subprocess.TimeoutExpired:server.kill();server.wait()


if __name__=='__main__':main()
