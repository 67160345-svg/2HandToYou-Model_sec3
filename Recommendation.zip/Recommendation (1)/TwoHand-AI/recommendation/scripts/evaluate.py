"""Evaluate actual rankings; distinguish hand-written smoke labels from real data."""
import argparse
import json
import math
import sys
import time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def metrics(predicted, relevant, k):
    if k < 1:
        raise ValueError('k must be positive')
    relevant = set(relevant)
    ranked = list(dict.fromkeys(predicted))[:k]
    hits = [int(p in relevant) for p in ranked]
    dcg = sum(hit / math.log2(i + 2) for i, hit in enumerate(hits))
    ideal = sum(1 / math.log2(i + 2) for i in range(min(k, len(relevant))))
    return {f'precision@{k}': sum(hits) / k,
            f'recall@{k}': sum(hits) / len(relevant) if relevant else 0.,
            f'ndcg@{k}': dcg / ideal if ideal else 0.,
            'mrr': next((1 / (i + 1) for i, hit in enumerate(hits) if hit), 0.)}


def main():
    from app.config import Settings
    from app.embedding import Encoder
    from app.engine import RecommendationService
    from app.schemas import RecommendRequest, SimilarRequest
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--cases', type=Path, default=ROOT / 'examples/evaluation_cases.json')
    p.add_argument('--output', type=Path, default=ROOT / 'reports/semantic_evaluation.json')
    args = p.parse_args()
    settings = Settings(engine='semantic', model_name=str(ROOT/'models/semantic'), model_local_only=True)
    service = RecommendationService(Encoder(settings), settings)
    dataset = json.loads(args.cases.read_text(encoding='utf-8'))
    result = {'engine': 'semantic', 'label_origin': dataset.get('label_origin', 'unspecified'), 'cases': []}
    for case in dataset['cases']:
        endpoint = case['endpoint']
        if endpoint not in {'recommend', 'similar', 'compare'}:
            raise ValueError('Unknown endpoint in evaluation cases')
        request_cls = RecommendRequest if endpoint == 'recommend' else SimilarRequest
        payload = request_cls.model_validate(case['payload'])
        start = time.perf_counter()
        ranked, warnings, mode = getattr(service, endpoint)(payload)
        ids = [r['product_id'] for r in ranked]
        k = 3 if endpoint == 'compare' else 10
        result['cases'].append({'name': case['name'], 'endpoint': endpoint, 'ranked_ids': ids,
                                'mode': mode, 'warnings': sorted(warnings),
                                'duration_ms': round((time.perf_counter()-start)*1000, 2),
                                **metrics(ids, case['relevant_ids'], k)})
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print('Evaluation written:', args.output)


if __name__ == '__main__':
    main()
