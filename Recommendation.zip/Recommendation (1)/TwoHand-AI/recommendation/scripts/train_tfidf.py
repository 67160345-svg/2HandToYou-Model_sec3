"""Create a lexical baseline for regression tests only, never production."""
import argparse
import json
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
ROOT = Path(__file__).resolve().parents[1]


def train(output, catalog=None):
    products = json.loads((catalog or ROOT / 'examples/catalog.json').read_text(encoding='utf-8'))
    texts = [' | '.join(str(p.get(k) or '') for k in ['product_name', 'product_description', 'category', 'subcategory', 'brand', 'condition']) for p in products]
    vectorizer = TfidfVectorizer(analyzer='char', ngram_range=(2, 5)).fit(texts)
    state = {'purpose': 'lexical regression-test baseline; not semantic production',
             'vocabulary': {k: int(v) for k, v in vectorizer.vocabulary_.items()},
             'idf': vectorizer.idf_.tolist()}
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(state, ensure_ascii=False), encoding='utf-8')
    return state


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, default=ROOT / 'models/tfidf.json')
    p.add_argument('--catalog', type=Path)
    args = p.parse_args()
    train(args.output, args.catalog)
    print('Created test-only TF-IDF artifact:', args.output)
