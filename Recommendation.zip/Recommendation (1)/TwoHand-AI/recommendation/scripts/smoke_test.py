"""Run real HTTP checks against the semantic service. Never sends to a partner by default."""
import argparse
import json
import os
import statistics
import time
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen
ROOT = Path(__file__).resolve().parents[1]


def run(url, key):
    checks = []
    def call(path, payload=None, auth=key, expected=200, count=None, field=None, name=None):
        body = json.dumps(payload, ensure_ascii=False).encode() if payload is not None else None
        request = Request(url.rstrip('/') + path, data=body, headers={'Content-Type':'application/json','api-key':auth})
        start = time.perf_counter()
        try:
            response = urlopen(request, timeout=120)
        except HTTPError as exc:
            response = exc
        with response:
            status, headers = response.status, response.headers
            data = json.loads(response.read())
        elapsed = round((time.perf_counter()-start)*1000,2)
        if status != expected or (count is not None and len(data.get(field, [])) != count):
            raise RuntimeError(f'{name or path}: expected HTTP {expected}, got {status}; {data}')
        if not headers.get('X-Request-ID'):
            raise RuntimeError('Missing X-Request-ID')
        if expected == 200 and payload is not None and headers.get('X-AI-Engine') != 'semantic':
            raise RuntimeError('API did not use semantic engine')
        checks.append({'name':name or path,'status':status,'duration_ms':elapsed,
                       'engine':headers.get('X-AI-Engine'),'mode':headers.get('X-AI-Mode')})
        return data
    health = call('/health')
    if health != {'status':'ok','engine':'semantic'}:
        raise RuntimeError('Semantic readiness check failed')
    call('/live')
    call('/ready')
    for name, endpoint, field, count, status in [
        ('recommend','recommendProduct','product_recommend',10,200),
        ('cold_start','recommendProduct','product_recommend',10,200),
        ('similar','similarProduct','product_recommend',10,200),
        ('compare','compareProduct','product_compare',3,200),
        ('compare_shortfall','compareProduct',None,None,409),
    ]:
        payload = json.loads((ROOT/'examples'/f'{name}.json').read_text(encoding='utf-8'))
        data = call('/gateway/'+endpoint,payload,expected=status,count=count,field=field,name=name)
        if field:
            items = data[field]
            ids = [p['product_id'] for p in items]
            if len(ids) != len(set(ids)) or any(p.get('product_status') != 'Active' for p in items):
                raise RuntimeError(f'{name}: duplicates or non-active result')
            if 'this_product' in payload and payload['this_product']['product_id'] in ids:
                raise RuntimeError(f'{name}: returned main product')
    call('/gateway/recommendProduct',{'product':[]},auth='',expected=401,name='missing_key')
    call('/gateway/recommendProduct',{'product':[]},auth='wrong',expected=401,name='wrong_key')
    invalid=json.loads((ROOT/'examples/cold_start.json').read_text(encoding='utf-8'))
    del invalid['product'][1]['product_status']
    call('/gateway/recommendProduct',invalid,expected=422,name='missing_status')
    call('/docs',expected=404)
    sample=json.loads((ROOT/'examples/similar.json').read_text(encoding='utf-8'))
    durations=[]
    for i in range(10):
        call('/gateway/similarProduct',sample,name=f'warm_similar_{i+1}',count=10,field='product_recommend')
        durations.append(checks[-1]['duration_ms'])
    return {'status':'passed','engine':'semantic','checks':checks,
            'latency_sample':{'kind':'10 sequential warm requests using QA examples; not a capacity benchmark',
                              'candidate_count':len(sample['product']), 'median_ms':statistics.median(durations),
                              'max_ms':max(durations)}}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--url',default='http://127.0.0.1:8000')
    p.add_argument('--output',type=Path,default=ROOT/'reports/http_smoke.json')
    args=p.parse_args()
    key=os.getenv('AI_API_KEY','')
    if not key and (ROOT/'.env').is_file():
        for line in (ROOT/'.env').read_text(encoding='utf-8').splitlines():
            if line.startswith('AI_API_KEY='):
                key=line.split('=',1)[1].strip().strip("\"'")
                break
    if len(key)<24:p.error('Set AI_API_KEY or create .env first')
    result=run(args.url,key)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f'PASS {len(result["checks"])} real HTTP checks; semantic engine')
    print(json.dumps(result['latency_sample']))


if __name__=='__main__':main()
