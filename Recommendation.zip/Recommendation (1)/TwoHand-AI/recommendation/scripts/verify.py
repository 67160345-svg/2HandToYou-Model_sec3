"""Require all tests, including real semantic integration tests; write JUnit evidence."""
import os
import subprocess
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if __name__=='__main__':
    (ROOT/'reports').mkdir(exist_ok=True)
    env={**os.environ,'APP_ENV':'test','RUN_SEMANTIC_TESTS':'1','HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1'}
    result=subprocess.run([sys.executable,'-m','pytest','-q','--junitxml=reports/tests.xml'],cwd=ROOT,env=env)
    raise SystemExit(result.returncode)
