"""Create an isolated runtime, install pinned CPU dependencies and download the model."""
import argparse
import os
import subprocess
import sys
import venv
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--skip-model', action='store_true', help='Install dependencies only; API cannot start until the model is downloaded')
    parser.add_argument('--with-tests', action='store_true', help='Also install Python test/data-preparation tools')
    args = parser.parse_args()
    if sys.version_info[:2] != (3, 12):
        parser.error('Use Python 3.12: py -3.12 scripts/install.py (Windows) or python3.12 scripts/install.py (Linux)')
    target = ROOT / '.venv'
    if target.exists() and not target.is_dir():
        parser.error('.venv must be a directory')
    if target.exists() and not (target / 'pyvenv.cfg').exists() and any(target.iterdir()):
        parser.error('.venv exists but is not a virtual environment; choose a clean project directory')
    if not (target / 'pyvenv.cfg').exists():
        print('Creating .venv...', flush=True)
        venv.EnvBuilder(with_pip=True).create(target)
    python = target / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    version = subprocess.check_output([str(python), '-c', 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")'], text=True).strip()
    if version != '3.12':
        parser.error('Existing .venv uses another Python version. Rename it and rerun with Python 3.12.')
    def run(*arguments):
        subprocess.run([str(python), *arguments], cwd=ROOT, check=True)
    # Separate indexes avoid pulling a CUDA-enabled torch build.
    run('-m', 'pip', 'install', '-r', 'requirements-cpu.txt')
    run('-m', 'pip', 'install', '-r', 'requirements.lock')
    if args.with_tests:
        run('-m', 'pip', 'install', '-r', 'requirements-test.txt')
    run('-m', 'pip', 'check')
    run('scripts/setup_env.py')
    if not args.skip_model:
        run('scripts/download_model.py')
    print('Setup complete. Start with .venv/bin/python scripts/serve.py (Linux) or .venv\\Scripts\\python.exe scripts\\serve.py (Windows).')


if __name__ == '__main__':
    try:
        main()
    except subprocess.CalledProcessError as error:
        raise SystemExit(f'Setup stopped (exit {error.returncode}). Fix the error above and run install.py again.') from None
