"""Rebuild a QA catalog and audit from the supplied synthetic workbook; never train from fabricated labels."""
import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path
from openpyxl import load_workbook
ROOT=Path(__file__).resolve().parents[1]


def records(sheet):
    rows=sheet.iter_rows(values_only=True)
    header=None
    for row in rows:
        if row and row[0]=='Dataset_ID':
            header=list(row);break
    if header is None:raise ValueError(f'Cannot find Dataset_ID header in {sheet.title}')
    for row in rows:
        if row[0] is not None:yield dict(zip(header,row))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('source',type=Path,nargs='?',default=ROOT/'data/source_recommendation.xlsx')
    p.add_argument('--output-dir',type=Path,default=ROOT/'data/prepared')
    args=p.parse_args()
    book=load_workbook(args.source,read_only=True,data_only=True)
    mapping={'Product_ID':'product_id','Product_Name':'product_name','Category':'category','Subcategory':'subcategory',
             'Brand':'brand','Condition':'condition','Price':'price','Popularity_Score':'popularity_score','Product_Status':'product_status'}
    catalog={};pairs=set();duplicates=0;conflicts=Counter();rows=0
    for row in records(book['05_Recommendation_Dataset']):
        rows+=1
        pair=(row['Buyer_ID'],row['Product_ID'])
        duplicates+=pair in pairs;pairs.add(pair)
        product={dst:row[src] for src,dst in mapping.items() if row.get(src) is not None}
        if product['product_id'] in catalog:
            previous=catalog[product['product_id']]
            for field in set(previous)|set(product):
                if previous.get(field)!=product.get(field):conflicts[field]+=1
        else:catalog[product['product_id']]=product
    if conflicts:
        raise ValueError(f'Conflicting product records; resolve before preparing catalog: {dict(conflicts)}')
    behaviors=list(records(book['04_Buyer_Behavior']))
    audit={'source_kind':'synthetic QA data, not real marketplace observations',
           'source_filename':args.source.name,'sha256':hashlib.sha256(args.source.read_bytes()).hexdigest(),
           'recommendation_rows':rows,'unique_catalog_products':len(catalog),'duplicate_buyer_product_pairs':duplicates,
           'behavior_snapshots':len(behaviors),'catalog_status_counts':dict(Counter(p['product_status'] for p in catalog.values())),
           'not_fabricated':['product_description','product_deteriorate','product_have_boxset','region_code','image_embedding'],
           'warnings':['Synthetic scores/Expected/Pass columns are not measured model performance.',
                       'Buyer-specific similarity and behavior counts were not converted into global product attributes.',
                       'Missing comparison attributes must be supplied by the real Backend.']}
    args.output_dir.mkdir(parents=True,exist_ok=True)
    (args.output_dir/'catalog.json').write_text(json.dumps(list(catalog.values()),ensure_ascii=False,indent=2),encoding='utf-8')
    with (args.output_dir/'behavior_snapshots.jsonl').open('w',encoding='utf-8') as out:
        for row in behaviors:out.write(json.dumps(row,ensure_ascii=False,default=str)+'\n')
    (args.output_dir/'data_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(audit,ensure_ascii=False,indent=2))
    if duplicates:raise SystemExit('Duplicate Buyer_ID + Product_ID found; audit failed.')


if __name__=='__main__':main()
