"""Start the real API using .env, with one worker and offline inference."""
import os
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)
from dotenv import load_dotenv
load_dotenv(ROOT / '.env', override=False)
os.environ.setdefault('APP_ENV', 'production')
os.environ['HF_HUB_OFFLINE'] = '1'
os.environ['TRANSFORMERS_OFFLINE'] = '1'
os.environ['TOKENIZERS_PARALLELISM'] = 'false'
from app.config import Settings
Settings.from_env().validate()
import uvicorn
if __name__ == '__main__':
    uvicorn.run('app.main:app', host=os.getenv('BIND_ADDRESS', '127.0.0.1'),
                port=int(os.getenv('API_PORT', '8000')), workers=1,
                proxy_headers=False, access_log=False, log_config='deploy/logging.json',
                timeout_keep_alive=5, timeout_graceful_shutdown=120)
