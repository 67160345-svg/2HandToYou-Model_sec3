import io
import json
import sqlite3
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import numpy as np
import pytest
from PIL import Image
from fastapi.testclient import TestClient
from main import create_app
from modules.settings import Settings
from modules.sqlite_store import SQLiteStore
from modules.scoring_engine import evaluate_baseline_decision

KEY = 'test-only-' + 'a'*40
CONTEXT = dict(product_id='product-1', listing_id='listing-1', seller_id='seller-1', category='camera')

def picture(seed=0):
    image = np.clip(180+np.random.default_rng(seed).normal(0,24,(600,800,3)),0,255).astype(np.uint8)
    buf=io.BytesIO(); Image.fromarray(image).save(buf,format='PNG');return buf.getvalue()

def features(mask=True):
    return dict(phash='8abcdef012345678', fg_vector=[1.0]+[0.0]*511,
        bg_vector=[1.0]+[0.0]*511, has_segmentation=mask, segmentation_reason='No product mask')

@pytest.fixture
def service(tmp_path):
    cfg=Settings(api_key=KEY,database_path=str(tmp_path/'db.sqlite3'))
    store=SQLiteStore(cfg.database_path)
    app=create_app(cfg, extractor=lambda image:features(),store=store,detectors=lambda image:{})
    with TestClient(app) as client:
        yield client,store,cfg

def post(client,context=None,data=None,key=KEY):
    return client.post('/gateway/detectDuplicateProduct',headers={'api-key':key} if key else {},
            files={'image':('product.png', data or picture(),'image/png')}, data=context or CONTEXT)

def count(store):
    with store.connect() as db:
        return db.execute('SELECT COUNT(*) FROM reference_images').fetchone()[0]

@pytest.mark.parametrize('key',[None,'wrong-key'])
def test_rejects_key_before_parsing(service,key):
    client,store,_=service
    r=client.post('/gateway/detectDuplicateProduct',content=b'invalid multipart',headers={'api-key':key} if key else {})
    assert r.status_code==401
    assert count(store)==0

def test_retry_is_stable_and_stores_once(service):
    client,store,_=service
    a=post(client);b=post(client)
    assert a.status_code==200 and a.json()==b.json()
    assert a.json()['analysis']['decision']=='UNIQUE'
    assert count(store)==1

def test_spam_distinct_listing_has_nonzero_score(service):
    client,store,_=service
    post(client)
    r=post(client,{**CONTEXT,'listing_id':'listing-2','product_id':'product-2'}).json()
    assert r['analysis']['decision']=='SPAM' and r['is_repetition']
    assert r['repetition_rate']==1.0
    assert count(store)==1

def test_other_seller_duplicate_not_spam(service):
    client,store,_=service;post(client)
    r=post(client,{**CONTEXT,'listing_id':'listing-2','product_id':'product-2','seller_id':'seller-2'}).json()
    assert r['analysis']['decision']=='DUPLICATE'
    assert r['matched_product']['product_id']=='product-1'
    assert count(store)==1

def test_same_listing_edit_excluded(service):
    client,store,_=service;post(client)
    r=post(client,{**CONTEXT,'product_id':'product-edit'},data=picture(10)).json()
    assert r['analysis']['decision']=='UNIQUE'

def test_restart_preserves_reference_and_retry(service):
    client,store,cfg=service;a=post(client).json()
    app=create_app(cfg,extractor=lambda image:features(),store=SQLiteStore(cfg.database_path),detectors=lambda image:{})
    with TestClient(app) as restarted:
        assert post(restarted).json()==a
        assert post(restarted,{**CONTEXT,'product_id':'p2','listing_id':'l2'}).json()['analysis']['decision']=='SPAM'

def test_concurrent_retry_is_stable(service):
    client,store,_=service
    with ThreadPoolExecutor(max_workers=2) as pool:
        responses=list(pool.map(lambda _:post(client),range(2)))
    accepted=[r.json() for r in responses if r.status_code==200]
    assert accepted and all(r.status_code in {200,503} for r in responses)
    assert len({json.dumps(r,sort_keys=True) for r in accepted})==1
    assert count(store)==1

def test_corrupt_image_is_400(service):
    assert post(service[0],data=b'not an image').status_code==400

def test_health_and_private_docs(service):
    c=service[0]
    assert c.get('/ready').status_code==200
    assert c.get('/live').status_code==200
    assert c.get('/docs').status_code==404

def test_body_limit_checked_before_parse(service):
    r=service[0].post('/gateway/detectDuplicateProduct',content=b'x',headers={
        'api-key':KEY,'content-type':'multipart/form-data; boundary=x','content-length':str(12*1024*1024)})
    assert r.status_code==413

def test_dimension_limit(service):
    service[2].max_pixels=100
    assert post(service[0]).status_code==400

def test_context_length(service):
    assert post(service[0],{**CONTEXT,'seller_id':'s'*257}).status_code==422

def test_no_segmentation_review_then_hash_duplicate(tmp_path):
    cfg=Settings(api_key=KEY,database_path=str(tmp_path/'db.sqlite3'))
    app=create_app(cfg,extractor=lambda image:features(False),detectors=lambda image:{})
    with TestClient(app) as c:
        a=post(c).json();b=post(c,{**CONTEXT,'product_id':'p2','listing_id':'l2'}).json()
        assert a['analysis']['decision']=='REVIEW'
        assert b['analysis']['decision']=='SPAM'
        assert b['repetition_rate']==1.0

def test_heuristic_review_does_not_seed_reference(tmp_path):
    cfg=Settings(api_key=KEY,database_path=str(tmp_path/'db.sqlite3'));store=SQLiteStore(cfg.database_path)
    app=create_app(cfg,extractor=lambda image:features(),store=store,
        detectors=lambda image:{'screenshot':{'flagged':True,'reason':'UI'}})
    with TestClient(app) as c:
        assert post(c).json()['analysis']['decision']=='REVIEW'
        assert count(store)==0

def test_transaction_rolls_back(tmp_path):
    s=SQLiteStore(tmp_path/'db.sqlite3')
    with pytest.raises(RuntimeError):
        with s.transaction() as t:
            t.commit_result('key',{'status':'success'},{'id':'id'})
            raise RuntimeError('simulated failure')
    assert count(s)==0
    with s.transaction() as t:assert t.cached('key') is None

def test_selected_reference_scores_not_mixed():
    a={'product_id':'hash-winner','fg_vector':[0.,1.],'bg_vector':[0.,1.],'phash':'0000000000000000'}
    b={'product_id':'embedding-winner','fg_vector':[1.,0.],'bg_vector':[1.,0.],'phash':'ffffffffffffffff'}
    decision,fg,bg,phash,reason,matched=evaluate_baseline_decision([1.,0.],[1.,0.],'0000000000000000',[a,b])
    assert decision=='DUPLICATE' and matched['product_id']=='hash-winner'
    assert fg==0.0 and bg==0.0 and phash==1.0

def test_invalid_reference_is_skipped():
    valid={'product_id':'ok','fg_vector':[1.,0.],'bg_vector':[1.,0.],'phash':'0000000000000000'}
    bad={**valid,'phash':'invalid'}
    assert evaluate_baseline_decision([1.,0.],[1.,0.],'0000000000000000',[bad,valid])[0]=='DUPLICATE'

def test_unknown_store_fails(monkeypatch):
    monkeypatch.setenv('AI_API_KEY',KEY);monkeypatch.setenv('REFERENCE_STORE','typo')
    with pytest.raises(RuntimeError,match='REFERENCE_STORE'):Settings.from_env()

def test_capacity_fails_without_partial_write(tmp_path):
    cfg=Settings(api_key=KEY,database_path=str(tmp_path/'db.sqlite3'));s=SQLiteStore(cfg.database_path,max_references=1)
    app=create_app(cfg,extractor=lambda image:features(),store=s,detectors=lambda image:{})
    with TestClient(app) as c:
        assert post(c).status_code==200
        # Same listing edit needs another reference, but capacity cannot silently evict old references.
        assert post(c,data=picture(5)).status_code==503
        assert count(s)==1

def test_mask_area_uses_image_coordinates(monkeypatch):
    from types import SimpleNamespace
    from modules import feature_extractor as f
    class Masks:
        def __len__(self):return 1
        def cpu(self):return self
        def numpy(self):
            mask=np.zeros((1,320,320),dtype=np.uint8);mask[:,80:240,80:240]=1;return mask
    monkeypatch.setattr(f,'_get_detection_labels',lambda result:[])
    result=SimpleNamespace(masks=SimpleNamespace(data=Masks()))
    # 25% object, including when the input image is much larger than the network mask.
    assert f._evaluate_segmentation_support(result,320,320)[0]
    assert f._evaluate_segmentation_support(result,3000,3000)[0]

def test_sqlite_backup_integrity(service,tmp_path,monkeypatch):
    import subprocess,sys,os
    client,store,cfg=service;post(client)
    backup=tmp_path/'snapshot.sqlite3'
    subprocess.run([sys.executable,'scripts/backup.py','--output',str(backup)],
        env={**os.environ,'DATABASE_PATH':cfg.database_path,'REFERENCE_STORE':'sqlite'},check=True)
    with sqlite3.connect(backup) as db:
        assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
        assert db.execute('SELECT count(*) FROM reference_images').fetchone()[0]==1

def test_supabase_atomic_result_adapter():
    from types import SimpleNamespace
    from modules.supabase_reference_store import SupabaseStore
    calls=[]
    class Client:
        def rpc(self,name,args):
            calls.append((name,args))
            data={'duplicate_v2_ready':1,'duplicate_v2_cached':None,'duplicate_v2_candidates':[],
                  'duplicate_v2_commit':args.get('result_data')}.get(name)
            return SimpleNamespace(execute=lambda:SimpleNamespace(data=data))
    store=SupabaseStore(client=Client())
    assert store.ready()
    with store.transaction() as t:
        assert t.cached('abc') is None
        assert t.candidates(CONTEXT,features())==[]
        assert t.commit_result('abc',{'status':'success'})=={'status':'success'}
    assert calls[-1][0]=='duplicate_v2_commit'
    assert calls[-1][1]['reference_data'] is None
