"""Duplicate detection service. One worker per reference store; authenticated backend callers only."""
from contextlib import asynccontextmanager
import hashlib
import json
import logging
from pathlib import Path
import threading
from typing import Dict, Optional
from fastapi import FastAPI, File, Form, UploadFile, HTTPException
from fastapi.concurrency import run_in_threadpool
from fastapi.openapi.utils import get_openapi
from pydantic import BaseModel
from modules.settings import Settings
from modules.middleware import RequestGuard
from modules.sqlite_store import SQLiteStore, StoreCapacityError
from modules.preprocessor import calculate_quality_scores, check_image_quality, load_image_from_bytes
from modules.scoring_engine import evaluate_baseline_decision, evaluate_spam_decision
from modules.detectors import run_detectors

LOG = logging.getLogger('duplicate')
MODEL_VERSION = 'yolov8n-seg-openclip-vit-b-32-2.0.0'

class MatchedProductInfo(BaseModel):
    product_id: Optional[str] = None
    image_reference: Optional[str] = None

class SimilarityBreakdown(BaseModel):
    repetition_similarity: float
    foreground_similarity: float
    background_similarity: float
    phash_similarity: float

class AnalysisDetail(BaseModel):
    decision: str
    reason: str
    similarity_breakdown: SimilarityBreakdown
    quality_scores: Dict[str, float]

class GatewayDetectionResponse(BaseModel):
    status: str = 'success'
    is_repetition: bool
    repetition_rate: float
    matched_product: Optional[MatchedProductInfo] = None
    analysis: AnalysisDetail


def response_for(decision, reason, quality, fg=0.0, bg=0.0, phash=0.0, matched=None):
    # Similarity is a score (0..1), never a calibrated probability.
    repetition = decision in {'DUPLICATE', 'SPAM'}
    rate = max(fg, phash) if repetition else fg if decision == 'REVIEW' else 0.0
    return GatewayDetectionResponse(
        is_repetition=repetition, repetition_rate=rate,
        matched_product=MatchedProductInfo(product_id=matched.get('product_id'),
            image_reference=matched.get('image_url')) if matched and decision != 'UNIQUE' else None,
        analysis=AnalysisDetail(decision=decision, reason=reason, quality_scores=quality,
            similarity_breakdown=SimilarityBreakdown(repetition_similarity=rate,
                foreground_similarity=fg, background_similarity=bg, phash_similarity=phash))).model_dump()


def create_app(settings=None, extractor=None, store=None, detectors=None):
    # Injectable dependencies are for tests; the module app always loads real weights.
    pipeline_lock = threading.Lock()
    state = {'ready': False}

    @asynccontextmanager
    async def lifespan(app):
        cfg = settings or Settings.from_env()
        state['settings'] = cfg
        if store is not None:
            state['store'] = store
        elif cfg.store == 'sqlite':
            state['store'] = SQLiteStore(cfg.database_path, cfg.max_references)
        else:
            from modules.supabase_reference_store import SupabaseStore
            state['store'] = SupabaseStore(cfg.max_references)
        if extractor is None:
            import shutil
            if not shutil.which('tesseract'):
                raise RuntimeError('Tesseract executable missing; install tesseract-ocr')
            from modules.feature_extractor import initialize_models, extract_all_features
            await run_in_threadpool(initialize_models, cfg.cpu_threads)
            state['extractor'] = extract_all_features
        else:
            state['extractor'] = extractor
        state['detectors'] = detectors or run_detectors
        if not await run_in_threadpool(state['store'].ready):
            raise RuntimeError('Reference store is not ready')
        state['ready'] = True
        try:
            yield
        finally:
            state['ready'] = False

    app = FastAPI(title='TTT AI Duplicate Detection', version='2.0.0', lifespan=lifespan,
                  docs_url=None, redoc_url=None, openapi_url=None)
    # Settings must be validated before handling the first request, not at module import.
    class ConfiguredGuard:
        def __init__(self, app):
            self.app, self.guard = app, None
        async def __call__(self, scope, receive, send):
            if scope['type'] != 'http':
                return await self.app(scope, receive, send)
            if self.guard is None:
                self.guard = RequestGuard(self.app, state['settings'])
            return await self.guard(scope, receive, send)
    app.add_middleware(ConfiguredGuard)
    def schema():
        if app.openapi_schema:
            return app.openapi_schema
        spec = get_openapi(title=app.title, version=app.version, routes=app.routes)
        spec.setdefault('components', {}).setdefault('securitySchemes', {})['ServiceKey'] = {
            'type': 'apiKey', 'in': 'header', 'name': 'api-key'}
        endpoint = spec['paths']['/gateway/detectDuplicateProduct']['post']
        endpoint['security'] = [{'ServiceKey': []}]
        for code, description in {'400':'Invalid image', '401':'Missing or invalid service key',
                '413':'Upload exceeds limit', '415':'Unsupported request content type',
                '503':'Busy, capacity reached or model unavailable'}.items():
            endpoint['responses'][code] = {'description': description}
        app.openapi_schema = spec
        return spec
    app.openapi = schema

    @app.get('/live')
    async def live():
        return {'status': 'ok'}

    @app.get('/ready')
    @app.get('/health')
    async def ready():
        try:
            healthy = state['ready'] and await run_in_threadpool(state['store'].ready)
        except Exception:
            healthy = False
        if not healthy:
            raise HTTPException(503, 'Service not ready')
        return {'status': 'ok', 'engine': 'yolo-openclip', 'store': state['settings'].store,
                'model_version': MODEL_VERSION}

    def process(contents, filename, context):
        cfg = state['settings']
        key = hashlib.sha256(json.dumps({'version': MODEL_VERSION, 'context': context,
                'image_sha256': hashlib.sha256(contents).hexdigest()}, sort_keys=True).encode()).hexdigest()
        # YOLO and the read/decide/write cycle are serialized, while /live remains responsive.
        with pipeline_lock, state['store'].transaction() as transaction:
            cached = transaction.cached(key)
            if cached is not None:
                return cached
            try:
                img = load_image_from_bytes(contents, max_pixels=cfg.max_pixels, max_side=cfg.max_image_side)
            except ValueError as exc:
                raise HTTPException(400, 'Invalid or unsupported image') from exc
            quality = calculate_quality_scores(img)
            quality_ok, issues = check_image_quality(img)
            if not quality_ok:
                result = response_for('REVIEW', 'ภาพไม่พร้อมสำหรับ detection: ' + '; '.join(issues), quality)
                return transaction.commit_result(key, result)
            detector_results = state['detectors'](img)
            warnings = [f"{name}: {value['reason']}" for name, value in detector_results.items() if value['flagged']]
            features = state['extractor'](img)
            if len(features.get('fg_vector', [])) != 512 or len(features.get('bg_vector', [])) != 512:
                raise HTTPException(503, 'Model returned invalid feature dimensions')
            candidates = transaction.candidates(context, features)
            # Without a valid product mask, embeddings are full-frame and cannot establish physical duplicates.
            semantic_candidates = [r for r in candidates if r.get('has_segmentation', False)] if features['has_segmentation'] else []
            decision, fg, bg, phash, reason, matched = evaluate_baseline_decision(
                features['fg_vector'], features['bg_vector'], features['phash'], semantic_candidates,
                fg_threshold=0.95, review_threshold=0.70)
            # Full-frame pHash is still useful when segmentation cannot identify the product.
            hash_candidates = []
            from modules.scoring_engine import compute_phash_similarity
            for record in candidates:
                try:
                    distance, similarity = compute_phash_similarity(features['phash'], record['phash'])
                except (ValueError, TypeError, KeyError):
                    continue
                if distance <= 5:
                    hash_candidates.append((distance, record))
            if hash_candidates:
                chosen = min(hash_candidates, key=lambda pair: pair[0])[1]
                decision, fg, bg, phash, reason, matched = evaluate_baseline_decision(
                    features['fg_vector'], features['bg_vector'], features['phash'], [chosen],
                    fg_threshold=0.95, review_threshold=0.70)
            if decision == 'INVALID_DATA':
                raise HTTPException(503, 'Model returned invalid features')
            if warnings:
                decision, reason = 'REVIEW', '; '.join(warnings)
            elif not features['has_segmentation'] and not hash_candidates:
                decision = 'REVIEW'
                reason = 'ต้องตรวจสอบภาพต่อ: ' + features['segmentation_reason']
            decision, spam_reason = evaluate_spam_decision(context, decision, matched)
            if spam_reason:
                reason = spam_reason
            result = response_for(decision, reason, quality, fg, bg, phash, matched)
            # Confirmed duplicates/spam and heuristic warnings must not pollute reference images.
            record = None
            if decision == 'UNIQUE' or (decision == 'REVIEW' and not warnings and not features['has_segmentation']):
                record = {'id': key, **context, **features,
                          'product_id': context.get('product_id') or key,
                          'image_url': Path(filename or 'image').name,
                          'model_version': MODEL_VERSION}
            return transaction.commit_result(key, result, record)

    @app.post('/gateway/detectDuplicateProduct', response_model=GatewayDetectionResponse)
    async def detect(image: UploadFile = File(...), product_id: Optional[str] = Form(None),
                     seller_id: Optional[str] = Form(None), listing_id: Optional[str] = Form(None),
                     category: Optional[str] = Form(None)):
        context = {}
        for name, value in {'product_id': product_id, 'seller_id': seller_id,
                            'listing_id': listing_id, 'category': category}.items():
            cleaned = (value or '').strip()
            if len(cleaned) > 256:
                raise HTTPException(422, f'{name} exceeds 256 characters')
            context[name] = None if cleaned.lower() in {'', 'string', 'none', 'null'} else cleaned
        # ASGI guard limits the complete multipart body before FastAPI parses it.
        try:
            contents = await image.read(10 * 1024 * 1024 + 1)
        finally:
            await image.close()
        if not contents:
            raise HTTPException(400, 'Empty image')
        if len(contents) > 10 * 1024 * 1024:
            raise HTTPException(413, 'Image exceeds 10 MiB')
        try:
            return await run_in_threadpool(process, contents, image.filename, context)
        except StoreCapacityError:
            raise HTTPException(503, 'Reference store capacity reached; contact administrator', headers={'Retry-After': '60'}) from None
    return app


app = create_app()
if __name__ == '__main__':
    import uvicorn
    uvicorn.run('main:app', host='127.0.0.1', port=8001, workers=1, proxy_headers=False)
