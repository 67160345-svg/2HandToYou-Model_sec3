# 2HandToYou Duplicate Detection

บริการตรวจภาพสินค้าซ้ำด้วย YOLOv8n-seg + OpenCLIP + pHash สำหรับ Backend ของ 2HandToYou
รองรับ POST `/gateway/detectDuplicateProduct` พร้อม API key, durable retry และข้อมูลอ้างอิงถาวร

README นี้อธิบายการรัน **Duplicate แยกบริการ** จาก Duplicate.zip
คำสั่งทั้งหมดให้รันใน `TwoHand-AI/duplicate` ที่มี Dockerfile และ requirements.txt

## 1. เริ่มใช้งานด้วย Docker

ต้องมี Docker Engine / Docker Desktop แบบ Linux containers, Compose v2.20+ และ Python 3 สำหรับสร้าง config

Linux:

```bash
python3 scripts/setup_env.py
docker compose config --quiet
docker compose up -d --build --wait
docker compose ps
```

Windows PowerShell:

```powershell
py -3 scripts/setup_env.py
docker compose config --quiet
docker compose up -d --build --wait
docker compose ps
```

ตัวสร้าง config จะสร้าง `.env` พร้อม API key สุ่ม โดยไม่ทับไฟล์เดิม
Docker ติดตั้ง dependencies, Tesseract OCR และดาวน์โหลด OpenCLIP ประมาณ 605 MB ระหว่าง build
YOLO weights ขนาดประมาณ 7 MB อยู่ใน modules/ แล้ว
ต้องเข้าถึง Docker Hub, PyPI, PyTorch และ Hugging Face ได้ระหว่างติดตั้ง
หลังติดตั้ง inference ใช้โมเดลในเครื่อง ไม่ต้องดาวน์โหลด weights ทุกครั้งที่มี request

ตรวจ `http://127.0.0.1:8001/ready` ต้องตอบ 200 พร้อม `status: ok` และ `engine: yolo-openclip`

```bash
docker compose logs --tail=100 duplicate
docker compose down
```

ฐานข้อมูล SQLite อยู่ใน Docker volume `duplicate-data` และคงอยู่หลัง down ตามปกติ
อย่าใช้ `docker compose down -v` กับข้อมูลจริง เพราะจะลบ volume ด้วย

## 2. เรียก API ด้วย Postman

Method: **POST**

```text
http://127.0.0.1:8001/gateway/detectDuplicateProduct
```

Header:

```text
api-key: ค่าจาก AI_API_KEY ใน .env
```

Body → **form-data**:

| Key | Type | ตัวอย่าง |
| --- | --- | --- |
| image | File | เลือกรูปสินค้า JPG/PNG/WebP/HEIC/HEIF หรือชนิดที่ระบบรองรับ |
| product_id | Text | product-001 |
| seller_id | Text | seller-001 |
| listing_id | Text | listing-001 |
| category | Text | phone |

image เป็นข้อมูลจำเป็น; ต้องเลือกชนิด File และเลือกไฟล์ใหม่จากเครื่องที่ใช้ Postman
ภาพไม่เกิน 10 MiB, ค่าเริ่มต้นไม่เกิน 20 ล้าน pixels; ไม่รับ PDF เป็นภาพสินค้า
ไม่ต้องตั้ง Content-Type เอง ให้ Postman สร้าง multipart boundary
metadata ทั้ง 4 ช่องต้องครบจึงใช้กฎ SPAM ได้ และแต่ละช่องไม่เกิน 256 ตัวอักษร
api-caller ส่งมาได้เพื่อเข้ากับ integration เดิม แต่การตรวจสิทธิ์ของบริการนี้ใช้ api-key
Backend ต้องตรวจสิทธิ์ผู้ขายและส่ง seller_id/listing_id ที่เชื่อถือได้ ไม่ให้ browser ถือ service key

ตัวอย่าง curl บน Linux สำหรับฐานข้อมูลทดสอบ ให้แทน YOUR_API_KEY ก่อนรัน:

```bash
curl -X POST http://127.0.0.1:8001/gateway/detectDuplicateProduct \
  -H "api-key: YOUR_API_KEY" \
  -F "image=@tests/product_fixture.png" \
  -F "product_id=product-001" \
  -F "seller_id=seller-001" \
  -F "listing_id=listing-001" \
  -F "category=phone"
```

ภาพ fixture เป็นภาพวาด QA และอาจได้ REVIEW เพราะไม่มี mask ของสินค้า
คำขอที่ผ่านเงื่อนไขอาจเพิ่ม reference จึงควรทดสอบบนฐานข้อมูลแยกจาก production

Collection รวมอยู่ใน Postman.zip ที่ `TwoHand-AI/postman/TwoHand-AI.postman_collection.json`
ตั้ง duplicate_url / duplicate_key และ working directory เป็น TwoHand-AI
กลุ่ม Duplicate ใน Collection ใช้ฐานข้อมูลทดสอบว่าง และมีกรณี expected_401/400 ที่ตั้งใจให้ตอบ error

## 3. อ่านผลการตรวจ

ให้ดู `analysis.decision` พร้อม is_repetition และ repetition_rate

| Decision | ความหมาย |
| --- | --- |
| UNIQUE | ไม่พบ match ตามเกณฑ์ และแยกตัวสินค้าออกจากพื้นหลังได้ |
| DUPLICATE | pHash หรือ foreground similarity ถึงเกณฑ์ซ้ำ |
| SPAM | ภาพซ้ำ, context ครบ, ผู้ขายเดิม และเป็นคนละสินค้า/ประกาศ |
| REVIEW | ภาพต้องตรวจต่อ เช่น คุณภาพต่ำ, heuristic flag, ไม่มี segmentation หรือคะแนนอยู่ในช่วงต้องทบทวน |

REVIEW ที่ is_repetition=false ไม่ได้ยืนยันว่าภาพไม่ซ้ำ ให้ Backend อ่าน decision ด้วย
คะแนนอยู่ในช่วง 0–1 และเป็น similarity score ไม่ใช่ความน่าจะเป็นที่สอบเทียบแล้ว
SPAM/DUPLICATE ใช้คะแนนสูงสุดระหว่าง foreground และ pHash; scores ของผลจับคู่อ้างอิง reference เดียวกัน
Screenshot/watermark/AI artifact เป็น heuristic สำหรับส่งตรวจต่อ ไม่ใช่ตัวพิสูจน์ว่าเป็นภาพ AI

## 4. Retry และการเก็บข้อมูล

- ส่ง bytes ของภาพและ metadata เดิมจะได้ผลเดิมจาก cache แม้รีสตาร์ตบริการ
- product_id เดิม หรือ seller_id + listing_id เดิม จะไม่ถูกนำมาเทียบกับตัวเอง
- ทดสอบ SPAM: ใช้ภาพเดิมและ seller_id เดิม แต่เปลี่ยน product_id และ listing_id เป็นประกาศใหม่
- ไม่เพิ่มภาพที่ตัดสินเป็น DUPLICATE/SPAM หรือโดน heuristic flag เป็น reference ใหม่
- เมื่อไม่มี segmentation ระบบยังใช้ pHash ตรวจซ้ำได้; ไม่ใช้ full-frame embedding ยืนยัน physical duplicate
- เก็บ features และผลตรวจ โดยไม่จำเป็นต้องเก็บสำเนาภาพต้นฉบับ image_reference จึงไม่ใช่ public download URL
- durable cache เก็บล่าสุดสูงสุด 20,000 คำขอ; คำขอที่เก่ากว่านั้นอาจถูกคำนวณใหม่

## 5. การตั้งค่า

| ตัวแปร | ค่าเริ่มต้น/หน้าที่ |
| --- | --- |
| AI_API_KEY | สร้างโดย setup_env.py; ส่งผ่าน api-key |
| REFERENCE_STORE | sqlite |
| DATABASE_PATH | native: runtime-data/duplicate.sqlite3; Docker ใช้ /app/runtime-data/duplicate.sqlite3 |
| BIND_ADDRESS | 127.0.0.1; เพิ่มใน .env หากต้องปรับ |
| API_PORT | 8001; เพิ่มใน .env หากต้องปรับ |
| CPU_THREADS | 2 |
| MAX_CONCURRENT_REQUESTS | 2; เมื่อเต็มตอบ 503 |
| MAX_REFERENCES | 10,000 ภาพ; เมื่อเต็มตอบ 503 ไม่ลบข้อมูลเก่าเงียบ ๆ |
| MAX_PIXELS | 20,000,000 |
| MAX_IMAGE_SIDE | 1600 หลัง resize เพื่อประมวลผล |

ใช้ 1 worker / 1 instance ต่อ reference store ไม่เพิ่ม replicas โดยตรง
SQLite เหมาะกับ server เครื่องเดียวและค้นหาแบบ linear scan ต้องวัดเวลาเมื่อข้อมูลเพิ่มขึ้น
กรณี Backend อยู่คนละเครื่อง ให้ตั้ง private IP, firewall และ TLS ตามโครงสร้างของทีม
`/docs` และ `/openapi.json` ไม่เปิดใน production; OpenAPI อยู่ใน Docs-Deployment.zip

## 6. ใช้ Supabase แทน SQLite

1. สร้าง .env ด้วย setup_env.py แล้วแก้ REFERENCE_STORE=supabase
2. ใส่ SUPABASE_URL และ SUPABASE_SERVICE_ROLE_KEY บน server
3. รัน `db/002_production.sql` ใน Supabase SQL Editor ด้วยสิทธิ์ owner
4. เปิดบริการและตรวจ /ready ก่อนเรียก API

SQL v2 สร้างตาราง/RPC ของบริการนี้ ไม่ลบหรือย้ายข้อมูลจากตาราง v1 ให้อัตโนมัติ
v2 เก็บ features/ผลตรวจ จึงไม่ต้องมี Storage bucket เพื่อเปิดบริการ
ยังต้องใช้ 1 instance / 1 worker ใน Supabase mode
Adapter เคยผ่าน unit test แบบ mock RPC แต่ยังไม่ได้ยืนยัน migration/การเชื่อมต่อกับโครงการ Supabase ของผู้ใช้
เส้นทางที่ทดสอบ persistence และ restart จริงแล้วคือ SQLite

## 7. ติดตั้งแบบไม่ใช้ Docker

ต้องมี Python 3.12 และ Tesseract OCR อยู่ใน PATH
Linux ต้องมี system packages tesseract-ocr, libgl1 และ libglib2.0-0 ด้วย

Linux:

```bash
python3.12 scripts/install.py
.venv/bin/python scripts/serve.py
```

Windows PowerShell:

```powershell
py -3.12 scripts/install.py
.\.venv\Scripts\python.exe scripts\serve.py
```

ตัวติดตั้งสร้าง .venv, ติดตั้ง dependencies, สร้าง .env และดาวน์โหลดโมเดล
เปิดครั้งถัดไปด้วย scripts/serve.py ผ่าน Python ใน .venv ได้เลย
เส้นทางที่ตรวจแล้วคือ Linux x86_64 CPU; Windows native/ARM64/GPU ยังไม่ได้ยืนยัน

ติดตั้งแยกจากการดาวน์โหลด:

```bash
python3.12 scripts/install.py --skip-model
.venv/bin/python scripts/download_model.py
.venv/bin/python scripts/download_model.py --offline
```

ระบบตรวจ SHA-256 ของ OpenCLIP และ YOLO ก่อนโหลดโมเดล

## 8. Tests และสำรองข้อมูล

```bash
python3.12 scripts/install.py --with-tests
.venv/bin/python -m pytest tests -q
```

ผลชุดส่งมอบ 15 กันยายน 2026: Duplicate 34 tests ผ่าน และทดสอบ API จริง/restart/Postman รวมผ่าน
Unit tests บางส่วนใช้ mock เพื่อแยก business logic; real HTTP/Postman ใช้ YOLO/OpenCLIP จริง
Reports.zip เก็บผลเดิม การเพิ่ม README รอบนี้ไม่ได้รันทดสอบโมเดลใหม่
ผลจากภาพวาด QA ไม่ใช่ accuracy ของภาพ marketplace จริง

สำรอง SQLite ใน Docker เลือกชื่อไฟล์ใหม่ที่ยังไม่มี:

```bash
docker compose exec -T duplicate python scripts/backup.py --output /app/runtime-data/backups/duplicate-backup-001.sqlite3
docker compose cp duplicate:/app/runtime-data/backups/duplicate-backup-001.sqlite3 ./duplicate-backup-001.sqlite3
```

สคริปต์ตรวจ integrity ของ snapshot ให้ เก็บสำเนานอก server ด้วย
Supabase mode ใช้การสำรองของ Supabase แทน การ restore ต้องให้ผู้ดูแลหยุดบริการและทำตามคู่มือ deployment

## 9. แก้ปัญหาเบื้องต้น

| อาการ | ตรวจอะไร |
| --- | --- |
| 401 | key หาย/ผิด หรือใช้คีย์ของ Recommendation |
| 400 | ภาพเสีย ว่าง ชนิดไม่รองรับ หรือเกิน pixel limit |
| 413 | ภาพเกิน 10 MiB หรือ multipart body ใหญ่เกินกำหนด |
| 415 | ต้องใช้ multipart/form-data |
| 422 | ไม่ได้ส่ง image หรือ metadata ยาวเกินกำหนด |
| 503 | งานเต็ม, reference เต็ม, โมเดล/ฐานข้อมูลยังไม่พร้อม |
| ทุกภาพเป็น REVIEW | ดู reason: คุณภาพภาพ, segmentation และ heuristic flags |
| ต่อจากเครื่องอื่นไม่ได้ | BIND_ADDRESS, IP, พอร์ต, firewall และ reverse proxy |

## 10. ใช้ชุดแยกหรือ Compose รวม

Duplicate.zip รันเดี่ยวได้โดยไม่ต้องแตก Reports/Docs/Postman
Standalone ใช้ AI_API_KEY ใน `duplicate/.env`
ถ้าแตกคู่กับ Recommendation.zip และ Docs-Deployment.zip เพื่อใช้ Compose รวม
ให้ใช้ DUPLICATE_API_KEY จาก `TwoHand-AI/.env` ของโฟลเดอร์บนสุด

คู่มือเพิ่มเติม: Docs-Deployment.zip; ผลทดสอบ: Reports.zip; Collection: Postman.zip
ยังต้องยืนยัน Docker containers/Gateway บน server ปลายทางและความแม่นยำกับภาพจริงก่อนรับมอบระบบรวม
