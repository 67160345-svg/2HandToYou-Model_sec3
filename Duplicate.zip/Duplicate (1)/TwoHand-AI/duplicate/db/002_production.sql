-- Run once in Supabase SQL Editor as project owner. Safe to re-run; does not alter v1 tables.
-- The v2 tables start empty. Historical v1 references are not imported automatically.
BEGIN;
CREATE EXTENSION IF NOT EXISTS vector;
CREATE TABLE IF NOT EXISTS public.duplicate_v2_references (
 id text PRIMARY KEY, record jsonb NOT NULL, fg_vector vector(512) NOT NULL,
 phash text NOT NULL CHECK (phash ~ '^[0-9a-f]{16}$'), created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS public.duplicate_v2_requests (
 id text PRIMARY KEY, response jsonb NOT NULL, created_at timestamptz NOT NULL DEFAULT now());
ALTER TABLE public.duplicate_v2_references ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.duplicate_v2_requests ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.duplicate_v2_references, public.duplicate_v2_requests FROM anon, authenticated;
GRANT ALL ON public.duplicate_v2_references, public.duplicate_v2_requests TO service_role;
CREATE INDEX IF NOT EXISTS duplicate_v2_reference_phash ON public.duplicate_v2_references(phash);
CREATE OR REPLACE FUNCTION public.duplicate_v2_ready() RETURNS integer LANGUAGE sql STABLE
 SET search_path=public AS $$ SELECT 1 FROM (SELECT count(*) FROM duplicate_v2_references) q $$;
CREATE OR REPLACE FUNCTION public.duplicate_v2_cached(request_key text) RETURNS jsonb LANGUAGE sql STABLE
 SET search_path=public AS $$ SELECT response FROM duplicate_v2_requests WHERE id=request_key $$;
CREATE OR REPLACE FUNCTION public.duplicate_v2_candidates(query_vector vector(512), query_phash text,
 excluded_product text DEFAULT NULL, excluded_listing text DEFAULT NULL, excluded_seller text DEFAULT NULL,
 match_count integer DEFAULT 50) RETURNS TABLE(record jsonb) LANGUAGE sql STABLE SET search_path=public AS $$
 WITH eligible AS (
   SELECT r.* FROM duplicate_v2_references r
   WHERE (excluded_product IS NULL OR r.record->>'product_id' IS DISTINCT FROM excluded_product)
   AND (excluded_listing IS NULL OR excluded_seller IS NULL
     OR r.record->>'listing_id' IS DISTINCT FROM excluded_listing OR r.record->>'seller_id' IS DISTINCT FROM excluded_seller)
 ), semantic AS (SELECT id FROM eligible ORDER BY fg_vector <=> query_vector LIMIT greatest(1,least(match_count,200))),
 hashes AS (SELECT id FROM eligible WHERE bit_count((('x'||phash)::bit(64)) # (('x'||query_phash)::bit(64))) <= 5)
 SELECT e.record FROM eligible e WHERE e.id IN (SELECT id FROM semantic UNION SELECT id FROM hashes);
$$;
CREATE OR REPLACE FUNCTION public.duplicate_v2_commit(request_key text, result_data jsonb,
 reference_data jsonb DEFAULT NULL, reference_limit integer DEFAULT 10000)
 RETURNS jsonb LANGUAGE plpgsql SET search_path=public AS $$
DECLARE previous jsonb;
BEGIN
 PERFORM pg_advisory_xact_lock(817294101);
 SELECT response INTO previous FROM duplicate_v2_requests WHERE id=request_key;
 IF previous IS NOT NULL THEN RETURN previous; END IF;
 IF reference_data IS NOT NULL THEN
   IF (SELECT count(*) FROM duplicate_v2_references) >= reference_limit
      AND NOT EXISTS(SELECT 1 FROM duplicate_v2_references WHERE id=reference_data->>'id')
     THEN RETURN '{"error":"capacity"}'::jsonb; END IF;
   INSERT INTO duplicate_v2_references(id,record,fg_vector,phash)
     VALUES(reference_data->>'id',reference_data,(reference_data->'fg_vector')::text::vector,reference_data->>'phash')
     ON CONFLICT(id) DO NOTHING;
 END IF;
 INSERT INTO duplicate_v2_requests(id,response) VALUES(request_key,result_data);
 DELETE FROM duplicate_v2_requests WHERE id IN
   (SELECT id FROM duplicate_v2_requests ORDER BY created_at DESC,id DESC OFFSET 20000);
 RETURN result_data;
END; $$;
REVOKE EXECUTE ON FUNCTION public.duplicate_v2_ready(), public.duplicate_v2_cached(text),
 public.duplicate_v2_candidates(vector,text,text,text,text,integer),
 public.duplicate_v2_commit(text,jsonb,jsonb,integer) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.duplicate_v2_ready(), public.duplicate_v2_cached(text),
 public.duplicate_v2_candidates(vector,text,text,text,text,integer),
 public.duplicate_v2_commit(text,jsonb,jsonb,integer) TO service_role;
COMMIT;
