"""Download pinned OpenCLIP weights and verify every model before server startup."""
import argparse
import hashlib
import json
from pathlib import Path
import os
import shutil
import tempfile

ROOT = Path(__file__).resolve().parents[1]

def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()

def verify_files():
    source = json.loads((ROOT/'model-source.json').read_text())
    paths = {'clip': ROOT/'models'/source['filename'], 'yolo':ROOT/source['yolo_file']}
    for name in paths:
        expected = source['sha256' if name == 'clip' else 'yolo_sha256']
        if not paths[name].is_file() or sha256(paths[name]) != expected:
            raise RuntimeError(f'{name} weights missing or checksum mismatch; run python scripts/download_model.py')
    return paths

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--offline', action='store_true')
    args = parser.parse_args()
    if args.offline:
        verify_files(); print('PASS: both model checksums (offline)'); return
    from filelock import FileLock
    from huggingface_hub import hf_hub_download
    source = json.loads((ROOT/'model-source.json').read_text())
    folder = ROOT/'models'; folder.mkdir(exist_ok=True)
    with FileLock(str(folder/'.download.lock'), timeout=0):
        try:
            verify_files(); print('PASS: existing model files'); return
        except RuntimeError:
            pass
        print('Downloading pinned OpenCLIP weights (605 MB); partial downloads can resume.', flush=True)
        downloaded = hf_hub_download(repo_id=source['model_id'], revision=source['revision'],
                                     filename=source['filename'], cache_dir=folder/'.download-cache')
        if sha256(downloaded) != source['sha256']:
            raise RuntimeError('OpenCLIP checksum mismatch; existing model was not replaced')
        fd, stage = tempfile.mkstemp(dir=folder, prefix='.model-stage-')
        try:
            with os.fdopen(fd,'wb') as output, open(downloaded,'rb') as inp:
                shutil.copyfileobj(inp, output); output.flush(); os.fsync(output.fileno())
            os.replace(stage, folder/source['filename'])
        finally:
            if os.path.exists(stage): os.unlink(stage)
        verify_files()
        shutil.rmtree(folder/'.download-cache', ignore_errors=True)
        print('PASS: downloaded model and bundled YOLO checksums')

if __name__ == '__main__':
    main()
