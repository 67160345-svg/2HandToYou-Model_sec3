"""Create a consistent SQLite snapshot while the service is running."""
import argparse,os,sqlite3
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
if os.getenv('REFERENCE_STORE','sqlite')!='sqlite':raise SystemExit('Use Supabase backups for Supabase mode')
source=Path(os.getenv('DATABASE_PATH','runtime-data/duplicate.sqlite3')).resolve()
if not source.exists():raise SystemExit('Database not found')
if a.output.exists():raise SystemExit('Backup already exists; choose a new filename')
a.output.parent.mkdir(parents=True,exist_ok=True)
with sqlite3.connect(source.as_uri()+'?mode=ro',uri=True) as inp,sqlite3.connect(a.output) as out:
    inp.backup(out)
    if out.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise RuntimeError('Backup integrity check failed')
print('Backup created and integrity checked')
