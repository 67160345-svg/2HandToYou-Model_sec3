from pathlib import Path
import os,sys
ROOT=Path(__file__).resolve().parents[1]
os.chdir(ROOT);sys.path.insert(0,str(ROOT))
from modules.settings import Settings
Settings.from_env()
import uvicorn
uvicorn.run('main:app',host=os.getenv('BIND_ADDRESS','127.0.0.1'),port=int(os.getenv('API_PORT','8001')),
            workers=1,proxy_headers=False,access_log=False,log_config=str(ROOT/'deploy/logging.json'))
