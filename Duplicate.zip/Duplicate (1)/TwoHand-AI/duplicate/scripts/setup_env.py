"""Create .env once with a random internal API key; never overwrite existing secrets."""
from pathlib import Path
import secrets

ROOT = Path(__file__).resolve().parents[1]
path = ROOT / '.env'
try:
    with path.open('x', encoding='utf-8') as stream:
        stream.write((ROOT / '.env.example').read_text().replace('AI_API_KEY=', 'AI_API_KEY=' + secrets.token_hex(32), 1))
    path.chmod(0o600)
    print('Created .env with a random API key. Keep it private and configure your Backend/Postman with that key.')
except FileExistsError:
    print('.env already exists; unchanged.')
