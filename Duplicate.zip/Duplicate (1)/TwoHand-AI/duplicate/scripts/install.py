"""Install a CPU-only runtime in .venv, configure it and download the pinned model."""
import argparse
from pathlib import Path
import subprocess
import sys
import venv
ROOT=Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--with-tests',action='store_true');p.add_argument('--skip-model',action='store_true');a=p.parse_args()
    if sys.version_info[:2]!=(3,12):raise SystemExit('Use Python 3.12')
    env=ROOT/'.venv';python=env/('Scripts/python.exe' if sys.platform=='win32' else 'bin/python')
    if not python.exists():venv.EnvBuilder(with_pip=True).create(env)
    def run(*args):subprocess.run([str(python),*args],cwd=ROOT,check=True)
    run('-m','pip','install','-r','requirements-cpu.txt')
    run('-m','pip','install','-r','requirements.lock')
    if a.with_tests:run('-m','pip','install','-r','requirements-test.txt')
    run('-m','pip','check');run('scripts/setup_env.py')
    if not a.skip_model:run('scripts/download_model.py')
    print('Ready. Install OS package tesseract-ocr, then run .venv Python with scripts/serve.py.')
if __name__=='__main__':main()
