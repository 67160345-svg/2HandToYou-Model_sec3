"""Supabase v2 adapter. One running service instance; atomic persistence via dedicated RPCs."""
from contextlib import contextmanager
import os
from supabase import create_client
from modules.sqlite_store import StoreCapacityError

class SupabaseStore:
    def __init__(self, max_references=10000, client=None):
        self.client = client or create_client(os.environ['SUPABASE_URL'], os.environ['SUPABASE_SERVICE_ROLE_KEY'])
        self.limit = max_references

    def ready(self):
        return self.client.rpc('duplicate_v2_ready', {}).execute().data == 1

    @contextmanager
    def transaction(self):
        # main.py holds the pipeline lock. The final RPC commits reference and retry response atomically.
        # Do not run multiple service replicas against this store without a distributed decision lock.
        yield SupabaseTransaction(self.client, self.limit)

class SupabaseTransaction:
    def __init__(self, client, limit):
        self.client, self.limit = client, limit

    def cached(self, key):
        return self.client.rpc('duplicate_v2_cached', {'request_key': key}).execute().data

    def candidates(self, context, features):
        rows = self.client.rpc('duplicate_v2_candidates', {
            'query_vector': features['fg_vector'], 'query_phash': features['phash'],
            'excluded_product': context.get('product_id'), 'excluded_listing': context.get('listing_id'),
            'excluded_seller': context.get('seller_id'), 'match_count': 50}).execute().data or []
        return [row['record'] for row in rows]

    def commit_result(self, key, response, record=None):
        data = self.client.rpc('duplicate_v2_commit', {'request_key': key, 'result_data': response,
                  'reference_data': record, 'reference_limit': self.limit}).execute().data
        if isinstance(data, dict) and data.get('error') == 'capacity':
            raise StoreCapacityError('Reference capacity reached')
        return data
