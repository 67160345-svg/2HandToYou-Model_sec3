"""Durable single-server reference store; decision + reference + retry result commit together."""
from contextlib import contextmanager
import json
from pathlib import Path
import sqlite3


class StoreCapacityError(RuntimeError):
    pass


class SQLiteStore:
    def __init__(self, path, max_references=10000):
        self.path = str(path)
        self.max_references = max_references
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.execute('PRAGMA journal_mode=WAL')
            db.executescript('''
                CREATE TABLE IF NOT EXISTS schema_version (version INTEGER PRIMARY KEY);
                INSERT OR IGNORE INTO schema_version VALUES (1);
                CREATE TABLE IF NOT EXISTS reference_images (
                    id TEXT PRIMARY KEY, product_id TEXT, listing_id TEXT, seller_id TEXT,
                    record TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
                CREATE INDEX IF NOT EXISTS reference_listing ON reference_images(seller_id, listing_id);
                CREATE TABLE IF NOT EXISTS requests (
                    id TEXT PRIMARY KEY, response TEXT NOT NULL,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
            ''')

    def connect(self):
        db = sqlite3.connect(self.path, timeout=30)
        db.execute('PRAGMA busy_timeout=30000')
        db.execute('PRAGMA synchronous=FULL')
        return db

    def ready(self):
        with self.connect() as db:
            return db.execute('SELECT version FROM schema_version').fetchone()[0] == 1

    @contextmanager
    def transaction(self):
        db = self.connect()
        try:
            db.execute('BEGIN IMMEDIATE')
            yield SQLiteTransaction(db, self.max_references)
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()


class SQLiteTransaction:
    def __init__(self, db, limit):
        self.db, self.limit = db, limit

    def cached(self, key):
        row = self.db.execute('SELECT response FROM requests WHERE id=?', (key,)).fetchone()
        return json.loads(row[0]) if row else None

    def candidates(self, context, features):
        rows = self.db.execute('SELECT record FROM reference_images').fetchall()
        result = []
        for row in rows:
            record = json.loads(row[0])
            # A listing edit is not a new spam listing. IDs are supplied by the authenticated gateway.
            same_seller = context.get('seller_id') and context.get('seller_id') == record.get('seller_id')
            same_listing = context.get('listing_id') and context.get('listing_id') == record.get('listing_id')
            same_product = context.get('product_id') and context.get('product_id') == record.get('product_id')
            if (same_seller and same_listing) or same_product:
                continue
            result.append(record)
        return result

    def commit_result(self, key, response, record=None):
        if record is not None:
            if self.db.execute('SELECT COUNT(*) FROM reference_images').fetchone()[0] >= self.limit:
                if not self.db.execute('SELECT 1 FROM reference_images WHERE id=?', (record['id'],)).fetchone():
                    raise StoreCapacityError('Reference capacity reached')
            self.db.execute('INSERT OR IGNORE INTO reference_images(id,product_id,listing_id,seller_id,record) VALUES(?,?,?,?,?)',
                            (record['id'], record.get('product_id'), record.get('listing_id'),
                             record.get('seller_id'), json.dumps(record)))
        self.db.execute('INSERT OR IGNORE INTO requests(id,response) VALUES(?,?)', (key, json.dumps(response)))
        # Bound cached result retention; current reference identity still prevents duplicate inserts.
        self.db.execute('DELETE FROM requests WHERE id IN (SELECT id FROM requests ORDER BY created_at DESC, rowid DESC LIMIT -1 OFFSET 20000)')
        return self.cached(key)
