"""Validated runtime settings. Load dotenv before importing any model modules."""
from dataclasses import dataclass
from pathlib import Path
import os
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / '.env')


@dataclass
class Settings:
    api_key: str = ''
    store: str = 'sqlite'
    database_path: str = str(ROOT / 'runtime-data/duplicate.sqlite3')
    max_body_bytes: int = 11 * 1024 * 1024
    body_timeout_seconds: int = 20
    max_concurrent_requests: int = 2
    max_references: int = 10000
    max_pixels: int = 20000000
    max_image_side: int = 1600
    cpu_threads: int = 2

    @classmethod
    def from_env(cls):
        s = cls(api_key=os.getenv('AI_API_KEY', ''),
                store=os.getenv('REFERENCE_STORE', 'sqlite').lower(),
                database_path=os.getenv('DATABASE_PATH', str(ROOT / 'runtime-data/duplicate.sqlite3')))
        for field in ('max_body_bytes', 'body_timeout_seconds', 'max_concurrent_requests',
                      'max_references', 'max_pixels', 'max_image_side', 'cpu_threads'):
            setattr(s, field, int(os.getenv(field.upper(), str(getattr(s, field)))))
        if len(s.api_key) < 32 or s.api_key.lower().startswith(('change', 'your', 'replace')):
            raise RuntimeError('Set AI_API_KEY to a random secret of at least 32 characters; run scripts/setup_env.py')
        if s.store not in {'sqlite', 'supabase'}:
            raise RuntimeError('REFERENCE_STORE must be sqlite or supabase; memory is not a production option')
        if any(getattr(s, f) <= 0 for f in ('max_body_bytes', 'body_timeout_seconds',
               'max_concurrent_requests', 'max_references', 'max_pixels', 'max_image_side', 'cpu_threads')):
            raise RuntimeError('Numeric resource limits must be positive')
        if s.max_concurrent_requests > 8 or s.max_image_side > 4096 or s.max_pixels > 40000000:
            raise RuntimeError('Resource limits exceed supported bounds')
        return s
