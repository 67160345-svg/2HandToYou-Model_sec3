@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if errorlevel 1 goto :python_error

set "PYTHON_VERSION="
for /f "delims=" %%V in ('py -3.12 -c "import sys; print(sys.version_info.major, sys.version_info.minor)" 2^>nul') do set "PYTHON_VERSION=%%V"
if not "%PYTHON_VERSION%"=="3 12" goto :python_error

py -3.12 scripts\install.py
if errorlevel 1 goto :install_error
.venv\Scripts\python.exe scripts\serve.py
if errorlevel 1 goto :server_error
exit /b 0

:python_error
echo.
echo [ERROR] Python 3.12 was not found.
echo Install Python 3.12 and enable the Python Launcher, then run this file again.
goto :failed

:install_error
echo.
echo [ERROR] Dependency installation failed.
goto :failed

:server_error
echo.
echo [ERROR] The server stopped unexpectedly.

:failed
echo.
pause
exit /b 1
