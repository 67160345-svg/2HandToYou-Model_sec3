"""Semantic backend plus explicitly labelled lexical test baseline. No silent fallback."""
import json
from collections import OrderedDict
from pathlib import Path
from threading import RLock
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer


class Encoder:
    def __init__(self, settings):
        self.kind = settings.engine
        self.lock = RLock()
        self.cache = OrderedDict()
        if self.kind == "semantic":
            from sentence_transformers import SentenceTransformer
            self.model = SentenceTransformer(
                settings.model_name, revision=settings.model_revision,
                local_files_only=settings.model_local_only, trust_remote_code=False, device="cpu",
            )
            # Avoid silent truncation of long descriptions: encode bounded token chunks.
            self.chunk_tokens = max(8, self.model.max_seq_length - 2)
        else:
            path = Path(settings.tfidf_path)
            if not path.exists():
                raise RuntimeError("Missing TF-IDF artifact. Run python scripts/train_tfidf.py")
            state = json.loads(path.read_text(encoding="utf-8"))
            self.model = TfidfVectorizer(analyzer="char", ngram_range=(2, 5),
                                         vocabulary=state["vocabulary"], dtype=np.float32)
            self.model.idf_ = np.asarray(state["idf"], dtype=np.float32)

    def _semantic_encode(self, texts):
        with self.lock:
            missing = list(dict.fromkeys(t for t in texts if t not in self.cache))
            if missing:
                chunks, owners = [], []
                for index, text in enumerate(missing):
                    tokens = self.model.tokenizer.encode(text, add_special_tokens=False)
                    for start in range(0, max(1, len(tokens)), self.chunk_tokens):
                        chunks.append(self.model.tokenizer.decode(tokens[start:start+self.chunk_tokens]))
                        owners.append(index)
                encoded = self.model.encode(chunks, batch_size=32, normalize_embeddings=True,
                                            convert_to_numpy=True, show_progress_bar=False)
                pooled = np.zeros((len(missing), encoded.shape[1]), dtype=np.float32)
                np.add.at(pooled, owners, encoded)
                pooled /= np.maximum(np.linalg.norm(pooled, axis=1, keepdims=True), 1e-12)
                for text, vector in zip(missing, pooled):
                    self.cache[text] = vector
            result = np.stack([self.cache[t] for t in texts])
            for t in texts:
                self.cache.move_to_end(t)
            while len(self.cache) > 4096:
                self.cache.popitem(last=False)
            return result

    def similarities(self, query_texts, product_texts):
        if not query_texts or not product_texts:
            return np.zeros((len(query_texts), len(product_texts)), dtype=np.float32)
        if self.kind == "semantic":
            vectors = self._semantic_encode(query_texts + product_texts)
            result = vectors[:len(query_texts)] @ vectors[len(query_texts):].T
        else:
            query = self.model.transform(query_texts)
            candidates = self.model.transform(product_texts)
            result = (query @ candidates.T).toarray()
        return np.clip(result, 0, 1)
