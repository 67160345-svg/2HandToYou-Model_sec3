"""Explicit configuration; one encoder instance per server process."""
from dataclasses import dataclass
import os


@dataclass(frozen=True)
class Settings:
    engine: str = "semantic"
    model_name: str = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
    model_revision: str | None = None
    model_local_only: bool = False
    tfidf_path: str = "models/tfidf.json"
    catalog_path: str = ""
    api_key: str = ""
    environment: str = "development"
    require_status: bool = False
    compare_shortfall: str = "error"
    max_body_bytes: int = 8_000_000

    @classmethod
    def from_env(cls):
        return cls(
            engine=os.getenv("AI_ENGINE", "semantic"),
            model_name=os.getenv("MODEL_NAME", cls.model_name),
            model_revision=os.getenv("MODEL_REVISION") or None,
            model_local_only=os.getenv("MODEL_LOCAL_ONLY", "false").lower() == "true",
            tfidf_path=os.getenv("TFIDF_PATH", "models/tfidf.json"),
            catalog_path=os.getenv("CATALOG_PATH", ""),
            api_key=os.getenv("AI_API_KEY", ""),
            environment=os.getenv("APP_ENV", "development"),
            require_status=os.getenv("REQUIRE_PRODUCT_STATUS", "false").lower() == "true",
            compare_shortfall=os.getenv("COMPARE_SHORTFALL", "error"),
        )

    def validate(self):
        if self.engine not in {"semantic", "tfidf"}:
            raise ValueError("AI_ENGINE must be semantic or tfidf")
        if self.compare_shortfall not in {"error", "return_available"}:
            raise ValueError("COMPARE_SHORTFALL must be error or return_available")
        if self.environment == "production" and (len(self.api_key) < 24 or not self.require_status):
            raise ValueError("Production needs AI_API_KEY (24+ characters) and REQUIRE_PRODUCT_STATUS=true")
