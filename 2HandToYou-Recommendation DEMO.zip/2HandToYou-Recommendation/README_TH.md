# 2HandToYou — โมเดลร่วมสำหรับ 3 Recommendation API

ชุดโค้ด MVP สำหรับทีม AAI เชื่อมกับ Backend ของทีม SE

| Endpoint | ผลลัพธ์ |
| --- | --- |
| `POST /gateway/recommendProduct` | `product_recommend` สูงสุด 10 ชิ้น ตามความสนใจ หรือความนิยมเมื่อไม่มีข้อมูลความสนใจ |
| `POST /gateway/similarProduct` | `product_recommend` สูงสุด 10 ชิ้น ใกล้เคียงกับสินค้าปัจจุบัน |
| `POST /gateway/compareProduct` | `product_compare` 3 ชิ้น ประเภทเดียวกัน เหมาะนำไปเทียบสภาพ/กล่อง/ราคา |

## อ่านก่อนใช้

ไฟล์ที่ได้รับเป็น Dataset Excel และ Postman Collection ไม่ใช่ไฟล์น้ำหนักโมเดลที่ฝึกแล้ว ชุดนี้จึงทำระบบใหม่ให้ตาม Requirement โดยมี 2 โหมด:

- `semantic`: ใช้ pretrained `sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2` ร่วมกันทั้ง 3 เส้น ต้องติดตั้ง dependencies และดาวน์โหลดโมเดลก่อน ใช้ชื่อ/รายละเอียดเพื่อวัดความหมาย ไม่ได้ fine-tune ด้วย Excel นี้
- `tfidf`: โมเดลพื้นฐานจับความคล้ายของตัวอักษรสำหรับทดสอบ API มีไฟล์ที่ fit แล้วใน `models/tfidf.json` ใช้ได้โดยไม่ดาวน์โหลดโมเดลภาษา แต่ไม่ใช่ Semantic Similarity และไม่เข้าใจคำพ้องความหมายเท่าโมเดลภาษา

โมเดล Semantic มีการรองรับหลายภาษารวมถึงไทยตาม [เอกสาร Sentence Transformers](https://www.sbert.net/docs/sentence_transformer/pretrained_models.html#multilingual-models) แต่ยังต้องวัดคุณภาพบนสินค้าจริงของโครงการ น้ำหนัก Semantic ไม่รวมใน ZIP นี้

`compareProduct` เลือกสินค้าไปเป็นคู่เทียบ ไม่ได้สร้างบทวิเคราะห์ว่าอะไรดีที่สุด และไม่ใช่โมเดลประเมินราคา คะแนนที่คืนคือคะแนนจัดอันดับ ไม่ใช่โอกาสซื้อหรือความมั่นใจร้อยละ

## 1. ทดลองให้ API ตอบกลับก่อน

สำหรับ Windows ติดตั้ง Python 3.11 จาก [python.org](https://www.python.org/downloads/) พร้อม Python Launcher จากนั้น:

1. แตก ZIP และเปิดโฟลเดอร์ `2HandToYou-Recommendation`
2. ดับเบิลคลิก `run_demo.bat` รอติดตั้งไลบรารีครั้งแรก ต้องมีอินเทอร์เน็ตในขั้นติดตั้ง
3. เปิด `http://127.0.0.1:8000/health` ต้องได้ `status: ok` และ `engine: tfidf`
4. เปิด Postman กด Import แล้วเลือก `postman/2HandToYou_Local.postman_collection.json`
5. ใน Collection เลือก `recommend`, `cold_start`, `similar`, `compare` แล้วกด Send ควรเป็น HTTP 200
6. `compare_shortfall` เป็นตัวอย่างตั้งใจให้ได้ HTTP 409 เพราะมีคู่เทียบเพียง 2 ชิ้น

อย่าปิดหน้าต่างตัวรันระหว่างทดลอง กด Ctrl+C เพื่อหยุด ตัวรันเดโมฟังเฉพาะเครื่องตัวเอง ไม่ใช่ public server ไม่มี `/docs` ในโหมดตัวรันเดโม

Collection ใหม่ชี้มาที่เครื่องคุณเท่านั้น ไม่ใช้ API key ของพาร์ตเนอร์ และไม่ได้ยิงไปที่ Gateway จริง

ถ้ารัน `.bat` ไม่ได้ เปิด PowerShell ที่โฟลเดอร์โปรเจกต์:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-demo.txt
$env:AI_ENGINE="tfidf"
.\.venv\Scripts\python.exe scripts/demo_server.py
```

เรียก API โดยไม่ใช้ Postman เปิด PowerShell อีกหน้าต่าง:

```powershell
$payload = Get-Content -Raw -Encoding UTF8 examples/compare.json
$bytes = [System.Text.Encoding]::UTF8.GetBytes($payload)
Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:8000/gateway/compareProduct" -ContentType "application/json; charset=utf-8" -Body $bytes
```

## 2. เปิดใช้โมเดล Semantic ตามโจทย์

หยุดตัวรันเดโมก่อน เพราะใช้ port 8000 เดียวกัน แล้วดับเบิลคลิก `run_semantic.bat`

ตัวรันจะติดตั้ง dependencies ดาวน์โหลด pretrained model ลง `models/semantic` เฉพาะเมื่อยังไม่มี และเปิด FastAPI หลังจากโหลดโมเดลสำเร็จ ไม่สลับไป TF-IDF เงียบ ๆ หากโหลดโมเดลไม่สำเร็จ

ตรวจ `http://127.0.0.1:8000/health` ต้องเป็น `engine: semantic` จากนั้นทดสอบใน Postman หรือเปิด `http://127.0.0.1:8000/docs`

คำสั่งเทียบเท่าใน PowerShell:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe scripts/download_model.py
$env:AI_ENGINE="semantic"
$env:MODEL_NAME="models/semantic"
$env:MODEL_LOCAL_ONLY="true"
.\.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --workers 1
```

ดาวน์โหลดครั้งแรกต้องเข้าถึงผู้ให้บริการโมเดลได้ หลังบันทึกโมเดลและติดตั้งไลบรารีแล้วสามารถ infer ในเครื่องโดยไม่เรียกบริการ AI ภายนอก หากดาวน์โหลดไม่สำเร็จให้แก้ปัญหาเครือข่าย/พื้นที่ก่อน ไม่ถือว่าโหมด Semantic พร้อมใช้

## 3. ข้อมูลที่ SE ต้องส่งเพิ่ม

ฟิลด์ใน Postman เดิมยังใช้เป็นฐานได้ แต่ไม่เพียงพอสำหรับ Requirement ทั้งหมด:

| ฟิลด์ | ใช้ที่ไหน | หากไม่มี |
| --- | --- | --- |
| `popularity_score` ช่วง 0–1 | Cold Start | คืน 422 เมื่อยังมีสินค้าที่จะจัดอันดับ แต่คะแนนไม่ครบ ไม่แต่งความนิยมขึ้นเอง |
| `category`, `subcategory` | similar / compare | similar ใช้ข้อความอย่างเดียวในส่วนที่ขาด; compare ต้องมีข้อมูลประเภทอย่างน้อยหนึ่งระดับ |
| `product_type` (ทางเลือกที่ละเอียดกว่า) | compare | หากมี จะใช้เป็นตัวกรองประเภทหลักก่อน subcategory/category |
| `product_status` | กรองพร้อมขาย | โหมด production บังคับส่งทุก candidate; เดโมที่ขาดจะเตือนว่า SE ต้องกรองก่อนส่ง |
| `price` | แสดงส่วนต่างราคาคู่เทียบ | ยังเลือกคู่เทียบได้ แต่ไม่คำนวณส่วนต่างราคา |
| `history_product` หรือแคตตาล็อกที่ตั้งไว้ | แปลง ID ในประวัติเป็นเนื้อหาสินค้า | ID ที่ค้นข้อมูลไม่ได้จะถูกข้ามพร้อม Warning; ถ้าไม่เหลือสัญญาณความสนใจจะใช้ Cold Start |

อย่าใช้ `product_status: Active` เติมให้ทุกชิ้นโดยไม่ตรวจฐานข้อมูลจริง และอย่าใช้ลำดับใน array แทนคะแนนความนิยม

`product_deteriorate` รองรับ 0–100 โดยใช้ความต่างแบบค่าสัมบูรณ์เพื่อหาสภาพใกล้กัน จึงยังไม่ต้องตีความว่าเลขมากดีหรือแย่ แต่ก่อนแสดงคำว่า “สภาพดีกว่า” ต้องให้ SE ยืนยันความหมาย ใช้ `true`/`false` จริงกับ `product_have_boxset` ไม่ใช้ string

`compareProduct` หากข้อมูลเพียงพอจะคืน 3 ชิ้น ถ้าคู่เทียบที่ผ่านเงื่อนไขมีไม่ถึง 3 จะคืน 409 ค่าเริ่มต้นนี้ตรงกับข้อกำหนดจำนวน 3 ชิ้น หากทีมตกลงยอมรับน้อยกว่า 3 ค่อยตั้ง `COMPARE_SHORTFALL=return_available` ระบบจะไม่เติมสินค้าคนละประเภทหรือสินค้าซ้ำเพื่อให้ครบ

## 4. Dataset และการฝึก

สคริปต์ได้แยกแคตตาล็อกสินค้าจาก 10,000 คู่ผู้ซื้อ–สินค้าเป็นสินค้าที่ไม่ซ้ำ 2,891 ชิ้น เก็บข้อมูลพฤติกรรม 5,000 snapshot และรายงานจุดขาดใน `data/prepared/data_audit.json`

- พบ ID สินค้าในประวัติ 103 ID ที่ไม่มีในแคตตาล็อกที่แยกได้ ไม่สร้างข้อมูลแทนให้
- ไม่มีรายละเอียดสินค้า รูปภาพ เปอร์เซ็นต์เสื่อม และข้อมูลกล่องในตารางสินค้า จึงไม่แปลง `Condition` เป็นเปอร์เซ็นต์ตามอำเภอใจ
- ข้อมูลระบุชัดว่าเป็น synthetic และค่าที่ Acceptance Criteria เรียกว่า Expected ไม่ใช่ผลวัดโมเดล
- ตัวอย่างมือถือใน `examples` เป็นข้อมูล QA ที่สร้างขึ้นแยกต่างหาก เพื่อให้ทดสอบ compare ได้ ไม่ใช่ข้อมูลที่อ้างว่ามีใน Excel
- TF-IDF ที่แนบ fit จากชื่อ/หมวด/แบรนด์ใน catalog และตัวอย่าง QA ไม่มีการเรียนรู้ preference จากคะแนนสังเคราะห์ใน Excel

ทำซ้ำหลังเปลี่ยน Dataset:

```powershell
.\.venv\Scripts\python.exe scripts/prepare_data.py data/source_recommendation.xlsx
.\.venv\Scripts\python.exe scripts/train_tfidf.py
```

โมเดล Semantic แบบ pretrained ไม่จำเป็นต้องฝึกใหม่เพื่อเริ่มใช้งาน แต่หากต้องการ fine-tune ควรมีคู่ข้อความ/สินค้าและคะแนน relevance จากคนตรวจหรือพฤติกรรมจริง แยก training/validation/test ตามผู้ใช้หรือเวลา และมี test set ที่ไม่เคยใช้ปรับน้ำหนัก ชุดนี้ไม่สร้าง label ปลอมให้ทั้ง 3 งานแล้วอ้างว่าเรียนรู้สำเร็จ

## 5. ทดสอบและวัดผล

```powershell
$env:AI_ENGINE="tfidf"
.\.venv\Scripts\python.exe scripts/verify.py
.\.venv\Scripts\python.exe scripts/evaluate.py
```

`verify.py` ทดสอบตรรกะและ HTTP จริงใน localhost พร้อมบันทึกผลลง `reports/verification.json` / `reports/verification.txt` รายการ Semantic และ FastAPI จะขึ้น skipped หากยังไม่มี dependency หรือโมเดล ไม่ถือว่าผ่าน

หลังติดตั้งครบและมี `models/semantic` ให้รัน verify ซ้ำเพื่อเปิดการทดสอบทั้งสองส่วน จากนั้นวัด Semantic ด้วย:

```powershell
$env:AI_ENGINE="semantic"
$env:MODEL_NAME="models/semantic"
$env:MODEL_LOCAL_ONLY="true"
.\.venv\Scripts\python.exe scripts/evaluate.py --output reports/semantic_evaluation.json
```

ตัวอย่าง evaluation มีเพียง smoke cases เพื่อเช็คทิศทาง ไม่ใช่หลักฐานความแม่นยำ production หากใช้เคสจริง เตรียม JSON รูปแบบเดียวกับ `examples/evaluation_cases.json` แล้วระบุ `--cases your_cases.json` สคริปต์คำนวณ Precision@K, Recall@K, NDCG@K และ MRR จากลิสต์ที่ระบบคืนจริง ไม่คัดลอกเปอร์เซ็นต์จาก Excel

## 6. เชื่อมกับ Backend จริง

Frontend เรียก Backend ของ SE ตามเดิม จากนั้น Gateway ตรวจสิทธิ์ผู้เรียกและส่ง payload มาที่ AI service นี้ Backend เป็นผู้ส่ง candidate ที่ผู้ใช้มีสิทธิ์เห็นและยังพร้อมขาย ไม่ควรเปิด AI key ให้ Frontend

- ชื่อ path มี `/gateway/...` เหมือนต้นฉบับ แต่ host ต้องเป็นที่อยู่ AI server ไม่ใช่ host เดิมของพาร์ตเนอร์
- `api-caller`, `Referer` และ key แยกบริการของ Gateway เดิมยังตรวจที่ฝั่ง Gateway ระบบนี้ไม่ได้จำลองฐานสิทธิ์ `resolveCallerService`
- บริการ AI ใช้ `api-key` ภายในอีกชุด ตั้งด้วย `AI_API_KEY` ไม่ใช้ key ที่ติดมากับ Postman เดิม
- ดู `docs/API_CONTRACT_TH.md` และโค้ดตัวอย่าง forward ใน `examples/gateway_forward.mjs`
- `CATALOG_PATH` ใช้เสริมข้อมูลประวัติเท่านั้น ไม่เอาสินค้านอก request มาเพิ่มในผลลัพธ์
- การแก้ catalog บนดิสก์ต้อง restart server และข้อมูลสดใน request จะมีลำดับความสำคัญเหนือ catalog เสมอ

ยังไม่ได้ deploy หรือแก้ Gateway จริงของ SE ให้ การนำขึ้น server ต้องทำบนเครื่องและสิทธิ์ที่ทีมจัดเตรียมไว้

## 7. Server / Docker

สำหรับเริ่มทดลอง Semantic บน CPU ประเมินเบื้องต้นที่ CPU 2–4 cores, RAM 4–8 GB และเผื่อดิสก์หลาย GB สำหรับ Python/PyTorch/โมเดล ตัวเลขนี้เป็นงบทรัพยากรตั้งต้น ไม่ใช่ผล benchmark ของระบบนี้ ให้ load test กับจำนวน candidate และผู้ใช้จริงก่อนเลือกสเปก

หนึ่ง worker โหลดหนึ่งโมเดล ถ้าใช้หลาย worker จะมีหลายสำเนาใน RAM ค่าเริ่มต้นจึงเป็น `--workers 1` และมี cache เวกเตอร์สินค้า/ข้อความแบบจำกัดจำนวนในแต่ละ process โมเดล infer ด้วย CPU และรับ candidate สูงสุด 5,000 ชิ้นต่อ request ยังไม่มี vector database หรือ pre-index ของ marketplace จริง

สำหรับ Docker ต้องดาวน์โหลดโมเดลลง `models/semantic` ก่อน build:

```powershell
docker build -t twohand-ai .
$env:AI_API_KEY="<ตั้งคีย์สุ่มใหม่อย่างน้อย 24 ตัวอักษร>"
docker run --rm -p 127.0.0.1:8000:8000 -e AI_API_KEY twohand-ai
```

Docker ตั้ง production, บังคับ status, ปิด docs และใช้ non-root user ไว้แล้ว ด้านหน้า service ยังต้องมี HTTPS/reverse proxy, rate limit, timeout, firewall และการตรวจสิทธิ์ผู้ใช้โดย Gateway ห้ามเปิด demo server สู่อินเทอร์เน็ต Docker build/deploy ยังไม่ได้ทดสอบในสภาพแวดล้อมที่ใช้สร้าง ZIP นี้

## 8. ปัญหาที่เจอบ่อย

| อาการ | วิธีตรวจ |
| --- | --- |
| `py` หรือ Python 3.11 ไม่พบ | ติดตั้ง Python 3.11 + Python Launcher หรือใช้ Python 3.11 ที่มีอยู่สร้าง venv เอง |
| Port 8000 ถูกใช้ | ปิดตัวรันเดิมก่อนเปิดอีกโหมด |
| ไม่มี `models/tfidf.json` | รัน `scripts/train_tfidf.py` หลังเตรียม catalog |
| Semantic โหลดไม่ได้ | ตรวจ internet, disk และ dependency; รัน download_model อีกครั้ง; อย่าใช้ TF-IDF แทนแล้วเรียกว่า Semantic |
| 422 `missing_popularity` | ส่ง popularity_score ที่ใช้สเกล/ช่วงเวลาเดียวกันทุก candidate |
| 422 `missing_product_type` | เติมประเภทเดียวกันทั้ง this_product และ candidate |
| 409 `insufficient_comparable_products` | ส่ง candidate ที่ผ่านเงื่อนไขอย่างน้อย 3 ตัว ไม่นับสินค้าหลัก |
| 401 | ตั้ง `api-key` ให้ตรงกับ AI_API_KEY ของ service ไม่ใช่ key เก่าใน Gateway |
| แก้ `.env.example` แล้วไม่เปลี่ยน | ไฟล์นี้เป็นตัวอย่างเอกสาร โปรแกรมไม่ได้โหลดอัตโนมัติ ให้ตั้ง environment ใน shell หรือ Docker |

เอกสารอ้างอิงการโหลดโมเดลครั้งเดียวต่อ process: [FastAPI Lifespan](https://fastapi.tiangolo.com/advanced/events/)
