// Integration function for an existing SE backend (Node.js with built-in fetch).
// Call ONLY after the existing Gateway has authorized caller, referer and user access.
// Do not insert the original partner keys here; AI service has its own internal key.
const allowed = new Set(["recommendProduct", "similarProduct", "compareProduct"]);

export async function callRecommendationAI(endpoint, payload) {
  if (!allowed.has(endpoint)) throw new Error("Unsupported AI endpoint");
  const base = process.env.RECOMMENDATION_AI_URL;
  const key = process.env.RECOMMENDATION_AI_KEY;
  if (!base || !key) throw new Error("AI service configuration missing");
  const url = new URL(base);
  if (!["http:", "https:"].includes(url.protocol)) throw new Error("Invalid service URL");
  url.pathname = url.pathname.replace(/\/$/, "") + `/gateway/${endpoint}`;
  url.search = "";
  url.hash = "";
  // No endpoint or host is accepted from browser input. Never send full user profiles.
  const response = await fetch(url, {
    method: "POST",
    headers: {"Content-Type": "application/json", "api-key": key},
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(30000),
    redirect: "error"
  });
  const body = await response.json();
  // Caller decides how to map 409/422 to UX. Do not silently convert errors to [].
  return {status: response.status, body, warnings: response.headers.get("X-AI-Warnings")};
}
