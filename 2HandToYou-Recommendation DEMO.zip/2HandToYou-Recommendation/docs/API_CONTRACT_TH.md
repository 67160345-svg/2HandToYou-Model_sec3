# API Contract v1 — ข้อเสนอสำหรับให้ SE ยืนยันก่อนใช้งานจริง

คง method/path, root input และ root output ตามข้อกำหนดผู้ใช้ โดยกำหนดสมาชิกใน output array เป็น object รายละเอียดสินค้าที่อนุญาต พร้อม `score` และ `reason` เพราะ Collection ต้นฉบับไม่มี response example ให้ยืนยันรูปแบบสมาชิก ถ้า SE ต้องการ array ของ ID ให้แก้ชั้น adapter โดยไม่แก้แกน ranking

## Product

ต้องมี `product_id` string ไม่ว่างไม่เกิน 200 ตัวอักษร และ `product_name` ไม่ว่างไม่เกิน 500 ตัวอักษร `product_description` ไม่เกิน 4,000 ตัวอักษร ค่าเริ่มต้นเป็นข้อความว่าง

ชื่อ optional fields ที่รองรับ: `category`, `subcategory`, `product_type`, `brand`, `condition`, `price`, `popularity_score`, `product_status`, `product_deteriorate`, `product_have_boxset`, `product_image`

- ID เป็น opaque string รองรับทั้ง UUID ของระบบจริงและ `PRD...` ใน dataset ไม่บังคับรูปแบบ ID ฝั่ง Excel กับระบบจริงให้เหมือนกัน
- Price ต้องเป็นตัวเลขมากกว่า 0 และเป็นสกุลเงิน/หน่วยเดียวกันทั้ง request (ในโครงการนี้คาดว่า THB)
- popularity_score ช่วง 0–1 โดยต้องคำนวณฝั่ง Backend ด้วยนิยามและช่วงเวลาเดียวกัน ไม่ใช่ความนิยมของผู้ใช้ปัจจุบันคนเดียว
- deteriorate ช่วง 0–100, boxset ต้องเป็น boolean จริงหรือ null
- status รองรับ Active/Sold/Inactive/Deleted รับตัวพิมพ์เล็กและปรับรูปแบบได้
- field ที่ไม่รู้จักใน Product ถูกละทิ้ง ไม่สะท้อนข้อมูลส่วนตัวของผู้ขาย; แต่ API ไม่สามารถรับประกันลบ PII ที่เขียนอยู่ภายในชื่อ/รายละเอียดสินค้าได้ SE ต้อง sanitize ก่อนส่ง
- product_image ส่งผ่านเป็น path/string เท่านั้น โปรแกรมนี้ไม่ดาวน์โหลดภาพและไม่ได้คำนวณ image similarity
- `product` array บังคับส่งและรับได้ 0–5,000 ชิ้น; ID ซ้ำรายละเอียดเหมือนกันจะเหลือหนึ่งชิ้น รายละเอียดขัดกันคืน 422
- root field ที่ไม่รู้จักคืน 422 เพื่อจับการสะกดชื่อผิด

## recommendProduct

Input: `history` array (ค่าเริ่มต้น []), `activity` array (ค่าเริ่มต้น []), `product` array, `history_product` array เสริมได้ (ค่าเริ่มต้น [])

history แต่ละชิ้นมี product_id และ viewed_at (optional ISO datetime ต้องมี timezone) activity รับ `view`, `add_to_cart`, `search`; รองรับ wishlist/favorite/purchase เป็นส่วนขยาย optional โดย search ต้องมี keyword และอย่างอื่นต้องมี product_id; timestamp เป็น optional datetime ที่ต้องมี timezone

ระบบ resolve ID โดยเรียงความสำคัญ: product ใน request > history_product > CATALOG_PATH ที่โหลดตอนเริ่ม server รายการเหล่านี้ใช้ทำความเข้าใจประวัติ แต่ผลลัพธ์มาจาก product ใน request เท่านั้น

น้ำหนักเริ่มต้นที่ยังไม่ได้ปรับจากข้อมูลจริง: view=1, search=3, add_to_cart/wishlist/favorite=4, purchase=5 ประวัติที่มีเวลาลดน้ำหนักครึ่งหนึ่งทุก 30 วัน (cap อายุที่ 365 วัน); ไม่ใส่เวลาไม่ลดน้ำหนัก เวลาอนาคตไม่เพิ่มน้ำหนัก ข้อความสัญญาณซ้ำใช้ค่าสูงสุดไม่บวกซ้ำ จัดเก็บสูงสุด 100 สัญญาณน้ำหนักสูงสุด

Score เป็น weighted mean ของ cosine similarity ระหว่างสินค้าและสัญญาณความสนใจ (clip cosine ติดลบเป็น 0) คะแนนพฤติกรรมจึงมีผลผ่านน้ำหนักสัญญาณ ไม่บวกซ้ำเป็นคะแนนที่นิยามไม่ได้ ไม่ใช้สูตรเสนอในข้อความก่อนหน้าว่า 55/25/20 เป็นค่าที่พิสูจน์แล้ว

ไม่มีสัญญาณที่ resolve ได้: ใช้ popularity_score ทุก candidate; หากขาดให้คืน 422 เมื่อไม่มี candidate เลยคืน `{"product_recommend":[]}` สินค้าที่ระบุ purchase ใน activity ไม่คืนซ้ำ แต่ไม่มีฐานประวัติซื้ออื่นนอก payload

ผลสำเร็จ: `{"product_recommend":[<Product + score + reason>]}` สูงสุด 10 ถ้ามีเพียง 2 คืน 2 ไม่เติมซ้ำ เรียงคะแนนมากไปน้อย คะแนนเสมอตัดสินด้วย product_id เพื่อให้ผลซ้ำได้

## similarProduct

Input: this_product, product

นำชื่อและคำอธิบาย รวมหมวด/ประเภท/แบรนด์ที่มี เป็นข้อความให้ encoder; score = 0.75×text similarity + 0.15×category match + 0.10×subcategory match เมื่อข้อมูลเปรียบเทียบหมวดขาดจะตัดองค์ประกอบนั้นและหารด้วยน้ำหนักที่ยังใช้ได้ ค่าทั้งหมดเป็น baseline ที่ปรับได้ใน app/engine.py

ไม่คืน product_id เดียวกับ this_product และไม่คืนสินค้าที่ระบุสถานะไม่ Active ชิ้นอื่นอาจมีชื่อเหมือนกันได้ถ้าเป็นคนละ listing คืน root `product_recommend` สูงสุด 10 เช่นเดียวกับเส้นแรก

ยังไม่มี relevance threshold ที่ calibrate จากข้อมูลจริง จึงอาจคืนสินค้าที่คล้ายน้อยเมื่อ candidate ที่ดีมีน้อย ควรสร้างชุดประเมินก่อนกำหนด cutoff ไม่สามารถใช้ score เป็น probability ได้

## compareProduct

Input: this_product, product

1. กรองประเภทแบบ exact match หลังตัดช่องว่างหัวท้ายและ casefold เลือก field ของ this_product ตามลำดับ product_type > subcategory > category แล้วใช้ field เดียวกันกับ candidate
2. ตัว this_product และ candidate ต้องมี deteriorate ร่วมกัน หรือ boxset ร่วมกันอย่างน้อยหนึ่งอย่าง จึงเหมาะนำมาเทียบตามโจทย์
3. ตัดสินค้าหลักและสินค้าที่ไม่พร้อมขาย
4. Score = 0.40×text similarity + 0.50×(1 − abs(deteriorate difference)/100) + 0.10×boxset match หาก attribute ขาดไม่ใส่คะแนนให้ และ normalize ด้วยน้ำหนักที่เหลือ
5. เลือก 3 ชิ้น ไม่ใช้ราคาเป็นตัวกรอง เพื่อไม่ตัดตัวเลือกที่ราคาต่างออกก่อนให้ผู้ใช้เปรียบเทียบ

ถ้ามีเพียง category กว้าง เช่น Electronics คู่อาจเป็นคนละชนิดสินค้าจริงได้ SE ควรส่ง subcategory หรือ product_type ที่นิยามละเอียดและใช้ taxonomy เดียวกันทั้งระบบ ระบบไม่เดาหมวดจากชื่อแทนค่าที่ไม่มี

Output `{"product_compare":[<Product + score + reason + differences>]}` differences ได้แก่:

| ฟิลด์ | นิยาม |
| --- | --- |
| price_difference | ราคาตัวเลือก − ราคาสินค้าหลัก ค่าลบหมายถึงตัวเลือกถูกกว่า ไม่ใช่คุ้มค่ากว่า |
| deteriorate_difference | ค่าของตัวเลือก − ค่าสินค้าหลัก ยังไม่ตีความดี/แย่ |
| boxset_match | boolean เปรียบเทียบค่ากล่อง ถ้าทั้งคู่มีข้อมูล |

ค่าที่คำนวณไม่ได้เป็น null ใน demo adapter หรือถูก omit ใน FastAPI adapter ไม่ใช้ 0 แทนข้อมูลขาด SE ต้องยอมรับกรณี null/ไม่มี field

409 ถ้าคู่เทียบไม่ครบ 3 เช่น `{"detail":{"code":"insufficient_comparable_products","message":"Need 3 distinct eligible same-type products","available_count":2,"required_count":3}}` ถ้าตั้ง COMPARE_SHORTFALL=return_available จะคืน 200 พร้อม 0–3 ชิ้น และ Warning แทน ให้ตกลงกับ SE ก่อนเปลี่ยน

## Headers และข้อจำกัดร่วม

Request ต้องเป็น JSON ใช้ api-key ของ AI service ถ้าตั้งไว้ แต่การตรวจ caller, referer และสิทธิ์ผู้ใช้จริงอยู่ที่ Gateway เท่านั้น

Response headers: X-AI-Engine=semantic/tfidf; X-AI-Mode=personalized/cold_start/similar/compare/empty_catalog; X-AI-Warnings เป็นรหัส ASCII เช่น unresolved_history_ids, status_not_supplied_upstream_must_filter, fewer_than_three_comparable_products

| HTTP | ความหมาย |
| --- | --- |
| 200 | ได้ผลลัพธ์ อาจเป็น array ว่างในเส้น recommend/similar |
| 400 | JSON เสียใน demo server; FastAPI จัด validation JSON เป็น 422 |
| 401 | AI api-key ไม่ตรง |
| 409 | คู่เทียบไม่ครบ 3 ตาม default contract |
| 413 | Request body เกิน 8,000,000 bytes |
| 415 | content encoding ไม่รองรับ; demo ต้องมี Content-Type application/json |
| 422 | Payload/ข้อมูลธุรกิจจำเป็นไม่ครบ |
| 500 | ความผิดพลาดภายใน ไม่คืน traceback หรือ payload ดิบ |

ขนาด body จำกัด 8 MB; history/activity อย่างละ 1,000 รายการ; history_product 1,000; candidate 5,000 ซึ่งเป็น safety limit ไม่ใช่การรับประกัน latency ทุกขนาด

Production ต้องตั้ง APP_ENV=production, REQUIRE_PRODUCT_STATUS=true, AI_API_KEY ยาวอย่างน้อย 24 ตัวอักษร เก็บ key ใน secret store/environment ไม่ commit key ลงไฟล์

## สิ่งที่ยังไม่รวม

การฝึก Semantic แบบ supervised จากผู้ใช้จริง, vector database, feedback logging จากระบบจริง, image similarity, โมเดลประเมินราคา, LLM เขียนบทวิเคราะห์สินค้า, การ publish public server และการแก้ฐานสิทธิ์ของ Gateway เดิม ไม่อ้างว่าฟังก์ชันเหล่านี้ทำแล้ว
