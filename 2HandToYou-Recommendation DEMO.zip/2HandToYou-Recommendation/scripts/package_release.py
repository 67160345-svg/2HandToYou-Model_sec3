"""Package project without caches, environments, secrets or downloaded heavyweight models."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    root=Path(__file__).resolve().parents[1]
    files=[]
    for path in sorted(root.rglob('*')):
        if not path.is_file():
            continue
        rel=path.relative_to(root)
        if any(part in {'__pycache__','.venv','.git'} for part in rel.parts):
            continue
        if path.suffix in {'.pyc','.zip'} or path.name == '.env':
            continue
        if rel.parts[:2] == ('models','semantic'):
            continue
        if path.name == 'SHA256SUMS.json':
            continue
        files.append(path)
    manifest={str(p.relative_to(root)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    checksum=root/'reports/SHA256SUMS.json'
    checksum.write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    files.append(checksum)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(args.output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for path in files:
            archive.write(path,str(Path(root.name)/path.relative_to(root)))
    with zipfile.ZipFile(args.output) as archive:
        bad=archive.testzip()
        if bad:
            raise RuntimeError(f'Archive integrity failure: {bad}')
    print(json.dumps({'archive':str(args.output),'files':len(files),'bytes':args.output.stat().st_size,
                      'sha256':hashlib.sha256(args.output.read_bytes()).hexdigest()},indent=2))
