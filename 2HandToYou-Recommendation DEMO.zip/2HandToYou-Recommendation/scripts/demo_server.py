"""Local-only HTTP demo using the same schemas/service as FastAPI. Not a production server."""
import argparse
import json
import secrets
import sys
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from pydantic import ValidationError
from app.config import Settings
from app.embedding import Encoder
from app.engine import ContractError, RecommendationService
from app.schemas import Product, RecommendRequest, SimilarRequest


def make_handler(service):
    routes={"/gateway/recommendProduct":(RecommendRequest,"recommend","product_recommend"),
            "/gateway/similarProduct":(SimilarRequest,"similar","product_recommend"),
            "/gateway/compareProduct":(SimilarRequest,"compare","product_compare")}

    class Handler(BaseHTTPRequestHandler):
        def setup(self):
            super().setup()
            self.connection.settimeout(15)

        def log_message(self,*args):
            pass  # Do not log request bodies, keys or user histories.

        def reply(self,status,body,headers=None):
            data=json.dumps(body,ensure_ascii=False,allow_nan=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type","application/json; charset=utf-8")
            self.send_header("Content-Length",str(len(data)))
            self.send_header("X-AI-Engine",service.encoder.kind)
            for key,value in (headers or {}).items():
                self.send_header(key,value)
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self):
            if self.path == "/health":
                return self.reply(200,{"status":"ok","engine":service.encoder.kind,"server":"local_demo"})
            return self.reply(404,{"detail":{"code":"not_found"}})

        def do_POST(self):
            if self.path not in routes:
                return self.reply(404,{"detail":{"code":"not_found"}})
            key=service.settings.api_key
            if key and not secrets.compare_digest(self.headers.get("api-key","").encode(),key.encode()):
                return self.reply(401,{"detail":{"code":"invalid_api_key"}})
            if self.headers.get("Transfer-Encoding"):
                return self.reply(411,{"detail":{"code":"content_length_required"}})
            if self.headers.get("Content-Encoding","identity") != "identity":
                return self.reply(415,{"detail":{"code":"unsupported_content_encoding"}})
            if self.headers.get("Content-Type","").split(";")[0].lower() != "application/json":
                return self.reply(415,{"detail":{"code":"json_required"}})
            try:
                length=int(self.headers.get("Content-Length","-1"))
            except ValueError:
                return self.reply(400,{"detail":{"code":"invalid_content_length"}})
            if length < 0:
                return self.reply(411,{"detail":{"code":"content_length_required"}})
            if length > service.settings.max_body_bytes:
                return self.reply(413,{"detail":{"code":"body_too_large"}})
            try:
                data=json.loads(self.rfile.read(length))
                schema,method,output_key=routes[self.path]
                req=schema.model_validate(data)
                result,warnings,mode=getattr(service,method)(req)
                return self.reply(200,{output_key:result},{"X-AI-Mode":mode,"X-AI-Warnings":",".join(sorted(warnings))})
            except (json.JSONDecodeError,UnicodeDecodeError):
                return self.reply(400,{"detail":{"code":"invalid_json"}})
            except ValidationError as exc:
                errors=[{"loc":list(e["loc"]),"msg":e["msg"],"type":e["type"]} for e in exc.errors()]
                return self.reply(422,{"detail":{"code":"invalid_payload","errors":errors}})
            except ContractError as exc:
                return self.reply(exc.status,{"detail":exc.detail})
            except Exception:
                return self.reply(500,{"detail":{"code":"internal_error"}})
    return Handler


def load_service(settings):
    settings.validate()
    catalog=[]
    if settings.catalog_path:
        catalog=[Product.model_validate(p) for p in json.loads(Path(settings.catalog_path).read_text(encoding="utf-8"))]
    return RecommendationService(Encoder(settings),settings,catalog)


if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--port",type=int,default=8000)
    args=parser.parse_args()
    settings=Settings.from_env()
    if settings.environment == "production":
        raise SystemExit("Use FastAPI/Uvicorn for production, not demo_server.py")
    server=ThreadingHTTPServer(("127.0.0.1",args.port),make_handler(load_service(settings)))
    print(f"Local demo: http://127.0.0.1:{args.port} | engine={settings.engine}",flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
