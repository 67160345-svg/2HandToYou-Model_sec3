"""Read the supplied workbook; never edit it or turn synthetic labels into accuracy claims."""
import argparse
import collections
import hashlib
import json
from pathlib import Path
import openpyxl


def table(workbook, sheet):
    rows = workbook[sheet].iter_rows(min_row=4,values_only=True)
    header = next(rows)
    return [dict(zip(header,row)) for row in rows if any(v is not None for v in row)]


def prepare(source, destination):
    destination.mkdir(parents=True,exist_ok=True)
    wb = openpyxl.load_workbook(source,read_only=True,data_only=True)
    rows = table(wb,"05_Recommendation_Dataset")
    behavior = table(wb,"04_Buyer_Behavior")
    mapping = {"Product_ID":"product_id","Product_Name":"product_name","Category":"category",
               "Subcategory":"subcategory","Brand":"brand","Price":"price","Condition":"condition",
               "Popularity_Score":"popularity_score","Product_Status":"product_status"}
    grouped = collections.defaultdict(list)
    for r in rows:
        grouped[r["Product_ID"]].append(r)
    conflicts = {field:sum(len({r[field] for r in group})>1 for group in grouped.values()) for field in mapping}
    if any(conflicts.values()):
        raise ValueError(f"Catalog conflicts require manual resolution: {conflicts}")
    catalog = []
    for product_id in sorted(grouped):
        first = grouped[product_id][0]
        p = {dest:first[src] for src,dest in mapping.items()}
        p["product_description"] = ""  # Missing in source: no invented product description/specs.
        catalog.append(p)
    (destination/"catalog.json").write_text(json.dumps(catalog,ensure_ascii=False,indent=2),encoding="utf-8")
    known = set(grouped)
    unknown = set()
    for r in behavior:
        for field in ["View_History","Click_History","Wishlist","Favorite","Purchase_History"]:
            for value in (r.get(field) or "").split("|"):
                value=value.strip()
                if value and value not in known:
                    unknown.add(value)
    # Keep separate snapshots: Dataset_ID is NOT a cross-sheet join key.
    (destination/"behavior_snapshots.jsonl").write_text("\n".join(json.dumps(r,ensure_ascii=False,default=str) for r in behavior)+"\n",encoding="utf-8")
    report = {
        "source_filename":source.name,"sha256":hashlib.sha256(source.read_bytes()).hexdigest(),
        "source_kind":"synthetic AI/QA data, not real marketplace observations",
        "recommendation_rows":len(rows),"unique_catalog_products":len(catalog),
        "duplicate_buyer_product_pairs":len(rows)-len({(r['Buyer_ID'],r['Product_ID']) for r in rows}),
        "catalog_conflicts":conflicts,"behavior_snapshots":len(behavior),
        "unresolved_behavior_product_id_count":len(unknown),
        "unresolved_behavior_product_id_examples":sorted(unknown)[:20],
        "catalog_status_counts":dict(collections.Counter(p["product_status"] for p in catalog)),
        "missing_source_fields":["product_description","product_deteriorate","product_have_boxset","product_image","product_type"],
        "warnings":[
            "Condition grades are preserved; no arbitrary conversion to deterioration percentage.",
            "No ground-truth semantic similarity or direct-comparison labels are supplied.",
            "Recommendation_Score and Confidence_Score are synthetic; not measured performance.",
            "Acceptance_Criteria Expected values are constants; Pass is not an executed model evaluation.",
            "Do not join Dataset_ID across sheets; use Buyer_ID/Product_ID and verified event time.",
            "Popularity is synthetic and is only suitable for a demonstration.",
        ],
    }
    (destination/"data_audit.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    wb.close()
    return report


if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("source",type=Path)
    parser.add_argument("--out",type=Path,default=Path("data/prepared"))
    args=parser.parse_args()
    print(json.dumps(prepare(args.source,args.out),ensure_ascii=False,indent=2))
