"""Small deliberately hand-authored QA catalog; not market data or measured labels."""
import json
from pathlib import Path


ROOT=Path(__file__).resolve().parents[1]


def write(path, value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding="utf-8")


def build():
    products=[]
    for i in range(16):
        p={"product_id":f"DEMO-PHONE-{i:02d}","product_name":f"Apple iPhone 13 128GB เครื่องที่ {i}",
           "product_description":"สมาร์ตโฟน โทรศัพท์มือถือ Apple iPhone 13 ความจุ 128GB ใช้งานปกติ",
           "category":"Electronics","subcategory":"Smartphone","brand":"Apple",
           "price":8000+i*150,"product_deteriorate":20+i,"product_have_boxset":i%2==0,
           "popularity_score":round((16-i)/16,4),"product_status":"Active"}
        products.append(p)
    products += [
        {"product_id":"DEMO-SHOE","product_name":"รองเท้าวิ่ง Adidas สีดำ","product_description":"รองเท้าวิ่งสำหรับออกกำลังกาย",
         "category":"Fashion","subcategory":"Running Shoes","price":2000,"product_deteriorate":20,"product_have_boxset":True,"popularity_score":1.,"product_status":"Active"},
        {"product_id":"DEMO-SOLD","product_name":"Apple iPhone 13 ขายแล้ว","category":"Electronics","subcategory":"Smartphone",
         "price":5000,"product_deteriorate":20,"product_have_boxset":True,"popularity_score":1.,"product_status":"Sold"},
    ]
    target=products[0]
    examples={
        "recommend":{"history":[{"product_id":target["product_id"]}],"activity":[{"type":"search","keyword":"iPhone 13 โทรศัพท์ Apple"}],"product":products},
        "cold_start":{"history":[],"activity":[],"product":products},
        "similar":{"this_product":target,"product":products},
        "compare":{"this_product":target,"product":products},
        "compare_shortfall":{"this_product":target,"product":products[:3]},
    }
    write(ROOT/"examples/catalog.json",products)
    for name,payload in examples.items():
        write(ROOT/f"examples/{name}.json",payload)
    items=[]
    for name,endpoint,key,limit,status in [
        ("recommend","recommendProduct","product_recommend",10,200),
        ("cold_start","recommendProduct","product_recommend",10,200),
        ("similar","similarProduct","product_recommend",10,200),
        ("compare","compareProduct","product_compare",3,200),
        ("compare_shortfall","compareProduct",None,3,409),
    ]:
        checks=[f'pm.test("HTTP {status}", () => pm.response.to.have.status({status}));']
        if key:
            checks += [f'const rows = pm.response.json().{key};',
                       f'pm.test("result count", () => pm.expect(rows.length).to.be.{"equal(3)" if limit==3 else "at.most(10)"});',
                       'pm.test("unique IDs", () => pm.expect(new Set(rows.map(p=>p.product_id)).size).to.equal(rows.length));',
                       'pm.test("active only", () => rows.forEach(p=>pm.expect(p.product_status).to.equal("Active")));']
        items.append({"name":name,"request":{"method":"POST","header":[
            {"key":"Content-Type","value":"application/json"},{"key":"api-key","value":"{{ai_api_key}}"}],
            "url":{"raw":"{{base_url}}/gateway/"+endpoint,"host":["{{base_url}}"],"path":["gateway",endpoint]},
            "body":{"mode":"raw","raw":json.dumps(examples[name],ensure_ascii=False,indent=2),"options":{"raw":{"language":"json"}}}},
            "event":[{"listen":"test","script":{"type":"text/javascript","exec":checks}}]})
    write(ROOT/"postman/2HandToYou_Local.postman_collection.json",{
        "info":{"name":"2HandToYou Recommendation - LOCAL ONLY","schema":"https://schema.getpostman.com/json/collection/v2.1.0/collection.json",
                "description":"Local AI service. No partner API keys. Gateway authentication remains upstream."},
        "variable":[{"key":"base_url","value":"http://127.0.0.1:8000"},{"key":"ai_api_key","value":""}],"item":items})
    cases=[
        {"name":"interest_phone","endpoint":"recommend","payload":examples["recommend"],"relevant_ids":[p["product_id"] for p in products[:16]]},
        {"name":"similar_phone","endpoint":"similar","payload":examples["similar"],"relevant_ids":[p["product_id"] for p in products[1:16]]},
        {"name":"compare_phone","endpoint":"compare","payload":examples["compare"],"relevant_ids":[p["product_id"] for p in products[1:16]]},
    ]
    write(ROOT/"examples/evaluation_cases.json",{"label_origin":"hand-authored smoke cases, not an independent marketplace benchmark","cases":cases})


if __name__ == "__main__":
    build()
    print("Created local examples and credential-free Postman collection")
