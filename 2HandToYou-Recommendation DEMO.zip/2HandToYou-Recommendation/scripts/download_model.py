"""Download the pretrained model once; does not train on the supplied synthetic workbook."""
import argparse
from pathlib import Path


if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--name",default="sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2")
    parser.add_argument("--revision",default=None,help="Optional upstream commit for reproducibility")
    parser.add_argument("--output",default="models/semantic")
    args=parser.parse_args()
    from sentence_transformers import SentenceTransformer
    model=SentenceTransformer(args.name,revision=args.revision,trust_remote_code=False,device="cpu")
    model.save(str(Path(args.output)))
    print(f"Saved pretrained model to {args.output}. Not fine-tuned or evaluated on marketplace data.")
