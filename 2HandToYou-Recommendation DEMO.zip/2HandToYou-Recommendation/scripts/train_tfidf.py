"""Fit lexical baseline, saved as JSON (no executable pickle/joblib files)."""
import argparse
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from sklearn.feature_extraction.text import TfidfVectorizer
from app.schemas import Product
from app.engine import product_text


def train(catalog_paths, output):
    products={}
    for path in catalog_paths:
        for item in json.loads(path.read_text(encoding="utf-8")):
            p=Product.model_validate(item)
            products[p.product_id]=p
    model=TfidfVectorizer(analyzer="char",ngram_range=(2,5),max_features=40000)
    model.fit([product_text(p) for p in products.values()])
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps({
        "kind":"tfidf_char_lexical_baseline_not_semantic", "catalog_count":len(products),
        "vocabulary":{k:int(v) for k,v in model.vocabulary_.items()}, "idf":model.idf_.tolist(),
    },ensure_ascii=False),encoding="utf-8")
    return {"products":len(products),"features":len(model.vocabulary_),"output":str(output)}


if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--catalog",type=Path,nargs="+",default=[Path("data/prepared/catalog.json"),Path("examples/catalog.json")])
    parser.add_argument("--output",type=Path,default=Path("models/tfidf.json"))
    args=parser.parse_args()
    print(json.dumps(train(args.catalog,args.output),indent=2))
