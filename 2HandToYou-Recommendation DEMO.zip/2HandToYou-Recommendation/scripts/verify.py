"""Run real checks and persist observed results; skipped tests are not passed tests."""
import datetime
import importlib.metadata
import io
import json
import os
from pathlib import Path
import platform
import sys
import unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))


if __name__ == '__main__':
    os.chdir(ROOT)
    suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'))
    stream=io.StringIO()
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    versions={}
    for package in ['numpy','scikit-learn','pydantic','openpyxl','fastapi','uvicorn','httpx','sentence-transformers']:
        try:
            versions[package]=importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            versions[package]='not installed'
    report={'checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'python':platform.python_version(),'platform':platform.system(),'dependencies':versions,
            'tests_run':result.testsRun,'passed':result.testsRun-len(result.skipped)-len(result.failures)-len(result.errors),
            'skipped':[{'test':str(t),'reason':reason} for t,reason in result.skipped],
            'failures':len(result.failures),'errors':len(result.errors),
            'scope':'Engine + local HTTP test adapter; FastAPI and semantic tests run only when dependencies/weights exist.',
            'not_verified':['Real SE gateway','Real marketplace relevance','Windows batch execution','Docker build/deploy']}
    (ROOT/'reports').mkdir(exist_ok=True)
    (ROOT/'reports/verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (ROOT/'reports/verification.txt').write_text(stream.getvalue(),encoding='utf-8')
    print(stream.getvalue())
    print(json.dumps(report,ensure_ascii=False,indent=2))
    raise SystemExit(0 if result.wasSuccessful() else 1)
