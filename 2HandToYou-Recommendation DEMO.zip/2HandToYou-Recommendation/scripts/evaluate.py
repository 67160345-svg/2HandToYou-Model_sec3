"""Evaluate actual ranked lists against separately supplied relevant IDs."""
import argparse
import json
import math
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app.config import Settings
from app.schemas import RecommendRequest, SimilarRequest
from scripts.demo_server import load_service


def metrics(ids,relevant,k):
    relevant=set(relevant)
    gains=[int(pid in relevant) for pid in ids[:k]]
    hits=sum(gains)
    dcg=sum(g/math.log2(i+2) for i,g in enumerate(gains))
    ideal=sum(1/math.log2(i+2) for i in range(min(k,len(relevant))))
    return {f"precision@{k}":hits/k, f"recall@{k}":hits/len(relevant) if relevant else None,
            f"ndcg@{k}":dcg/ideal if ideal else None,
            "mrr":next((1/(i+1) for i,g in enumerate(gains) if g),0),"returned":len(ids)}


if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--cases",type=Path,default=Path("examples/evaluation_cases.json"))
    parser.add_argument("--output",type=Path,default=Path("reports/evaluation.json"))
    args=parser.parse_args()
    service=load_service(Settings.from_env())
    data=json.loads(args.cases.read_text(encoding="utf-8"))
    results=[]
    for case in data["cases"]:
        method=case["endpoint"]
        if method not in {"recommend","similar","compare"}:
            raise ValueError("Invalid evaluation endpoint")
        schema=RecommendRequest if method=="recommend" else SimilarRequest
        payload=schema.model_validate(case["payload"])
        ids={p.product_id for p in payload.product}
        if not case["relevant_ids"] or len(set(case["relevant_ids"])) != len(case["relevant_ids"]):
            raise ValueError("relevant_ids must be nonempty and unique")
        if not set(case["relevant_ids"]) <= ids:
            raise ValueError("Relevant IDs must belong to the supplied candidates")
        ranked,warnings,mode=getattr(service,method)(payload)
        ranked_ids=[p["product_id"] for p in ranked]
        results.append({"name":case["name"],"endpoint":method,"mode":mode,"ranked_ids":ranked_ids,
                        "metrics":metrics(ranked_ids,case["relevant_ids"],3 if method=="compare" else 10)})
    report={"engine":service.encoder.kind,"label_origin":data.get("label_origin","unspecified"),
            "warning":"Smoke-case results do not establish production accuracy. Do not use workbook Expected values as measurements.","results":results}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps(report,ensure_ascii=False,indent=2))
