import copy
import importlib.util
import json
import threading
import unittest
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.error import HTTPError
from pydantic import ValidationError
from app.config import Settings
from app.embedding import Encoder
from app.engine import ContractError,RecommendationService
from app.schemas import Product, RecommendRequest,SimilarRequest
from scripts.demo_server import make_handler
from scripts.evaluate import metrics

ROOT=Path(__file__).resolve().parents[1]


class EngineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.settings=Settings(engine="tfidf",tfidf_path=str(ROOT/"models/tfidf.json"))
        cls.encoder=Encoder(cls.settings)
        cls.service=RecommendationService(cls.encoder,cls.settings)
        cls.products=json.loads((ROOT/"examples/catalog.json").read_text(encoding="utf-8"))

    def payload(self,name):
        return json.loads((ROOT/f"examples/{name}.json").read_text(encoding="utf-8"))

    def test_personalized_ten_relevant(self):
        result,_,mode=self.service.recommend(RecommendRequest.model_validate(self.payload("recommend")))
        self.assertEqual(len(result),10)
        self.assertEqual(mode,"personalized")
        self.assertTrue(all(r['product_id'].startswith('DEMO-PHONE') for r in result))

    def test_cold_start_popularity(self):
        result,_,mode=self.service.recommend(RecommendRequest.model_validate(self.payload("cold_start")))
        self.assertEqual(mode,'cold_start')
        self.assertEqual(len(result),10)
        self.assertEqual([p['score'] for p in result],sorted([p['score'] for p in result],reverse=True))
        self.assertNotIn('DEMO-SOLD',[p['product_id'] for p in result])

    def test_similar_excludes_self(self):
        req=SimilarRequest.model_validate(self.payload('similar'))
        result,_,_=self.service.similar(req)
        self.assertEqual(len(result),10)
        self.assertNotIn(req.this_product.product_id,[p['product_id'] for p in result])

    def test_compare_exact_three_same_type(self):
        result,_,_=self.service.compare(SimilarRequest.model_validate(self.payload('compare')))
        self.assertEqual(len(result),3)
        self.assertTrue(all(p['subcategory']=='Smartphone' for p in result))
        self.assertEqual(len({p['product_id'] for p in result}),3)
        self.assertTrue(all(p['product_id']!='DEMO-PHONE-00' for p in result))

    def test_compare_difference_sign(self):
        req=SimilarRequest.model_validate(self.payload('compare'))
        result,_,_=self.service.compare(req)
        for p in result:
            self.assertEqual(p['price_difference'],p['price']-req.this_product.price)
            self.assertEqual(p['deteriorate_difference'],p['product_deteriorate']-req.this_product.product_deteriorate)

    def test_compare_missing_price_not_invented(self):
        payload=self.payload('compare')
        del payload['this_product']['price']
        result,_,_=self.service.compare(SimilarRequest.model_validate(payload))
        self.assertTrue(all(p['price_difference'] is None for p in result))

    def test_insufficient_compare_409(self):
        with self.assertRaises(ContractError) as ctx:
            self.service.compare(SimilarRequest.model_validate(self.payload('compare_shortfall')))
        self.assertEqual(ctx.exception.status,409)
        self.assertEqual(ctx.exception.detail['available_count'],2)

    def test_shortfall_can_be_explicitly_relaxed(self):
        service=RecommendationService(self.encoder,replace(self.settings,compare_shortfall='return_available'))
        result,warnings,_=service.compare(SimilarRequest.model_validate(self.payload('compare_shortfall')))
        self.assertEqual(len(result),2)
        self.assertIn('fewer_than_three_comparable_products',warnings)

    def test_missing_comparison_type(self):
        payload=self.payload('compare')
        for k in ['category','subcategory']:
            payload['this_product'].pop(k)
        with self.assertRaises(ContractError) as ctx:
            self.service.compare(SimilarRequest.model_validate(payload))
        self.assertEqual(ctx.exception.detail['code'],'missing_product_type')

    def test_missing_comparison_attributes(self):
        payload=self.payload('compare')
        for k in ['product_deteriorate','product_have_boxset']:
            payload['this_product'].pop(k)
        with self.assertRaises(ContractError):
            self.service.compare(SimilarRequest.model_validate(payload))

    def test_compare_false_box_is_valid(self):
        payload=self.payload('compare')
        payload['this_product']['product_have_boxset']=False
        payload['this_product'].pop('product_deteriorate')
        result,_,_=self.service.compare(SimilarRequest.model_validate(payload))
        self.assertTrue(all(p['boxset_match'] for p in result))

    def test_zero_deterioration_is_valid(self):
        p=Product.model_validate({**self.products[0],'product_deteriorate':0})
        self.assertEqual(p.product_deteriorate,0)

    def test_identical_duplicates_removed(self):
        payload=self.payload('similar')
        payload['product']*=2
        req=SimilarRequest.model_validate(payload)
        self.assertEqual(len(req.product),len(self.products))

    def test_conflicting_duplicate_rejected(self):
        payload=self.payload('similar')
        payload['product'].append({**payload['product'][0],'price':1})
        with self.assertRaises(ValidationError):
            SimilarRequest.model_validate(payload)

    def test_unknown_seller_fields_not_returned(self):
        payload=self.payload('similar')
        for p in payload['product']:
            p['seller_email']='private@example.invalid'
        result,_,_=self.service.similar(SimilarRequest.model_validate(payload))
        self.assertTrue(all('seller_email' not in p for p in result))

    def test_all_nonactive_statuses_filtered(self):
        payload=self.payload('cold_start')
        for i,p in enumerate(payload['product']):
            p['product_status']=['Sold','Inactive','Deleted'][i%3]
        result,_,_=self.service.recommend(RecommendRequest.model_validate(payload))
        self.assertEqual(result,[])

    def test_missing_status_strict(self):
        payload=self.payload('similar')
        del payload['product'][1]['product_status']
        service=RecommendationService(self.encoder,replace(self.settings,require_status=True))
        with self.assertRaises(ContractError):
            service.similar(SimilarRequest.model_validate(payload))

    def test_missing_status_compatibility_warning(self):
        payload=self.payload('similar')
        del payload['product'][1]['product_status']
        _,warnings,_=self.service.similar(SimilarRequest.model_validate(payload))
        self.assertIn('status_not_supplied_upstream_must_filter',warnings)

    def test_missing_popularity_cold_start_rejected(self):
        payload=self.payload('cold_start')
        del payload['product'][1]['popularity_score']
        with self.assertRaises(ContractError):
            self.service.recommend(RecommendRequest.model_validate(payload))

    def test_unknown_history_explicit_fallback(self):
        payload=self.payload('cold_start')
        payload['history']=[{'product_id':'UNKNOWN'}]
        _,warnings,mode=self.service.recommend(RecommendRequest.model_validate(payload))
        self.assertEqual(mode,'cold_start')
        self.assertIn('unresolved_history_ids',warnings)

    def test_history_product_enrichment(self):
        payload=self.payload('cold_start')
        historical={**self.products[0],'product_id':'OLD'}
        payload['history']=[{'product_id':'OLD'}]
        payload['history_product']=[historical]
        _,warnings,mode=self.service.recommend(RecommendRequest.model_validate(payload))
        self.assertEqual(mode,'personalized')
        self.assertNotIn('unresolved_history_ids',warnings)

    def test_purchase_not_returned(self):
        payload=self.payload('recommend')
        payload['activity'].append({'type':'purchase','product_id':'DEMO-PHONE-01'})
        result,_,_=self.service.recommend(RecommendRequest.model_validate(payload))
        self.assertNotIn('DEMO-PHONE-01',[p['product_id'] for p in result])

    def test_event_duplication_does_not_change_rank(self):
        payload=self.payload('recommend')
        first=self.service.recommend(RecommendRequest.model_validate(payload))[0]
        payload['activity']*=10
        second=self.service.recommend(RecommendRequest.model_validate(payload))[0]
        self.assertEqual(first,second)

    def test_cart_signal_outweighs_single_view(self):
        # Controlled similarities test the policy, independently of encoder quality.
        import numpy as np
        class IdentityEncoder:
            kind='controlled_test'
            def similarities(self,queries,products):
                return np.asarray([[float(q==p) for p in products] for q in queries])
        products=[self.products[0],self.products[16]]
        payload={'product':products,'history':[{'product_id':products[0]['product_id']}],
                 'activity':[{'type':'add_to_cart','product_id':products[1]['product_id']}]}
        service=RecommendationService(IdentityEncoder(),self.settings)
        result,_,_=service.recommend(RecommendRequest.model_validate(payload))
        self.assertEqual(result[0]['product_id'],products[1]['product_id'])

    def test_recent_interest_outweighs_old_interest(self):
        import numpy as np
        from datetime import datetime,timezone,timedelta
        class IdentityEncoder:
            kind='controlled_test'
            def similarities(self,queries,products):
                # Select query's actual text instead of depending on sort order.
                return np.asarray([[float(q==p) for p in products] for q in queries])
        now=datetime.now(timezone.utc)
        products=[self.products[0],self.products[16]]
        payload={'product':products,'history':[
            {'product_id':products[0]['product_id'],'viewed_at':(now-timedelta(days=180)).isoformat()},
            {'product_id':products[1]['product_id'],'viewed_at':now.isoformat()}]}
        service=RecommendationService(IdentityEncoder(),self.settings)
        result,_,_=service.recommend(RecommendRequest.model_validate(payload))
        self.assertEqual(result[0]['product_id'],products[1]['product_id'])

    def test_invalid_numeric_inputs(self):
        for field,value in [('price',-1),('popularity_score',1.1),('product_deteriorate',101),('price',float('nan'))]:
            with self.subTest(field=field,value=value),self.assertRaises(ValidationError):
                Product.model_validate({**self.products[0],field:value})

    def test_string_false_rejected(self):
        with self.assertRaises(ValidationError):
            Product.model_validate({**self.products[0],'product_have_boxset':'false'})

    def test_naive_datetime_rejected(self):
        with self.assertRaises(ValidationError):
            RecommendRequest.model_validate({'product':[],'history':[{'product_id':'X','viewed_at':'2026-09-01T10:00:00'}]})

    def test_search_requires_keyword(self):
        with self.assertRaises(ValidationError):
            RecommendRequest.model_validate({'product':[],'activity':[{'type':'search'}]})

    def test_empty_candidates(self):
        result,_,_=self.service.recommend(RecommendRequest(product=[]))
        self.assertEqual(result,[])

    def test_short_recommend_returns_available_only(self):
        payload=self.payload('cold_start');payload['product']=payload['product'][:2]
        result,_,_=self.service.recommend(RecommendRequest.model_validate(payload))
        self.assertEqual(len(result),2)

    def test_no_shared_text_finite_scores(self):
        scores=self.encoder.similarities(['𐀀𐀁𐀂'],['xyzzyqzq'])
        self.assertTrue(0 <= float(scores[0,0]) <= 1)

    def test_metrics_known_answer(self):
        actual=metrics(['A','B','C'],['A','C','D'],3)
        self.assertAlmostEqual(actual['precision@3'],2/3)
        self.assertAlmostEqual(actual['recall@3'],2/3)
        self.assertEqual(actual['mrr'],1)

    def test_production_requires_key_and_status(self):
        with self.assertRaises(ValueError):
            replace(self.settings,environment='production').validate()


class HTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        settings=Settings(engine='tfidf',tfidf_path=str(ROOT/'models/tfidf.json'),api_key='test-only-local-key')
        cls.service=RecommendationService(Encoder(settings),settings)
        cls.server=ThreadingHTTPServer(('127.0.0.1',0),make_handler(cls.service))
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True)
        cls.thread.start()
        cls.url=f'http://127.0.0.1:{cls.server.server_port}'

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown();cls.server.server_close();cls.thread.join()

    def call(self,path,payload=None,key='test-only-local-key'):
        body=json.dumps(payload,ensure_ascii=False).encode() if payload is not None else None
        req=Request(self.url+path,data=body,headers={'Content-Type':'application/json','api-key':key})
        try:
            response=urlopen(req,timeout=10)
        except HTTPError as exc:
            response=exc
        with response:
            return response.status,json.loads(response.read()),response.headers

    def test_health(self):
        self.assertEqual(self.call('/health')[0],200)

    def test_all_three_http_contracts(self):
        for name,path,key,count in [('recommend','recommendProduct','product_recommend',10),('similar','similarProduct','product_recommend',10),('compare','compareProduct','product_compare',3)]:
            with self.subTest(endpoint=path):
                data=json.loads((ROOT/f'examples/{name}.json').read_text(encoding='utf-8'))
                status,body,headers=self.call('/gateway/'+path,data)
                self.assertEqual(status,200)
                self.assertEqual(set(body),{key})
                self.assertEqual(len(body[key]),count)
                self.assertEqual(headers['X-AI-Engine'],'tfidf')

    def test_auth_401(self):
        self.assertEqual(self.call('/gateway/recommendProduct',{'product':[]},key='wrong')[0],401)

    def test_validation_422_no_echo(self):
        status,body,_=self.call('/gateway/recommendProduct',{'product':'private-invalid-data'})
        self.assertEqual(status,422)
        self.assertNotIn('private-invalid-data',json.dumps(body))

    def test_large_body_rejected(self):
        req=Request(self.url+'/gateway/recommendProduct',data=b'{}',headers={
            'Content-Type':'application/json','api-key':'test-only-local-key',
            'Content-Length':'8000001'})
        with self.assertRaises(HTTPError) as ctx:
            urlopen(req,timeout=10)
        self.assertEqual(ctx.exception.code,413)
        ctx.exception.close()

    def test_shortfall_409(self):
        data=json.loads((ROOT/'examples/compare_shortfall.json').read_text(encoding='utf-8'))
        self.assertEqual(self.call('/gateway/compareProduct',data)[0],409)

    def test_concurrent_requests(self):
        data=json.loads((ROOT/'examples/similar.json').read_text(encoding='utf-8'))
        with ThreadPoolExecutor(max_workers=4) as pool:
            outputs=list(pool.map(lambda _:self.call('/gateway/similarProduct',data),range(8)))
        self.assertTrue(all(status==200 for status,_,_ in outputs))
        self.assertTrue(all(body==outputs[0][1] for _,body,_ in outputs))


@unittest.skipUnless(importlib.util.find_spec('sentence_transformers') and (ROOT/'models/semantic').exists(),
                     'Semantic weights/dependencies not available locally')
class SemanticTests(unittest.TestCase):
    def test_local_semantic_encoder(self):
        encoder=Encoder(Settings(engine='semantic',model_name=str(ROOT/'models/semantic'),model_local_only=True))
        values=encoder.similarities(['โทรศัพท์มือถือ'],['สมาร์ตโฟน','เก้าอี้ไม้'])
        self.assertEqual(values.shape,(1,2))
        self.assertGreater(float(values[0,0]),float(values[0,1]))


@unittest.skipUnless(importlib.util.find_spec('fastapi') and importlib.util.find_spec('httpx'),
                     'FastAPI/httpx not installed in this execution environment')
class FastAPITests(unittest.TestCase):
    def test_asgi_routes_and_shared_encoder(self):
        from fastapi.testclient import TestClient
        from app.main import create_app
        settings=Settings(engine='tfidf',tfidf_path=str(ROOT/'models/tfidf.json'),api_key='local-test')
        encoder=Encoder(settings)
        with TestClient(create_app(settings,encoder=encoder)) as client:
            for name,path,key,count in [('recommend','recommendProduct','product_recommend',10),('similar','similarProduct','product_recommend',10),('compare','compareProduct','product_compare',3)]:
                data=json.loads((ROOT/f'examples/{name}.json').read_text(encoding='utf-8'))
                response=client.post('/gateway/'+path,json=data,headers={'api-key':'local-test'})
                self.assertEqual(response.status_code,200)
                self.assertEqual(len(response.json()[key]),count)
                self.assertIs(client.app.state.service.encoder,encoder)
            self.assertEqual(client.post('/gateway/recommendProduct',json={'product':[]}).status_code,401)
            self.assertEqual(client.get('/openapi.json').status_code,200)


if __name__=='__main__':
    unittest.main()
