@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
    py -3.11 -m venv .venv
    if errorlevel 1 goto fail
)
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto fail
if not exist models\semantic\modules.json (
    .venv\Scripts\python.exe scripts\download_model.py
    if errorlevel 1 goto fail
)
set AI_ENGINE=semantic
set MODEL_NAME=models/semantic
set MODEL_LOCAL_ONLY=true
set APP_ENV=development
set REQUIRE_PRODUCT_STATUS=false
set COMPARE_SHORTFALL=error
.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --workers 1
goto end
:fail
echo Setup failed. Check Python 3.11, dependencies and model download access.
pause
:end
