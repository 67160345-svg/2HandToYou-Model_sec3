@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
    py -3.11 -m venv .venv
    if errorlevel 1 goto fail
)
.venv\Scripts\python.exe -m pip install -r requirements-demo.txt
if errorlevel 1 goto fail
set AI_ENGINE=tfidf
set APP_ENV=development
set AI_API_KEY=
set REQUIRE_PRODUCT_STATUS=false
set COMPARE_SHORTFALL=error
set TFIDF_PATH=models/tfidf.json
set CATALOG_PATH=
.venv\Scripts\python.exe scripts\demo_server.py
goto end
:fail
echo Setup failed. Install Python 3.11 and check your internet connection.
pause
:end
