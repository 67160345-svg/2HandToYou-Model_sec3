# 2HandToYou-Recommendation — โครงสร้างโปรเจกต์ (STRUCTURE)

ระบบ Recommendation API สำหรับสินค้ามือสอง มี 3 endpoint หลัก (`recommendProduct`,
`similarProduct`, `compareProduct`) รองรับ 2 โหมดโมเดล: `semantic` (sentence-transformers)
และ `tfidf` (baseline สำหรับทดสอบโดยไม่ต้องโหลดโมเดลภาษา)

```
2HandToYou-Recommendation/
├── app/                        # โค้ดหลักของ FastAPI service
│   ├── __init__.py
│   ├── main.py                 # จุดเริ่มแอป, กำหนด route, middleware จำกัดขนาด body, error handling
│   ├── config.py                # อ่านค่า config จาก environment variable (Settings dataclass)
│   ├── engine.py                 # ตรรกะ ranking/recommend/compare หลัก (RecommendationService)
│   ├── embedding.py              # ตัวเข้ารหัสข้อความ: semantic (SentenceTransformer) หรือ tfidf
│   └── schemas.py                # Pydantic models: Product, RecommendRequest, Response ต่างๆ
│
├── scripts/                    # สคริปต์งานเสริม (รันแยกจาก API)
│   ├── demo_server.py             # รันเซิร์ฟเวอร์เดโมสำหรับทดสอบในเครื่อง
│   ├── download_model.py          # ดาวน์โหลด pretrained semantic model มาเก็บไว้ในเครื่อง
│   ├── prepare_data.py            # เตรียม/ทำความสะอาดข้อมูลจาก Excel ต้นทาง
│   ├── train_tfidf.py             # ฝึกโมเดล tfidf แล้วเซฟผลลัพธ์ที่ models/tfidf.json
│   ├── evaluate.py                # รันการประเมินผลตาม evaluation_cases.json
│   ├── make_examples.py           # สร้างไฟล์ตัวอย่าง request/response ใน examples/
│   ├── package_release.py         # แพ็กโปรเจกต์/ทำ checksum สำหรับส่งมอบ
│   └── verify.py                  # ตรวจสอบความถูกต้องของ build ก่อนส่งมอบ
│
├── tests/
│   └── test_api.py               # เทสของ endpoint ต่างๆ (pytest)
│
├── data/
│   ├── source_recommendation.xlsx  # ไฟล์ข้อมูลดิบต้นทาง (ผู้ซื้อ–สินค้า)
│   └── prepared/
│       ├── catalog.json            # แคตตาล็อกสินค้าที่แยกออกมาแล้ว (unique products)
│       ├── behavior_snapshots.jsonl  # ข้อมูลพฤติกรรมผู้ใช้ (ดู/ประวัติ) แบบ snapshot
│       └── data_audit.json          # รายงานปัญหา/ข้อมูลขาดหายที่พบระหว่างเตรียมข้อมูล
│
├── models/
│   └── tfidf.json                # โมเดล TF-IDF ที่ฝึกไว้แล้ว (ใช้ได้ทันทีไม่ต้องดาวน์โหลด)
│   # หมายเหตุ: โมเดล semantic ไม่ได้แนบมาใน ZIP นี้ ต้องรัน download_model.py เอง
│
├── examples/                   # ตัวอย่าง request/response ของแต่ละ endpoint
│   ├── recommend.json
│   ├── similar.json
│   ├── compare.json
│   ├── compare_shortfall.json     # ตัวอย่างที่ตั้งใจให้ได้ HTTP 409 (คู่เทียบไม่ครบ 3)
│   ├── cold_start.json            # ตัวอย่างกรณีไม่มีข้อมูลความสนใจ (ใช้ความนิยมแทน)
│   ├── evaluation_cases.json       # เคสสำหรับ scripts/evaluate.py
│   ├── catalog.json
│   └── gateway_forward.mjs        # ตัวอย่างโค้ด Node.js สำหรับ forward request ผ่าน gateway
│
├── reports/                    # ผลลัพธ์ที่สร้างจากสคริปต์ตรวจสอบ/ประเมินผล
│   ├── evaluation.json
│   ├── verification.json
│   ├── verification.txt
│   └── SHA256SUMS.json            # checksum ของไฟล์ในแพ็กเกจ (สำหรับยืนยันความถูกต้อง)
│
├── docs/
│   └── API_CONTRACT_TH.md        # ข้อเสนอ API contract (path, input/output) ให้ทีม SE ยืนยัน
│
├── postman/
│   └── 2HandToYou_Local.postman_collection.json  # ชุดทดสอบ API ผ่าน Postman (ชี้ที่เครื่องตัวเองเท่านั้น)
│
├── Dockerfile                  # สร้าง image สำหรับรันโหมด production (engine=semantic)
├── requirements.txt             # ไลบรารีสำหรับโหมด semantic (production)
├── requirements-demo.txt        # ไลบรารีสำหรับโหมด tfidf (เดโมเบาๆ)
├── run_demo.bat                 # รันเดโมโหมด tfidf บน Windows (ดับเบิลคลิกได้เลย)
├── run_semantic.bat             # รันโหมด semantic บน Windows (ดาวน์โหลดโมเดลก่อนถ้ายังไม่มี)
├── .env.example                 # ตัวอย่างค่า environment variable ที่ใช้ได้
├── .gitignore / .dockerignore
└── README_TH.md                 # คู่มือหลัก: วิธีรัน, field ที่ SE ต้องส่งเพิ่ม, ข้อจำกัดของ dataset
```

## สรุปการทำงานของแต่ละส่วน

- **`app/`** คือตัว API จริงที่รันด้วย FastAPI มี 3 route หลัก:
  `POST /gateway/recommendProduct`, `POST /gateway/similarProduct`, `POST /gateway/compareProduct`
  - `config.py` อ่านค่าตั้งค่าทั้งหมดจาก environment variable เช่น `AI_ENGINE` (semantic/tfidf),
    `COMPARE_SHORTFALL`, `REQUIRE_PRODUCT_STATUS`
  - `embedding.py` เลือกใช้ semantic model (sentence-transformers) หรือ tfidf ตาม config
    ไม่มีการ fallback แบบเงียบๆ ถ้าโหลดโมเดลไม่สำเร็จจะ error ชัดเจน
  - `engine.py` เป็นตรรกะจัดอันดับ/หาสินค้าใกล้เคียง/เทียบสินค้า พร้อมกฎ เช่น ไม่เทียบสินค้าคนละประเภท
  - `schemas.py` กำหนดรูปแบบข้อมูล input/output และ validation (เช่น `product_status` ต้องเป็น
    Active/Sold/Inactive/Deleted, `popularity_score` ต้องอยู่ 0–1)

- **`scripts/`** เป็นเครื่องมือที่รันแยกจาก API เช่น เตรียมข้อมูล ฝึกโมเดล tfidf ประเมินผล
  และแพ็กเกจ/ตรวจสอบก่อนส่งมอบงาน — ไม่ได้ทำงานตอน request จริง

- **`data/`** เก็บข้อมูลตั้งต้น (Excel) และผลลัพธ์ที่เตรียมแล้ว (แคตตาล็อกสินค้า 2,891 ชิ้น,
  พฤติกรรมผู้ใช้ 5,000 snapshot) พร้อมรายงานข้อมูลที่ขาดหายใน `data_audit.json`

- **`models/tfidf.json`** คือโมเดล baseline ที่ฝึกไว้แล้ว พร้อมใช้ทันที ส่วนโมเดล semantic
  ต้องดาวน์โหลดเองด้วย `scripts/download_model.py` (ไม่รวมมาใน ZIP เพราะไฟล์ใหญ่)

- **`examples/`** และ **`postman/`** มีไว้ให้ทดสอบ API ได้ทันทีโดยไม่ต้องเขียน request เอง

- **`reports/`** เป็นผลลัพธ์อัตโนมัติจากการรัน evaluate/verify — ใช้ตรวจสอบคุณภาพ/ความถูกต้อง
  ของแพ็กเกจก่อนส่งมอบ

- **`docs/API_CONTRACT_TH.md`** คือข้อเสนอ contract ของ API ที่ต้องให้ทีม SE (Backend) ยืนยันก่อนใช้จริง

- **`run_demo.bat`** / **`run_semantic.bat`** คือทางลัดสำหรับรันบน Windows โดยไม่ต้องพิมพ์คำสั่งเอง
  (`run_demo.bat` ใช้โหมด tfidf, `run_semantic.bat` ใช้โหมด semantic)

- **`README_TH.md`** คือเอกสารหลักที่อธิบายวิธีรัน, field ข้อมูลที่ทีม SE ต้องส่งเพิ่ม
  (เช่น `popularity_score`, `category`, `product_status`, `price`), และข้อจำกัดของ dataset ที่ใช้ฝึก/ทดสอบ
